import { world, system, EntityTypes, BlockPermutation } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";

const rail_dist2_low = 2304
const rail_dist2_high = 5184
const visible_dist_2 = 4096
const rail_unit_size = 0.5
const js_high = 0
const je_high = 4
const js_low = -5
const je_low = -1

let players_g = []
let bodies_g = []

//スコアボードオブジェクト取得
let obj_mtc_spd
let obj_maxSpd
let obj_accDA
let obj_accDB
let obj_mtc_accN
let obj_not
let obj_mtc_air
let obj_mtc_Rspd
let obj_mtc_up
let obj_notBM
let obj_notAM
let obj_mtc_sid
let obj_mtc_fid
let obj_mtc_uid
let obj_mtc_parent
let obj_mtc_maku
let obj_mtc_rot
let obj_mtc_gradacc
let obj_mtc_prenot
let obj_mtc_not
let obj_mtc_ato
let obj_mtc_ats
let obj_mtc_dist
let obj_mtc_global
let obj_mtc_dd

function loadObjs() {
    obj_mtc_spd = world.scoreboard.getObjective("mtc_spd")
    obj_maxSpd = world.scoreboard.getObjective("mtc_spdMax")
    obj_accDA = world.scoreboard.getObjective("mtc_accDA")
    obj_accDB = world.scoreboard.getObjective("mtc_accDB")
    obj_mtc_accN = world.scoreboard.getObjective("mtc_accN")
    obj_not = world.scoreboard.getObjective("mtc_not")
    obj_mtc_air = world.scoreboard.getObjective("mtc_air")
    obj_mtc_Rspd = world.scoreboard.getObjective("mtc_Rspd")
    obj_mtc_up = world.scoreboard.getObjective("mtc_up")
    obj_notBM = world.scoreboard.getObjective("mtc_notBM")
    obj_notAM = world.scoreboard.getObjective("mtc_notAM")
    obj_mtc_sid = world.scoreboard.getObjective("mtc_sid")
    obj_mtc_fid = world.scoreboard.getObjective("mtc_fid")
    obj_mtc_uid = world.scoreboard.getObjective("mtc_uid")
    obj_mtc_parent = world.scoreboard.getObjective("mtc_parent")
    obj_mtc_maku = world.scoreboard.getObjective("mtc_maku")
    obj_mtc_rot = world.scoreboard.getObjective("mtc_rot")
    obj_mtc_gradacc = world.scoreboard.getObjective("mtc_gradacc")
    obj_mtc_prenot = world.scoreboard.getObjective("mtc_prenot")
    obj_mtc_not = world.scoreboard.getObjective("mtc_not")
    obj_mtc_ato = world.scoreboard.getObjective("mtc_ato")
    obj_mtc_ats = world.scoreboard.getObjective("mtc_ats")
    obj_mtc_dist = world.scoreboard.getObjective("mtc_dist")
    obj_mtc_global = world.scoreboard.getObjective("mtc_global")
    obj_mtc_dd = world.scoreboard.getObjective("mtc_dd")
}

loadObjs()

//レール情報取得
console.warn("Collecting Objects")
//デフォルトのレール，順序（特に頭4個）が正しくないと高さオフセットがだめになる
let rail_types = ["def0", "def1", "def2", "def3", "def4", "def5", "def6", "def7", "def8", "def9", "def10", "def11"]
let n_rail_type = rail_types.length
const ent_list = EntityTypes.getAll()
for (const ent_type of ent_list) {
    const type_id = ent_type.id
    if (type_id.slice(0, 9) === "mtc:rail_") {
        const addType = type_id.slice(9)
        let existRail = false
        for (const exiType of rail_types) {
            if (exiType === addType) {
                existRail = true
                break
            }
        }
        if (!existRail) {
            rail_types.push(addType)
            n_rail_type++
        }
    }
}

let pre_n_rails = world.getDynamicProperty("pre_r_rails")
if (pre_n_rails !== n_rail_type) {
    world.setDynamicProperty("pre_r_rails", n_rail_type)
    for (let i = 0; i < n_rail_type; i++) {
        world.setDynamicProperty("n_rail_used" + i, 1 / n_rail_type)
    }
}

console.warn("Done! " + n_rail_type + " rails found!")


world.getDimension("overworld").runCommandAsync("function mtc/worldboot")

//架線柱情報
let pole_types = ["def0", "def1"]
let n_pole_type = pole_types.length
const poent_list = EntityTypes.getAll()
for (const ent_type of poent_list) {
    const type_id = ent_type.id
    if (type_id.slice(0, 9) === "mtc:pole_") {
        const addType = type_id.slice(9)
        let existPole = false
        for (const exiType of pole_types) {
            if (exiType === addType) {
                existPole = true
                break
            }
        }
        if (!existPole) {
            pole_types.push(addType)
            n_pole_type++
        }
    }
}

let pre_n_poles = world.getDynamicProperty("pre_r_poles")
if (pre_n_poles !== n_pole_type) {
    world.setDynamicProperty("pre_r_poles", n_pole_type)
    for (let i = 0; i < n_pole_type; i++) {
        world.setDynamicProperty("n_pole_used" + i, 1 / n_pole_type)
    }
}

console.warn("Done! " + n_pole_type + " poles found!")



//車両情報
let all_cars = []
for (const ent_type of ent_list) {
    const type_id = ent_type.id
    if ((type_id.slice(0, 7) === "mtc:mtc" || type_id.slice(0, 7) === "mtc:mcs") && type_id.slice(0, 8) !== "mtc:mtc_") {
        all_cars.push(type_id)
    }
}
all_cars.sort()
console.warn("" + all_cars.length + " bodies found!")


const sleep = (time) => new Promise((r) => system.runTimeout(r, time));


//プレイヤidをキーにして周辺bodyを出す
//アニメーション再生補正用
let ents_around_ids = {}
const tick_init = system.currentTick


function showMTCmenu0(player) {
    //乗務確認
    player.runCommand("function mtc/testBoard")
    player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_calcj1 = @s mtc_calc1")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    let ent = player
    if (ents.length != 0) {
        ent = ents[0]
    }

    const form_home = new ActionFormData();
    form_home.title({ "translate": "mtc:mtc.ui.controll" })

    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.stop" }] }, "textures/mtc_icons/stop")


    if (ent.hasTag("mtc_open")) {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorC" }] }, "textures/mtc_items/doorC")
    } else {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorO" }, { "text": " >" }] }, "textures/mtc_items/doorO")
    }
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.horn" }, { "text": " >" }] }, "textures/mtc_items/horn")
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.sound" }, { "text": " >" }] }, "textures/mtc_items/sound")
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.maku" }, { "text": " >" }] }, "textures/mtc_items/mode")
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.ani" }, { "text": " >" }] }, "textures/mtc_items/ani")

    form_home.show(player).then(re => {
        if (re.cancelationReason === "UserBusy") showMTCmenu0(player);
        const car = getNearestCar(player)
        switch (re.selection) {
            case 0:
                ent.runCommand("scoreboard players operation @s mtc_not = @s mtc_notBM")
                ent.runCommand("tag @s add mtc_mas_v2")
                ent.runCommand("scoreboard players set @s mtc_ato -1")
                ent.runCommand("scoreboard players set @s mtc_spd 0")
                player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.stop" }] })
                break;

            case 1:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    player.runCommand("function mtc/testBoard")
                    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calcj1=0},c=1]", player)
                    if (ents.length == 0) {
                        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                    } else {
                        const ent = ents[0]
                        if (ent.hasTag("mtc_open")) {
                            command(player, "function mtc/doorB")
                        } else {
                            showMTCmenu1_1(player);
                        }
                    }
                }
                break;
            case 2:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    showMTCmenu1_5(player);
                }
                break;
            case 3:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    showMTCmenu1_4(player);
                }
                break;
            case 4:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    showMTCmenu1_2(player);
                }
                break;
            case 5:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    showMTCmenu1_3(player);
                }
                break;
        }
    });
}


//ドア
function showMTCmenu1_1(player) {
    //乗務確認
    player.runCommand("function mtc/testBoard")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    if (ents.length == 0) {
        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
    } else {
        const ent = ents[0]
        const form_home = new ActionFormData();
        form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.door" }] })

        if (ent.hasTag("mtc_bus")) {
            form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorFr" }] }, "textures/mtc_icons/doorFr")
            form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorBa" }] }, "textures/mtc_icons/doorBa")
            form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorBB" }] }, "textures/mtc_icons/doorBB")
        } else {
            form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorL" }] }, "textures/mtc_icons/doorL")
            form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorR" }] }, "textures/mtc_icons/doorR")
            form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.doorB" }] }, "textures/mtc_icons/doorB")
        }
        form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })
        form_home.show(player).then(re => {
            if (re.cancelationReason === "UserBusy") showMTCmenu1_1(player);
            switch (re.selection) {
                case 0:
                    command(player, "function mtc/doorL")
                    break;
                case 1:
                    command(player, "function mtc/doorR")
                    break;
                case 2:
                    command(player, "function mtc/doorB")
                    break;
                case 3:
                    showMTCmenu0(player)
                    break;
            }
        });
    }
}

//幕操作
function showMTCmenu1_2(player) {

    //乗務確認
    player.runCommand("function mtc/testBoard")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    if (ents.length == 0) {
        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
    } else {
        const ent = ents[0]
        const sc_makuM = world.scoreboard.getObjective("mtc_makuM").getScore(ent);
        const sc_maku_now = world.scoreboard.getObjective("mtc_maku").getScore(ent);

        const form_home = new ActionFormData();
        form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.maku" }] })

        for (let i = 1; i <= sc_makuM; i++) {
            let now = ""
            if (sc_maku_now + 1 == i) {
                now = " *"
            }
            form_home.button({ rawtext: [{ "translate": "mtc:" + getIdBase(ent.typeId) + ".Mode" + i }, { "text": now }] })
        }

        form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })

        form_home.show(player).then(re => {
            if (re.cancelationReason === "UserBusy") showMTCmenu1_2(player);
            if (re.selection < sc_makuM && re.selection >= 0) {
                ent.runCommand("scoreboard players set @s mtc_maku " + re.selection)
                ent.runCommand("tag @s add mtc_mode_v2")
            } else if (re.selection === sc_makuM) {
                showMTCmenu0(player)
            }
        });
    }
}

//カスタムアニメーション
function showMTCmenu1_3(player) {
    //乗務確認
    player.runCommand("function mtc/testBoard")
    player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_calcj1 = @s mtc_calc1")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    if (ents.length == 0) {
        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
    } else {
        const ent = ents[0]
        let n_anis = world.scoreboard.getObjective("mtc_max_ani").getScore(ent)
        if (n_anis === undefined) {
            n_anis = 2
        }

        const form_home = new ActionFormData();
        form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.ani" }] })

        for (let i = 1; i <= n_anis; i++) {
            let now = ""
            if (ent.getDynamicProperty("ani" + i) === 1) {
                now = "mtc:mtc.ui.now_on"
            } else {
                now = "mtc:mtc.ui.now_off"
            }
            form_home.button({ rawtext: [{ "translate": "mtc:" + getIdBase(ent.typeId) + ".Ani" + i }, { "text": " : " }, { "translate": now }] })
        }

        form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })

        form_home.show(player).then(re => {
            if (re.cancelationReason === "UserBusy") showMTCmenu1_3(player);
            if (re.selection < n_anis && re.selection >= 0) {
                const ani_id = 1 + re.selection
                player.runCommand("execute as @e[family=mtc_body] run scoreboard players operation @s mtc_calc2 = @s mtc_fid")
                player.runCommand("scoreboard players operation @e[family=mtc_body] mtc_calc2 -= @e[family=mtc_body,tag=mtc_parent,scores={mtc_calcj1=0},c=1] mtc_fid")
                const ents2 = getSelectorEntities("@e[family=mtc_body,scores={mtc_calc2=0}]", player)
                const entb = getSelectorEntities("@e[family=mtc_body,scores={mtc_calc2=0},tag=mtc_parent]", player)[0]
                const before_state = entb.getDynamicProperty("ani" + ani_id)
                for (const ent of ents2) {
                    if (before_state === 1) {
                        entb.removeTag("mtc_ani" + ani_id)
                        ent.setDynamicProperty("ani" + ani_id, 0)
                        stopAni(ent, "ani" + ani_id)
                        playAni(ent, "ani" + ani_id + "e", "ani" + ani_id)
                        try { ent.runCommand(`function ${getIdBase(ent.typeId)}/ani/ani${ani_id}e`) } catch (e) { }
                        const name = getIdBase(ent.typeId)
                        ent.dimension.playSound(name + "_ani" + ani_id + "e", ent.location, { volume: 256 })
                    } else {
                        entb.addTag("mtc_ani" + ani_id)
                        ent.setDynamicProperty("ani" + ani_id, 1)
                        playAni(ent, "ani" + ani_id, "ani" + ani_id)
                        try { ent.runCommand(`function ${getIdBase(ent.typeId)}/ani/ani${ani_id}`) } catch (e) { }
                        const name = getIdBase(ent.typeId)
                        ent.dimension.playSound(name + "_ani" + ani_id, ent.location, { volume: 256 })
                    }
                }
            } else if (re.selection === n_anis) {
                showMTCmenu0(player)
            }
        });
    }
}

//ループ再生
function showMTCmenu1_4(player) {
    //乗務確認
    player.runCommand("function mtc/testBoard")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    if (ents.length == 0) {
        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
    } else {
        const ent = ents[0]
        let n_sounds = world.scoreboard.getObjective("mtc_max_sound").getScore(ent)
        if (n_sounds === undefined) {
            n_sounds = 1
        }

        const form_home = new ActionFormData();
        form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.sound" }] })

        for (let i = 1; i <= n_sounds; i++) {
            let now = ""
            if (ent.getDynamicProperty("sound" + i) === 1) {
                now = "mtc:mtc.ui.now_on"
            } else {
                now = "mtc:mtc.ui.now_off"
            }
            form_home.button({ rawtext: [{ "translate": "mtc:" + getIdBase(ent.typeId) + ".Sound" + i }, { "text": " : " }, { "translate": now }] })
        }

        form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })

        form_home.show(player).then(re => {
            if (re.cancelationReason === "UserBusy") showMTCmenu1_3(player);
            if (re.selection < n_sounds && re.selection >= 0) {
                const sound_id = 1 + re.selection
                player.runCommand("function mtc/testBoard")
                const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {
                    const entb = ents[0]
                    const ents2 = getFormation(entb)
                    const before_state = entb.getDynamicProperty("sound" + sound_id)
                    for (const ent of ents2) {
                        if (before_state === 1) {
                            ent.setDynamicProperty("sound" + sound_id, 0)
                            ent.removeTag("mtc_sound" + sound_id)
                            ent.removeTag("mtc_nsound" + sound_id)
                        } else {
                            ent.setDynamicProperty("sound" + sound_id, 1)
                            ent.addTag("mtc_nsound" + sound_id)
                        }
                    }
                }
            } else if (re.selection === n_sounds) {
                showMTCmenu0(player)
            }
        });
    }
}

//サウンド
function showMTCmenu1_5(player) {
    //乗務確認
    player.runCommand("function mtc/testBoard")
    player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_calcj1 = @s mtc_calc1")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    if (ents.length == 0) {
        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
    } else {
        const ent = ents[0]
        let n_sounds = world.scoreboard.getObjective("mtc_max_horn").getScore(ent)
        if (n_sounds === undefined) {
            n_sounds = 0
        }

        const form_home = new ActionFormData();
        form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.horn" }] })

        for (let i = 1; i <= n_sounds; i++) {
            form_home.button({ rawtext: [{ "translate": "mtc:" + getIdBase(ent.typeId) + ".Horn" + i }] })
        }

        form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })

        form_home.show(player).then(re => {
            if (re.cancelationReason === "UserBusy") showMTCmenu1_3(player);
            if (re.selection < n_sounds && re.selection >= 0) {
                const sound_id = 1 + re.selection
                player.runCommand("execute as @e[family=mtc_body] run scoreboard players operation @s mtc_calc2 = @s mtc_fid")
                player.runCommand("scoreboard players operation @e[family=mtc_body] mtc_calc2 -= @e[family=mtc_body,tag=mtc_parent,scores={mtc_calcj1=0},c=1] mtc_fid")
                const ents2 = getSelectorEntities("@e[family=mtc_body,scores={mtc_calc2=0}]", player)
                for (const ent of ents2) {
                    ent.runCommand(`playsound ${getIdBase(ent.typeId) + "_horn" + sound_id} @a[r=64] ~~~ 256`)
                }
            } else if (re.selection === n_sounds) {
                showMTCmenu0(player)
            }
        });
    }
}

function showMTCset0(player) {
    //乗務確認
    player.runCommand("function mtc/testBoard")
    player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_calcj1 = @s mtc_calc1")
    const ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", player)

    let ent = player
    if (ents.length != 0) {
        ent = ents[0]
    }

    const form_home = new ActionFormData();
    form_home.title({ "translate": "mtc:mtc.ui.settings" })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.stop_all" }] }, "textures/mtc_icons/stop")

    form_home.button({ "translate": "mtc:mtc.ui.kill_train" }, "textures/mtc_items/kill_train")
    form_home.button({ "translate": "mtc:mtc.ui.kill_formation" }, "textures/mtc_items/kill_train")

    form_home.button({ "translate": "mtc:mtc.ui.rot" }, "textures/mtc_items/rot")
    if (ent.hasTag("mtc_selseat")) {
        form_home.button({ "translate": "mtc:mtc.ui.d_selseat" }, "textures/mtc_items/selseat")
    } else {
        form_home.button({ "translate": "mtc:mtc.ui.selseat" }, "textures/mtc_items/selseat")
    }

    form_home.button({ "translate": "mtc:mtc.ui.connect" }, "textures/mtc_items/connect")
    form_home.button({ "translate": "mtc:mtc.ui.disconnect" }, "textures/mtc_items/disconnect")
    form_home.button({ "translate": "mtc:mtc.ui.setting" }, "textures/mtc_items/mtc_set2")
    form_home.show(player).then(re => {
        if (re.cancelationReason === "UserBusy") showMTCset0(player);
        const car = getNearestCar(player)
        switch (re.selection) {
            case 0:
                player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_not = @s mtc_notBM")
                player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run tag @s add mtc_mas_v2")
                player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players set @s mtc_ato -1")
                player.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players set @s mtc_spd 0")
                world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.stop" }] })
                break;
            case 1:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    if (car === null) {
                        const bodies_near = player.dimension.getEntities({ families: ["mtc_body"], location: player.location, maxDistance: 30, closest: 1 })
                        if (bodies_near.length > 0) {
                            command(player, `execute positioned ${bodies_near[0].location.x} ${bodies_near[0].location.y} ${bodies_near[0].location.z} run function mtc_kill`)
                        } else {
                            player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_train" }] })
                        }
                    } else {
                        command(player, `execute positioned ${car.location.x} ${car.location.y} ${car.location.z} run function mtc_kill`)
                    }
                }
                break;
            case 2:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    if (car === null) {
                        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_train" }] })
                    } else {
                        command(player, `execute positioned ${car.location.x} ${car.location.y} ${car.location.z} run function mtc_kill_formation`)
                    }
                }
                break;
            case 3:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {
                    command(player, "function mtc_rot")
                }
                break;
            case 4:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {
                    if (world.getDynamicProperty("mtc_tilt") === 1 && !ent.hasTag("mtc_norail")) {
                        player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.tilt_no_selseat" }] })
                    } else {
                        if (ent.hasTag("mtc_selseat")) {
                            const ents_f = getFormation(ent)
                            for (const ent_f of ents_f) {
                                ent_f.removeTag("mtc_selseat")
                                const com = ent_f.getComponent("minecraft:rideable")
                                if (com !== undefined) {
                                    const riders = com.getRiders()
                                    for (const rider of riders) {
                                        if (rider.typeId == "mtc:seat") {
                                            rider.remove()
                                        }
                                    }
                                }

                            }
                            player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.disable_selseat" }] })
                        } else {
                            player.runCommand("execute as @e[family=mtc_body,c=1] unless entity @s[tag=mtc_selseat] run tellraw @p {\"rawtext\":[{\"text\":\"§a編成の座席選択を有効化しました\"}]}")
                            player.runCommand("execute as @e[family=mtc_body,c=1] if entity @s[tag=mtc_selseat] run tellraw @p {\"rawtext\":[{\"text\":\"§c既に有効化されています\"}]}")
                            player.runCommand("execute as @e[family=mtc_body,c=1] unless entity @s[tag=mtc_selseat] run function mtc_selseat")
                        }
                    }
                }
                break;
            case 5:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {
                    command(player, "function mtc/connect")
                }
                break;
            case 6:
                if (ents.length == 0) {
                    player.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
                } else {

                    command(player, "function mtc/disconnect")
                }

                break;
            case 7:
                showMTCset1_1(player);
                break
        }
    });
}


//他設定
function showMTCset1_1(player) {
    const form_home = new ActionFormData();
    form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.setting" }] })

    if (!obj_mtc_global.hasParticipant("pg_off")) {
        obj_mtc_global.setScore("pg_off", 0)
    }
    if (obj_mtc_global.getScore("pg_off") === 1) {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.pg_on" }] })
    } else {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.pg_off" }] })
    }

    if (world.getDynamicProperty("mtc_tilt") === 1) {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.tilt_off" }] })
    } else {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.tilt_on" }] })
    }

    if (world.getDynamicProperty("mtc_resist_off") === 1) {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.resist_on" }] })
    } else {
        form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.resist_off" }] })
    }

    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.kill_all" }] })

    form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })
        .show(player).then(re => {
            if (re.cancelationReason === "UserBusy") showMTCmenu1_1(player);
            switch (re.selection) {
                case 0:
                    if (obj_mtc_global.getScore("pg_off") === 1) {
                        obj_mtc_global.setScore("pg_off", 0)
                    } else {
                        obj_mtc_global.setScore("pg_off", 1)
                    }
                    break;
                case 1:
                    if (world.getDynamicProperty("mtc_tilt") === 1) {
                        for (const ent of bodies_g) {
                            if (!ent.hasTag("mtc_norail")) {
                                const com = ent.getComponent("minecraft:rideable")
                                if (com !== undefined) {
                                    const riders = com.getRiders()
                                    for (const rider of riders) {
                                        if (rider.typeId == "mtc:seat") {
                                            setState(rider, "mtc_tilt_old", 0)
                                            rider.triggerEvent("ev_p0")
                                        }
                                    }
                                }
                                setbodyUd(ent, 0)
                                //setbodyRl(ent, 0)
                            }
                        }
                        world.setDynamicProperty("mtc_tilt", 0)
                    } else {
                        world.setDynamicProperty("mtc_tilt", 1)
                        world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.msg.tilt_on" }] })
                    }
                    break;
                case 2:
                    if (world.getDynamicProperty("mtc_resist_off") === 1) {
                        world.setDynamicProperty("mtc_resist_off", 0)
                    } else {
                        world.setDynamicProperty("mtc_resist_off", 1)
                    }
                    break;
                case 3:
                    for (const ent of bodies_g) {
                        ent.remove()
                    }
                    break;
                case 4:
                    showMTCset0(player)
                    break;
            }
        });
}


//架線柱設置
function showPOLEmenu0(ent, pl) {

    let now_used = []
    let sorted_used = []
    let sorted_id = []
    for (let i = 0; i < n_pole_type; i++) {
        const cache = world.getDynamicProperty("n_pole_used" + i)
        now_used.push(cache)
        sorted_used.push(cache)
        sorted_id.push(i)
    }

    for (let i = 0; i < n_pole_type - 1; i++) {
        for (let j = 0; j < n_pole_type - 1; j++) {
            if (sorted_used[j + 1] > sorted_used[j]) {
                let c = sorted_used[j]
                sorted_used[j] = sorted_used[j + 1]
                sorted_used[j + 1] = c

                c = sorted_id[j]
                sorted_id[j] = sorted_id[j + 1]
                sorted_id[j + 1] = c
            }
        }
    }

    const form_home = new ActionFormData();
    form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.pole" }] })

    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.cancel" }] })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.remove_ma" }] })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.remove_m" }] })

    for (let i = 0; i < n_pole_type; i++) {
        form_home.button({ rawtext: [{ "translate": "mtc:polename." + pole_types[sorted_id[i]] }] }, "textures/pole_icons/" + pole_types[sorted_id[i]])
    }

    form_home.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showRAILmenu0(ent, pl);
        if (re.selection == 1) {
            const owner_id = ent.getDynamicProperty("mtc_owner")
            const entm_s = pl.dimension.getEntities({ families: ["mtc_pmarker"] })
            for (const ent_m of entm_s) {
                if (ent_m.getDynamicProperty("mtc_owner") === owner_id) {
                    ent_m.remove()
                }
            }
        } else if (re.selection == 2) {
            const owner_id = ent.getDynamicProperty("mtc_owner")
            const my_index = ent.getDynamicProperty("mtc_mark_index")
            const entm_s = pl.dimension.getEntities({ families: ["mtc_pmarker"] })
            let markers = []
            let markers1 = []
            let n_markers = 0
            for (const ent_m of entm_s) {
                if (ent_m.getDynamicProperty("mtc_owner") === owner_id) {
                    const ind = ent_m.getDynamicProperty("mtc_mark_index")
                    markers[ind] = ent_m
                    markers1[ind] = ent_m
                    n_markers++
                }
            }

            const entm1_s = pl.dimension.getEntities({ families: ["mtc_pmarker"] })
            let n_markers1 = 1
            for (const ent_m of entm1_s) {
                if (ent_m.getDynamicProperty("mtc_owner") === owner_id) {
                    markers1[ent_m.getDynamicProperty("mtc_mark_index")] = ent_m
                    n_markers1++
                }
            }

            if (my_index < n_markers - 1) {
                if (my_index !== 0) {
                    markers[my_index + 1].setDynamicProperty("mtc_pre_pos", markers[my_index - 1].location)
                } else {
                    markers[1].setDynamicProperty("mtc_pre_pos", undefined)
                }
                for (let i = my_index + 1; i < n_markers; i++) {
                    markers[i].setDynamicProperty("mtc_mark_index", i - 1)
                }
            }

            ent.remove()

        } else if (re.selection >= 3) {
            const id = sorted_id[re.selection - 3]
            //選択がサジェストにどの程度反映されるかの重み
            now_used[id] += 0.1

            let sum = 0
            for (let i = 0; i < n_pole_type; i++) {
                sum += now_used[i]
            }
            for (let i = 0; i < n_pole_type; i++) {
                now_used[i] *= 1 / sum
                world.setDynamicProperty("n_pole_used" + i, now_used[i])
            }

            if (pole_types[id] === "def2") {
                setPole(ent, pl, id, false)
            } else {
                showPOLEmenu0_1(ent, pl, id)
            }

        }
    });
}

function showPOLEmenu0_1(ent, pl, id) {
    const form_home = new MessageFormData();
    form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.pole" }] })
    form_home.body({ rawtext: [{ "translate": "mtc:mtc.ui.pole_edge" }] })
    form_home.button1("No")
    form_home.button2("Yes")
    form_home.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showPOLEmenu0_1(ent, pl, id);
        if (!re.canceled) setPole(ent, pl, id, re.selection === 1)
    })
}

//レール設置
function showRAILmenu0(ent, pl) {

    let now_used = []
    let sorted_used = []
    let sorted_id = []
    for (let i = 0; i < n_rail_type; i++) {
        const cache = world.getDynamicProperty("n_rail_used" + i)
        now_used.push(cache)
        sorted_used.push(cache)
        sorted_id.push(i)
    }

    for (let i = 0; i < n_rail_type - 1; i++) {
        for (let j = 0; j < n_rail_type - 1; j++) {
            if (sorted_used[j + 1] > sorted_used[j]) {
                let c = sorted_used[j]
                sorted_used[j] = sorted_used[j + 1]
                sorted_used[j + 1] = c

                c = sorted_id[j]
                sorted_id[j] = sorted_id[j + 1]
                sorted_id[j + 1] = c
            }
        }
    }

    const form_home = new ActionFormData();
    form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.rail" }] })

    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.cancel" }] })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.remove_ma" }] })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.remove_m" }] })

    for (let i = 0; i < n_rail_type; i++) {
        form_home.button({ rawtext: [{ "translate": "mtc:railname." + rail_types[sorted_id[i]] }] }, "textures/rail_icons/" + rail_types[sorted_id[i]])
    }

    form_home.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showRAILmenu0(ent, pl);
        if (re.selection == 1) {
            const owner_id = ent.getDynamicProperty("mtc_owner")
            const entm_s = pl.dimension.getEntities({ families: ["mtc_marker"] })
            for (const ent_m of entm_s) {
                if (ent_m.getDynamicProperty("mtc_owner") === owner_id) {
                    ent_m.remove()
                }
            }
        } else if (re.selection == 2) {
            const owner_id = ent.getDynamicProperty("mtc_owner")
            const my_index = ent.getDynamicProperty("mtc_mark_index")
            const entm_s = pl.dimension.getEntities({ type: "mtc:marker0" })
            let markers = []
            let markers1 = []
            let n_markers = 0
            for (const ent_m of entm_s) {
                if (ent_m.getDynamicProperty("mtc_owner") === owner_id) {
                    const ind = ent_m.getDynamicProperty("mtc_mark_index")
                    markers[ind] = ent_m
                    markers1[ind] = ent_m
                    n_markers++
                }
            }

            const entm1_s = pl.dimension.getEntities({ type: "mtc:marker1" })
            let n_markers1 = 1
            for (const ent_m of entm1_s) {
                if (ent_m.getDynamicProperty("mtc_owner") === owner_id) {
                    markers1[ent_m.getDynamicProperty("mtc_mark_index")] = ent_m
                    n_markers1++
                }
            }

            if (n_markers1 > 2 && my_index == 0) {
                pl.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.rail_mk_rem" }] })
            } else {

                if (ent.typeId == "mtc:marker0") {
                    if (my_index < n_markers - 1) {
                        if (my_index !== 0) {
                            markers[my_index + 1].setDynamicProperty("mtc_pre_pos", markers[my_index - 1].location)
                        } else {
                            markers[1].setDynamicProperty("mtc_pre_pos", undefined)
                        }
                        for (let i = my_index + 1; i < n_markers; i++) {
                            markers[i].setDynamicProperty("mtc_mark_index", i - 1)
                        }
                    }

                } else {


                    if (my_index < n_markers1 - 1) {
                        if (my_index !== 0) {
                            markers1[my_index + 1].setDynamicProperty("mtc_pre_pos", markers1[my_index - 1].location)
                        } else {
                            markers1[1].setDynamicProperty("mtc_pre_pos", undefined)
                        }
                        for (let i = my_index + 1; i < n_markers1; i++) {
                            markers1[i].setDynamicProperty("mtc_mark_index", i - 1)
                        }
                    }

                }
                ent.remove()
            }

        } else if (re.selection >= 3) {
            const id = sorted_id[re.selection - 3]
            //選択がサジェストにどの程度反映されるかの重み
            now_used[id] += 0.1

            let sum = 0
            for (let i = 0; i < n_rail_type; i++) {
                sum += now_used[i]
            }
            for (let i = 0; i < n_rail_type; i++) {
                now_used[i] *= 1 / sum
                world.setDynamicProperty("n_rail_used" + i, now_used[i])
            }

            showRAILmenu1_1(ent, pl, id)
        }
    });
}

//レール設置
function showRAILmenu1_1(ent, pl, id) {
    const po_en = (rail_types[id].slice(-3) === "_po")
    const form = new ModalFormData()
    form.title({ rawtext: [{ "translate": "mtc:mtc.ui.rail_title" }] });
    form.slider({ rawtext: [{ "translate": "mtc:mtc.ui.cant_max" }] }, 0, 7.875, 0.125, 6)
    form.textField({ rawtext: [{ "translate": "mtc:mtc.ui.cant_spd" }] },
        { rawtext: [{ "translate": "mtc:mtc.ui.cant_spd_alt" }] }, "")
    form.textField({ rawtext: [{ "translate": "mtc:mtc.ui.joint" }] },
        { rawtext: [{ "translate": "mtc:mtc.ui.cant_spd_alt" }] }, "")
    form.toggle({ rawtext: [{ "translate": "mtc:mtc.ui.tunnel" }] }, false)
    form.toggle({ rawtext: [{ "translate": "mtc:mtc.ui.enable_rainani" }] }, true)
    /*
    if (po_en) {
        let def_m = world.getDynamicProperty("mtc_def_pole_m")
        if (def_m === undefined) def_m = 50;
        form.slider({ rawtext: [{ "translate": "mtc:mtc.ui.pole" }] }, 0, 100, 5, def_m);
    }
    */
    form.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showRAILmenu1_1(ent, pl, id)
        if (re.canceled) {
            showRAILmenu0(ent, pl)
        } else {
            const tlm = re.formValues[0]
            let vrail = re.formValues[1]
            let joint = re.formValues[2]
            const tunnel = re.formValues[3]
            const rani_off = re.formValues[4]
            let po_sel = 0
            /*
            if (po_en) {
                po_sel = re.formValues[5]
                world.setDynamicProperty("mtc_def_pole_m", po_sel)
            }
            */

            if (!(vrail > 0)) vrail = 0//Nan/範囲外対応
            if (!(joint > 0)) joint = 0//Nan/範囲外対応
            if (tunnel) {
                showRAILmenu1_1_1(ent, pl, id, tlm, vrail, joint, rani_off, po_sel)
            } else {
                setRail(ent, pl, id, tlm, vrail, joint, false, 0, 0, 0, 0, rani_off, po_sel)//在来線tlm5.63 新幹線tlm7.13
            }
        }
    })
}
function showRAILmenu1_1_1(ent, pl, id, tlm, vrail, joint, rani_off, po_sel) {
    let default_l = world.getDynamicProperty("mtc_tunnel_l")
    let default_r = world.getDynamicProperty("mtc_tunnel_r")
    let default_u = world.getDynamicProperty("mtc_tunnel_u")
    let default_d = world.getDynamicProperty("mtc_tunnel_d")
    if (default_l === undefined) default_l = 2
    if (default_r === undefined) default_r = 2
    if (default_u === undefined) default_u = 5
    if (default_d === undefined) default_d = 0

    const form = new ModalFormData()
    form.title({ rawtext: [{ "translate": "mtc:mtc.ui.tunnel_title" }] });
    form.slider({ rawtext: [{ "translate": "mtc:mtc.ui.tunnel_l" }] }, 0, 10, 1, default_l)
    form.slider({ rawtext: [{ "translate": "mtc:mtc.ui.tunnel_r" }] }, 0, 10, 1, default_r)
    form.slider({ rawtext: [{ "translate": "mtc:mtc.ui.tunnel_u" }] }, 0, 10, 1, default_u)
    form.slider({ rawtext: [{ "translate": "mtc:mtc.ui.tunnel_d" }] }, 0, 10, 1, default_d)
    form.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showRAILmenu1_1_1(ent, pl, id, tlm, vrail, joint, rani_off, po_sel)
        if (re.canceled) {
            showRAILmenu1_1(ent, pl, id)
        } else {
            const dl = re.formValues[0]
            const dr = re.formValues[1]
            const du = re.formValues[2]
            const dd = re.formValues[3]
            world.setDynamicProperty("mtc_tunnel_l", dl)
            world.setDynamicProperty("mtc_tunnel_r", dr)
            world.setDynamicProperty("mtc_tunnel_u", du)
            world.setDynamicProperty("mtc_tunnel_d", dd)
            setRail(ent, pl, id, tlm, vrail, joint, true, dl, dr, du, dd, rani_off, po_sel)//在来線tlm5.63 新幹線tlm7.13
        }
    })
}

function showMTCspawn0(pl, pos) {
    if (all_cars.length === 0) {
        pl.sendMessage("§cError: No Trains Detected!")
        return
    }
    const form_home = new ActionFormData();
    form_home.title({ rawtext: [{ "text": "1" }, { "translate": "mtc:mtc.ui.spawn_settings" }] })
    for (const name of all_cars) {
        form_home.button({ rawtext: [{ "translate": "item.spawn_egg.entity." + name + ".name" }] }, "textures/items/" + getIdBase(name))
    }
    form_home.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showMTCspawn0(pl, pos);
        if (re.selection >= 0) {
            const sel = re.selection
            showMTCspawn1(pl, pos, [all_cars[sel]], 2)
        }
    })
}
function showMTCspawn1(pl, pos, formations, id) {
    const form_home = new ActionFormData();
    form_home.title({ rawtext: [{ "text": `${id}` }, { "translate": "mtc:mtc.ui.spawn_settings" }] })
    form_home.button({ rawtext: [{ "text": `${id - 1}` }, { "translate": "mtc:mtc.ui.spawn_btn" }] })
    form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })
    for (const name of all_cars) {
        form_home.button({ rawtext: [{ "translate": "item.spawn_egg.entity." + name + ".name" }] }, "textures/items/" + getIdBase(name))
    }
    form_home.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showMTCspawn1(pl, pos, formations, id);
        if (re.selection === 0) {
            showMTCspawn1_1(pl, pos, formations, id)
        } else if (re.selection === 1) {
            if (id === 2) {
                showMTCspawn0(pl, pos)
            } else {
                let fm2 = []
                for (let i = 0; i < formations.length - 1; i++) {
                    fm2.push(formations[i])
                }
                showMTCspawn1(pl, pos, fm2, id - 1)
            }
        } else if (re.selection >= 2) {
            const sel = re.selection - 2
            formations.push(all_cars[sel])
            showMTCspawn1(pl, pos, formations, id + 1)
        }
    })
}

function showMTCspawn1_1(pl, pos, formations, id) {
    const form_home = new ActionFormData();
    form_home.title({ rawtext: [{ "translate": "mtc:mtc.ui.spawn_setinv" }] })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.spawn_normal" }] })
    form_home.button({ rawtext: [{ "translate": "mtc:mtc.ui.spawn_inv" }] })
    form_home.button({ rawtext: [{ "text": "< " }, { "translate": "mtc:mtc.ui.back" }] })
    form_home.show(pl).then(re => {
        if (re.cancelationReason === "UserBusy") showMTCspawn1_1(pl, pos, formations, id);
        switch (re.selection) {
            case 0:
                spawnFormation(pl, pos, formations, false)
                break;
            case 1:
                spawnFormation(pl, pos, formations, true)
                break;
            case 2:
                showMTCspawn1(pl, pos, formations, id);
                break
        }
    })
}

async function spawnFormation(pl, pos, formations, dir_inv = false) {
    let roty
    for (let i = 0; i < formations.length; i++) {
        const name = formations[formations.length - 1 - i]
        pl.sendMessage({ rawtext: [{ "text": "[" + (i + 1) + "/" + formations.length + "] " }, { "translate": "item.spawn_egg.entity." + name + ".name" }] })
        if (i === 0 && dir_inv) world.setDynamicProperty("mtc_nextspawn_inv", true);
        let ent
        let fail = true
        for (let j = 0; j < 100; j++) {
            try {
                ent = pl.dimension.spawnEntity(name, pos)
                if (ent.isValid()) {
                    fail = false
                    break
                }
            } catch (e) {
            }
            await sleep(1)
        }
        if (fail) {
            pl.sendMessage("Formation Spawn Unknown Error 1!")
            return
        }

        fail = true
        for (let j = 0; j < 100; j++) {
            if (ent.hasTag("mtc_init")) {
                fail = false
                break
            }
            await sleep(1)
        }
        if (fail) {
            pl.sendMessage("Formation Spawn Unknown Error 2!")
            return
        }

        fail = true
        for (let j = 0; j < 100; j++) {
            if (!ent.hasTag("mtc_conn")) {
                fail = false
                break
            }
            await sleep(1)
        }
        if (fail) {
            pl.sendMessage("Formation Spawn Unknown Error 3!")
            return
        }

        fail = true
        for (let j = 0; j < 100; j++) {
            if (ent.getDynamicProperty("mtc_body_length") !== undefined) {
                fail = false
                break
            }
            await sleep(1)
        }
        if (fail) {
            pl.sendMessage("Formation Spawn Unknown Error 4!")
            return
        }

        await sleep(20)
        roty = ent.getRotation().y
        pos = ent.location
        const blen = ent.getDynamicProperty("mtc_body_length")
        let dx = -blen * Math.sin(roty * 0.0174533)
        let dz = blen * Math.cos(roty * 0.0174533)
        pos = { x: pos.x + dx, y: pos.y, z: pos.z + dz }
    }
    pl.sendMessage("[OK]")
}

let itemevent_cooldown = 0
world.beforeEvents.itemUseOn.subscribe(ev => {
    if (getState(ev.source, "item_cool") === undefined || system.currentTick - getState(ev.source, "item_cool") >= itemevent_cooldown) {
        setState(ev.source, "item_cool", system.currentTick)
        item(ev, true)
    }
}
)
world.beforeEvents.itemUse.subscribe(ev => {
    if (getState(ev.source, "item_cool") === undefined || system.currentTick - getState(ev.source, "item_cool") >= itemevent_cooldown) {
        setState(ev.source, "item_cool", system.currentTick)
        item(ev, false)
    }
});

function item(ev, on = false) {
    itemevent_cooldown = 2
    if (ev.itemStack.typeId == "mtc:i_notb") {
        ev.cancel = true;
        system.run(() => {
            ev.source.runCommand("execute as \"" + ev.source.name + "\" at @s run function mtc/notb")
        })
    } else if (ev.itemStack.typeId == "mtc:i_noteb") {
        ev.cancel = true;
        system.run(() => {
            ev.source.runCommand("execute as \"" + ev.source.name + "\" at @s run function mtc/noteb")
        })
    } else if (ev.itemStack.typeId == "mtc:i_notn") {
        ev.cancel = true;
        system.run(() => {
            ev.source.runCommand("execute as \"" + ev.source.name + "\" at @s run function mtc/notn")
        })
    } else if (ev.itemStack.typeId == "mtc:i_notp") {
        ev.cancel = true;
        system.run(() => {
            ev.source.runCommand("execute as \"" + ev.source.name + "\" at @s run function mtc/notp")
        })
    } else if (ev.itemStack.typeId == "mtc:i_reverse") {
        ev.cancel = true;
        itemevent_cooldown = 7
        system.run(() => {
            ev.source.runCommand("execute as \"" + ev.source.name + "\" at @s run function mtc/rev")
        })
    } else if (ev.itemStack.typeId == "mtc:i_set") {
        ev.cancel = true;
        itemevent_cooldown = 7
        system.run(() => {
            ev.source.runCommand("playsound random.click \"" + ev.source.name + "\"")
        })
        system.run(() => { showMTCmenu0(ev.source); });
    } else if (ev.itemStack.typeId == "mtc:i_set2") {
        ev.cancel = true;
        itemevent_cooldown = 7
        system.run(() => {
            ev.source.runCommand("playsound random.click \"" + ev.source.name + "\"")
        })
        system.run(() => { showMTCset0(ev.source); });
    } else if (ev.itemStack.typeId == "mtc:i_spawn") {
        ev.cancel = true;
        itemevent_cooldown = 7
        let pos
        if (on) {
            pos = { x: ev.block.x + 0.5, y: ev.block.y + 1, z: ev.block.z + 0.5 }
        } else {
            pos = ev.source.location
        }
        system.run(() => {
            ev.source.runCommand("playsound random.click \"" + ev.source.name + "\"")
        })
        system.run(() => { showMTCspawn0(ev.source, pos); });
    } else if (ev.itemStack.typeId == "mtc:i_marker0") {
        ev.cancel = true;
        itemevent_cooldown = 7
        system.run(() => {
            const bef_ents = ev.source.dimension.getEntities({ type: "mtc:marker0" })
            let n_bef_ent = 0
            let pre_pos = undefined
            let max = -1
            for (const ent of bef_ents) {
                if (ent.getDynamicProperty("mtc_owner") === ev.source.id) {
                    n_bef_ent++
                    if (ent.getDynamicProperty("mtc_mark_index") > max) {
                        max = ent.getDynamicProperty("mtc_mark_index")
                        pre_pos = ent.location
                    }
                }
            }

            let b_pos

            if (on) {
                b_pos = ev.block.center()
                b_pos.y += b_pos.y - ev.block.y
                if (ev.blockFace == "South") {
                    b_pos.z++
                    b_pos.y--
                } else if (ev.blockFace == "North") {
                    b_pos.z--
                    b_pos.y--
                } else if (ev.blockFace == "East") {
                    b_pos.x++
                    b_pos.y--
                } else if (ev.blockFace == "West") {
                    b_pos.x--
                    b_pos.y--
                } else {
                    if (ev.block.typeId.slice(-4) == "rail") b_pos.y -= 1
                    const st = ev.block.permutation.getAllStates()
                    if (st['top_slot_bit'] === false) b_pos.y -= 0.5
                }
            } else {
                b_pos = ev.source.location
            }

            const near_markers = ev.source.dimension.getEntities({ families: ["mtc_rail"], location: b_pos, closest: 64 })
            for (const ent_mk of near_markers) {
                const p1 = ent_mk.getDynamicProperty("mtc_bz_p1")
                const p3 = ent_mk.getDynamicProperty("mtc_bz_p3")
                const dh = p1.y - ent_mk.location.y
                if (dist(b_pos, p1) < 1.42) {
                    b_pos = p1
                    b_pos.y -= dh
                    break
                }
                if (dist(b_pos, p3) < 1.42) {
                    b_pos = p3
                    b_pos.y -= dh
                    break
                }
            }


            const ent = ev.source.dimension.spawnEntity("mtc:marker0", b_pos)

            ent.setDynamicProperty("mtc_owner", ev.source.id)
            ent.setDynamicProperty("mtc_mark_index", n_bef_ent)
            if (n_bef_ent > 0) {
                ent.setDynamicProperty("mtc_pre_pos", pre_pos)
            }


        })
    } else if (ev.itemStack.typeId == "mtc:i_marker1") {
        ev.cancel = true;
        itemevent_cooldown = 7
        system.run(() => {
            const bef_ents = ev.source.dimension.getEntities({ type: "mtc:marker0" })
            let n_bef_ent = 0
            let init_pos = undefined
            for (const ent of bef_ents) {
                if (ent.getDynamicProperty("mtc_owner") === ev.source.id) {
                    n_bef_ent++
                    if (ent.getDynamicProperty("mtc_mark_index") === 0) {
                        init_pos = ent.location
                        break
                    }
                }
            }

            if (n_bef_ent > 0) {
                n_bef_ent = 1
                const bef_ents = ev.source.dimension.getEntities({ type: "mtc:marker1" })
                let pre_pos = init_pos
                let max = -1
                for (const ent of bef_ents) {
                    if (ent.getDynamicProperty("mtc_owner") === ev.source.id) {
                        n_bef_ent++
                        if (ent.getDynamicProperty("mtc_mark_index") > max) {
                            max = ent.getDynamicProperty("mtc_mark_index")
                            pre_pos = ent.location
                        }
                    }
                }

                let b_pos

                if (on) {
                    b_pos = ev.block.center()
                    b_pos.y += b_pos.y - ev.block.y
                    if (ev.blockFace == "South") {
                        b_pos.z++
                        b_pos.y--
                    } else if (ev.blockFace == "North") {
                        b_pos.z--
                        b_pos.y--
                    } else if (ev.blockFace == "East") {
                        b_pos.x++
                        b_pos.y--
                    } else if (ev.blockFace == "West") {
                        b_pos.x--
                        b_pos.y--
                    } else {
                        if (ev.block.typeId.slice(-4) == "rail") b_pos.y -= 1
                        const st = ev.block.permutation.getAllStates()
                        if (st['top_slot_bit'] === false) b_pos.y -= 0.5
                    }
                } else {
                    b_pos = ev.source.location
                }

                const ent = ev.source.dimension.spawnEntity("mtc:marker1", b_pos)

                ent.setDynamicProperty("mtc_owner", ev.source.id)
                ent.setDynamicProperty("mtc_mark_index", n_bef_ent)
                ent.setDynamicProperty("mtc_pre_pos", pre_pos)

            } else {
                ev.source.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_marker0" }] })
            }

        })
    } else if (ev.itemStack.typeId == "mtc:i_marker2") {
        ev.cancel = true;
        itemevent_cooldown = 7
        system.run(() => {
            const bef_ents = ev.source.dimension.getEntities({ type: "mtc:marker2" })
            let n_bef_ent = 0
            let pre_pos = undefined
            let max = -1
            for (const ent of bef_ents) {
                if (ent.getDynamicProperty("mtc_owner") === ev.source.id) {
                    n_bef_ent++
                    if (ent.getDynamicProperty("mtc_mark_index") > max) {
                        max = ent.getDynamicProperty("mtc_mark_index")
                        pre_pos = ent.location
                    }
                }
            }

            let b_pos
            if (on) {
                b_pos = ev.block.center()
                b_pos.y += b_pos.y - ev.block.y
                if (ev.blockFace == "South") {
                    b_pos.z++
                    b_pos.y--
                } else if (ev.blockFace == "North") {
                    b_pos.z--
                    b_pos.y--
                } else if (ev.blockFace == "East") {
                    b_pos.x++
                    b_pos.y--
                } else if (ev.blockFace == "West") {
                    b_pos.x--
                    b_pos.y--
                } else {
                    if (ev.block.typeId.slice(-4) == "rail") b_pos.y -= 1
                    const st = ev.block.permutation.getAllStates()
                    if (st['top_slot_bit'] === false) b_pos.y -= 0.5
                }
            } else {
                b_pos = ev.source.location
            }

            const ent = ev.source.dimension.spawnEntity("mtc:marker2", b_pos)

            ent.setDynamicProperty("mtc_owner", ev.source.id)
            ent.setDynamicProperty("mtc_mark_index", n_bef_ent)
            if (n_bef_ent > 0) {
                ent.setDynamicProperty("mtc_pre_pos", pre_pos)
            }

        })
    }
}

//2秒毎
system.runInterval(() => {
    world.getDimension("overworld").runCommand("execute as @p at @s run function mtc_inner/install")

    //レールアニメ定速
    aniRail()

    loadAllBodies()

}, 40)


let drawed_rail = {}
let drawed_pole = {}
function aniRail() {

    //レールアニメ
    let ents_r = []
    ents_r = ents_r.concat(world.getDimension("overworld").getEntities({ families: ["mtc_rail"], excludeTypes: ["mtc:rail_def0", "mtc:rail2_def0", "mtc:rail_def11", "mtc:rail2_def11"] }))
    ents_r = ents_r.concat(world.getDimension("nether").getEntities({ families: ["mtc_rail"], excludeTypes: ["mtc:rail_def0", "mtc:rail2_def0", "mtc:rail_def11", "mtc:rail2_def11"] }))
    ents_r = ents_r.concat(world.getDimension("the_end").getEntities({ families: ["mtc_rail"], excludeTypes: ["mtc:rail_def0", "mtc:rail2_def0", "mtc:rail_def11", "mtc:rail2_def11"] }))

    let ents_newvalid = {}
    drawed_rail = {}
    for (const pl of players_g) {
        for (const ent of ents_r) {
            const d2 = dist2(pl.location, ent.location)
            if (d2 < rail_dist2_high) {
                ents_newvalid[ent.id] = ent
                if (d2 < rail_dist2_low) {
                    drawed_rail[ent.id] = true
                }
            }
        }
    }
    for (const key in ents_newvalid) {
        const ent = ents_newvalid[key]
        const rest_rot = getState(ent, "mtc_rail_rest_rot")
        if (rest_rot > 0) {
            setState(ent, "mtc_rail_rest_rot", rest_rot - 1)
            ent.teleport(ent.location, { rotation: ent.getRotation() })
        }
        doRailAnime(ent)
    }

    //  ポールアニメ
    let ents_p = []
    ents_p = ents_p.concat(world.getDimension("overworld").getEntities({ families: ["mtc_pole"] }))
    ents_p = ents_p.concat(world.getDimension("nether").getEntities({ families: ["mtc_pole"] }))
    ents_p = ents_p.concat(world.getDimension("the_end").getEntities({ families: ["mtc_pole"] }))

    let poles_newvalid = {}
    drawed_pole = {}

    for (const pl of players_g) {
        for (const ent of ents_p) {
            const d2 = dist2(pl.location, ent.location)
            if (d2 < rail_dist2_high) {
                poles_newvalid[ent.id] = ent
                if (d2 < rail_dist2_low) {
                    drawed_pole[ent.id] = true
                }
            }
        }
    }
    for (const key in poles_newvalid) {
        const ent = poles_newvalid[key]
        const rest_rot = getState(ent, "mtc_rail_rest_rot")
        if (rest_rot > 0) {
            setState(ent, "mtc_rail_rest_rot", rest_rot - 1)
            ent.teleport(ent.location, { rotation: ent.getRotation() })
        }
        doPoleAnime(ent)
    }

}

//定期アニメーション外のレールのアニメーション
let prev_plyers_pos = {}
function aniInvalidRail() {
    //レールアニメ
    let ents_r = []
    ents_r = ents_r.concat(world.getDimension("overworld").getEntities({ families: ["mtc_rail"], excludeTypes: ["mtc:rail_def0", "mtc:rail2_def0", "mtc:rail_def11", "mtc:rail2_def11"] }))
    ents_r = ents_r.concat(world.getDimension("nether").getEntities({ families: ["mtc_rail"], excludeTypes: ["mtc:rail_def0", "mtc:rail2_def0", "mtc:rail_def11", "mtc:rail2_def11"] }))
    ents_r = ents_r.concat(world.getDimension("the_end").getEntities({ families: ["mtc_rail"], excludeTypes: ["mtc:rail_def0", "mtc:rail2_def0", "mtc:rail_def11", "mtc:rail2_def11"] }))

    let ents_newvalid = {}
    for (const pl of players_g) {
        if (prev_plyers_pos[pl.id] === undefined || dist2(pl.location, prev_plyers_pos[pl.id]) > 100) {
            prev_plyers_pos[pl.id] = pl.location
            for (const ent of ents_r) {
                if (drawed_rail[ent.id] === undefined) {
                    const d2 = dist2(pl.location, ent.location)
                    if (d2 < rail_dist2_high) {
                        ents_newvalid[ent.id] = ent
                        if (d2 < rail_dist2_low) {
                            drawed_rail[ent.id] = true
                        } else {
                            delete drawed_rail[ent.id]
                        }
                    }
                }
            }
        }
    }
    for (const key in ents_newvalid) {
        const ent = ents_newvalid[key]
        doRailAnime(ent)
    }

    //ポールアニメ
    let ents_p = []
    ents_p = ents_p.concat(world.getDimension("overworld").getEntities({ families: ["mtc_pole"] }))
    ents_p = ents_p.concat(world.getDimension("nether").getEntities({ families: ["mtc_pole"] }))
    ents_p = ents_p.concat(world.getDimension("the_end").getEntities({ families: ["mtc_pole"] }))

    let poles_newvalid = {}
    for (const pl of players_g) {
        if (prev_plyers_pos[pl.id] === undefined || dist2(pl.location, prev_plyers_pos[pl.id]) > 144) {
            prev_plyers_pos[pl.id] = pl.location
            for (const ent of ents_p) {
                if (drawed_pole[ent.id] === undefined) {
                    const d2 = dist2(pl.location, ent.location)
                    if (d2 < rail_dist2_high) {
                        poles_newvalid[ent.id] = ent
                        if (d2 < rail_dist2_low) {
                            drawed_pole[ent.id] = true
                        } else {
                            delete drawed_pole[ent.id]
                        }
                    }
                }
            }
        }
    }
    for (const key in poles_newvalid) {
        const ent = poles_newvalid[key]
        doPoleAnime(ent)
    }

}

function doPoleAnime(ent, valid = true, disable = false) {

    if (ent.getDynamicProperty("mtc_pole_base_h")) {
        if (valid) {
            playAni(ent, "animation.rail.b_h", "pb_h")
        } else if (disable) {
            stopAni(ent, "pb_h")
        }
    }
    const base_deg = ent.getDynamicProperty("mtc_pole_base_deg")
    if (base_deg > 0) {
        for (let k = 0; k < 6; k++) {
            if ((base_deg >> k & 1) == 1) {
                if (valid) {
                    playAni(ent, `animation.rail.b_r${k + 1}`, `b_lr${k + 1}`)
                } else if (disable) {
                    stopAni(ent, `b_lr${k + 1}`)
                }
            }
        }
    } else if (base_deg < 0) {
        for (let k = 0; k < 6; k++) {
            if (((-base_deg) >> k & 1) == 1) {
                if (valid) {
                    playAni(ent, `animation.rail.b_l${k + 1}`, `b_lr${k + 1}`)
                } else if (disable) {
                    stopAni(ent, `b_lr${k + 1}`)
                }
            }
        }
    }


    const n_s = Math.min(32, ent.getDynamicProperty("n_s"))
    if (n_s < 32) {
        if (valid) {
            playAni(ent, `animation.rail.s${n_s + 1}_h`, `s_h`)
        } else if (disable) {
            stopAni(ent, `s_h`)
        }
    } else {
        if (valid || disable) {
            stopAni(ent, `s_h`)
        }
    }

    if (n_s > 0) {
        const deg_y = ent.getDynamicProperty(`s_lr`)
        const deg_x = ent.getDynamicProperty(`s_ud`)
        if (deg_y > 0) {
            for (let k = 0; k < 8; k++) {
                if ((deg_y >> k & 1) == 1) {
                    if (valid) {
                        playAni(ent, `animation.rail.s1_r${2 ** k}`, `s1_lr${2 ** k}`)
                    } else if (disable) {
                        stopAni(ent, `s1_lr${2 ** k}`)
                    }
                }
            }
        } else if (deg_y < 0) {
            for (let k = 0; k < 8; k++) {
                if (((-deg_y) >> k & 1) == 1) {
                    if (valid) {
                        playAni(ent, `animation.rail.s1_l${2 ** k}`, `s$1_lr${2 ** k}`)
                    } else if (disable) {
                        stopAni(ent, `s1_lr${2 ** k}`)
                    }
                }
            }
        }
        if (deg_x > 0) {
            for (let k = 0; k < 8; k++) {
                if ((deg_x >> k & 1) == 1) {
                    if (valid) {
                        playAni(ent, `animation.rail.s1_u${2 ** k}`, `s1_ud${2 ** k}`)
                    } else if (disable) {
                        stopAni(ent, `s1_ud${2 ** k}`)
                    }
                }
            }
        } else if (deg_x < 0) {
            for (let k = 0; k < 8; k++) {
                if (((-deg_x) >> k & 1) == 1) {
                    if (valid) {
                        playAni(ent, `animation.rail.s1_d${2 ** k}`, `s1_ud${2 ** k}`)
                    } else if (disable) {
                        stopAni(ent, `s1_ud${2 ** k}`)
                    }
                }
            }
        }
    }


}

function doRailAnime(ent, valid = true, disable = false) {
    if (ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_rail2") && ent.getDynamicProperty("mtc_now_npt") === 2 && ent.getDynamicProperty("mtc_pani_off") !== 1) {
        if (valid) {
            playAni(ent, `animation.rail.s1_h`, `s_h`)
        } else if (disable) {
            stopAni(ent, `s_h`)
        }
    } else {
        const n_s = Math.min(32, ent.getDynamicProperty("n_s"))
        if (n_s < 32) {
            if (valid) {
                playAni(ent, `animation.rail.s${n_s + 1}_h`, `s_h`)
            } else if (disable) {
                stopAni(ent, `s_h`)
            }
        } else {
            if (valid || disable) {
                stopAni(ent, `s_h`)
            }
        }
        /*
                const n_po = Math.min(16, ent.getDynamicProperty("mtc_po_n"))
                if (n_po !== undefined) {
                    let hide_list = []
                    let j = 1
                    let jm = ent.getDynamicProperty("mtc_po_m" + j)
                    for (let i = 1; i <= Math.ceil(n_s/2); i++) {
                        if (jm === i) {
                            j++
                            if (j <= n_po) jm = ent.getDynamicProperty("mtc_po_m" + j);
                        } else {
                            hide_list.push(i)
                        }
                    }
                    if (valid) {
                        for (const m of hide_list) {
                            playAni(ent, `animation.rail.m${m}_po`, `s_po${m}`)
                        }
                    } else if (disable) {
                        for (const m of hide_list) {
                            stopAni(ent, `s_po${m}`)
                        }
                    }
                }
        */

        for (let j = 0; j < n_s; j++) {
            const deg_y = ent.getDynamicProperty(`s${j + 1}_lr`)
            const deg_x = ent.getDynamicProperty(`s${j + 1}_ud`)
            if (deg_y > 0) {
                for (let k = 0; k < 8; k++) {
                    if ((deg_y >> k & 1) == 1) {
                        if (valid) {
                            playAni(ent, `animation.rail.s${j + 1}_r${2 ** k}`, `s${j + 1}_lr${2 ** k}`)
                        } else if (disable) {
                            stopAni(ent, `s${j + 1}_lr${2 ** k}`)
                        }
                    }
                }
            } else if (deg_y < 0) {
                for (let k = 0; k < 8; k++) {
                    if (((-deg_y) >> k & 1) == 1) {
                        if (valid) {
                            playAni(ent, `animation.rail.s${j + 1}_l${2 ** k}`, `s${j + 1}_lr${2 ** k}`)
                        } else if (disable) {
                            stopAni(ent, `s${j + 1}_lr${2 ** k}`)
                        }
                    }
                }
            }
            if (deg_x > 0) {
                for (let k = 0; k < 8; k++) {
                    if ((deg_x >> k & 1) == 1) {
                        if (valid) {
                            playAni(ent, `animation.rail.s${j + 1}_u${2 ** k}`, `s${j + 1}_ud${2 ** k}`)
                        } else if (disable) {
                            stopAni(ent, `s${j + 1}_ud${2 ** k}`)
                        }
                    }
                }
            } else if (deg_x < 0) {
                for (let k = 0; k < 8; k++) {
                    if (((-deg_x) >> k & 1) == 1) {
                        if (valid) {
                            playAni(ent, `animation.rail.s${j + 1}_d${2 ** k}`, `s${j + 1}_ud${2 ** k}`)
                        } else if (disable) {
                            stopAni(ent, `s${j + 1}_ud${2 ** k}`)
                        }
                    }
                }
            }
        }
    }

    //分岐
    if (ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_rail2")) {
        if (ent.getDynamicProperty("mtc_now_npt") !== 2 && ent.getDynamicProperty("mtc_pani_off") !== 1) {
            if (valid) {
                playAni(ent, `animation.rail.p2s1_h`, `p2s_h`)
            } else if (disable) {
                stopAni(ent, `p2s_h`)
            }
        } else {
            const n_s = Math.min(32, ent.getDynamicProperty("n_p2s"))
            if (n_s < 32) {
                if (valid) {
                    playAni(ent, `animation.rail.p2s${n_s + 1}_h`, `p2s_h`)
                } else if (disable) {
                    stopAni(ent, `p2s_h`)
                }
            } else {
                if (valid || disable) {
                    stopAni(ent, `p2s_h`)
                }
            }

            /*
            const n_po = Math.min(16, ent.getDynamicProperty("mtc_p2po_n"))
            if (n_po !== undefined) {
                let hide_list = []
                let j = 1
                let jm = ent.getDynamicProperty("mtc_p2po_m" + j)
                for (let i = 1; i <= Math.ceil(n_s/2); i++) {
                    if (jm === i) {
                        j++
                        if (j <= n_po) jm = ent.getDynamicProperty("mtc_p2po_m" + j);
                    } else {
                        hide_list.push(i)
                    }
                }
                if (valid) {
                    for (const m of hide_list) {
                        playAni(ent, `animation.rail.p2m${m}_po`, `s_p2po${m}`)
                    }
                } else if (disable) {
                    for (const m of hide_list) {
                        stopAni(ent, `s_p2po${m}`)
                    }
                }
            }
    */


            for (let j = 0; j < n_s; j++) {
                const deg_y = ent.getDynamicProperty(`p2s${j + 1}_lr`)
                const deg_x = ent.getDynamicProperty(`p2s${j + 1}_ud`)
                if (deg_y > 0) {
                    for (let k = 0; k < 8; k++) {
                        if ((deg_y >> k & 1) == 1) {
                            if (valid) {
                                playAni(ent, `animation.rail.p2s${j + 1}_r${2 ** k}`, `p2s${j + 1}_lr${2 ** k}`)
                            } else if (disable) {
                                stopAni(ent, `p2s${j + 1}_lr${2 ** k}`)
                            }
                        }
                    }
                } else if (deg_y < 0) {
                    for (let k = 0; k < 8; k++) {
                        if (((-deg_y) >> k & 1) == 1) {
                            if (valid) {
                                playAni(ent, `animation.rail.p2s${j + 1}_l${2 ** k}`, `p2s${j + 1}_lr${2 ** k}`)
                            } else if (disable) {
                                stopAni(ent, `p2s${j + 1}_lr${2 ** k}`)
                            }
                        }
                    }
                }
                if (deg_x > 0) {
                    for (let k = 0; k < 8; k++) {
                        if ((deg_x >> k & 1) == 1) {
                            if (valid) {
                                playAni(ent, `animation.rail.p2s${j + 1}_u${2 ** k}`, `p2s${j + 1}_ud${2 ** k}`)
                            } else if (disable) {
                                stopAni(ent, `p2s${j + 1}_ud${2 ** k}`)
                            }
                        }
                    }
                } else if (deg_x < 0) {
                    for (let k = 0; k < 8; k++) {
                        if (((-deg_x) >> k & 1) == 1) {
                            if (valid) {
                                playAni(ent, `animation.rail.p2s${j + 1}_d${2 ** k}`, `p2s${j + 1}_ud${2 ** k}`)
                            } else if (disable) {
                                stopAni(ent, `p2s${j + 1}_ud${2 ** k}`)
                            }
                        }
                    }
                }
            }
        }
    }

}

//毎秒実行
system.runInterval(() => {
    //ストラクチャーブロック近視
    let ents_r = []
    ents_r = ents_r.concat(world.getDimension("overworld").getEntities({ families: ["mtc_rail"] }))
    ents_r = ents_r.concat(world.getDimension("nether").getEntities({ families: ["mtc_rail"] }))
    ents_r = ents_r.concat(world.getDimension("the_end").getEntities({ families: ["mtc_rail"] }))
    for (const ent of ents_r) {
        const bz1 = ent.getDynamicProperty("mtc_bz_p1")
        const loc = ent.location
        const df2 = (bz1.x - loc.x) ** 2 + (bz1.z - loc.z) ** 2
        if (df2 > 25) {
            world.sendMessage("§c[Real Rail Error] Structure Block is not Supported!")
            world.sendMessage("§cReal Rail May not Work!")
        }
        if (loc.y < -100) {
            ent.addTag("mtc_safe_remove")
            ent.remove()
        }
        const def_loc = ent.getDynamicProperty("location")
        if (def_loc !== undefined) ent.teleport(def_loc);
    }

    //ポール水流対策
    let ents_p = []
    ents_p = ents_p.concat(world.getDimension("overworld").getEntities({ families: ["mtc_pole"] }))
    ents_p = ents_p.concat(world.getDimension("nether").getEntities({ families: ["mtc_pole"] }))
    ents_p = ents_p.concat(world.getDimension("the_end").getEntities({ families: ["mtc_pole"] }))
    for (const ent of ents_p) {
        const loc = ent.location
        if (loc.y < -100) {
            ent.addTag("mtc_safe_remove")
            ent.remove()
        }
        const def_loc = ent.getDynamicProperty("location")
        if (def_loc !== undefined) ent.teleport(def_loc);
    }

    //自動乗務
    for (const pl of players_g) {
        if (pl.isValid()) {
            if (!pl.hasTag("mtc_ride")) {
                let suc = false
                const ride_cp = pl.getComponent("minecraft:riding")
                if (ride_cp !== undefined) {
                    //乗ってる場合
                    const ride = ride_cp.entityRidingOn
                    if (ride.getComponent("minecraft:type_family").hasTypeFamily("mtc_body")) {
                        const fid = obj_mtc_fid.getScore(ride);
                        obj_mtc_parent.setScore(pl, fid)
                        suc = true
                    } else if (ride.typeId == "mtc:seat") {
                        const ride_cp = ride.getComponent("minecraft:riding")
                        if (ride_cp !== undefined) {
                            const ride = ride_cp.entityRidingOn
                            if (ride.getComponent("minecraft:type_family").hasTypeFamily("mtc_body")) {
                                const fid = obj_mtc_fid.getScore(ride);
                                obj_mtc_parent.setScore(pl, fid)
                                suc = true
                            }
                        }
                    }
                }

                if (!suc) {
                    obj_mtc_parent.setScore(pl, 0)
                }
            }
        }
    }



    let has_marker2 = false
    for (const pl of players_g) {
        const item = pl.getComponent("minecraft:inventory").container.getSlot(pl.selectedSlotIndex)
        if (item.hasItem()) {
            if (item.typeId == "mtc:i_marker2") {
                has_marker2 = true
                break
            }
        }
    }

    //架線柱パーティクル
    if (has_marker2) {
        let ents_m = []
        ents_m = ents_m.concat(world.getDimension("overworld").getEntities({ families: ["mtc_pole"] }))
        ents_m = ents_m.concat(world.getDimension("nether").getEntities({ families: ["mtc_pole"] }))
        ents_m = ents_m.concat(world.getDimension("the_end").getEntities({ families: ["mtc_pole"] }))
        for (const ent of ents_m) {
            const eloc = ent.location

            if (ent.dimension.getEntities({ type: "player", location: eloc, maxDistance: 64, closest: 1 }).length > 0) {
                ent.runCommand(`particle minecraft:sculk_soul_particle ${(eloc.x).toFixed(5)} ${(eloc.y).toFixed(5)} ${(eloc.z).toFixed(5)}`)
                ent.runCommand(`particle minecraft:sculk_soul_particle ${(eloc.x).toFixed(5)} ${(eloc.y + 2).toFixed(5)} ${(eloc.z).toFixed(5)}`)
                ent.runCommand(`particle minecraft:sculk_soul_particle ${(eloc.x).toFixed(5)} ${(eloc.y + 4).toFixed(5)} ${(eloc.z).toFixed(5)}`)
            }
        }
    }

    let has_marker = false
    for (const pl of players_g) {
        const item = pl.getComponent("minecraft:inventory").container.getSlot(pl.selectedSlotIndex)
        if (item.hasItem()) {
            if (item.typeId == "mtc:i_marker0" || item.typeId == "mtc:i_marker1") {
                has_marker = true
                break
            }
        }
    }

    //レールパーティクル
    if (has_marker) {
        let ents_m = []
        ents_m = ents_m.concat(world.getDimension("overworld").getEntities({ families: ["mtc_rail"] }))
        ents_m = ents_m.concat(world.getDimension("nether").getEntities({ families: ["mtc_rail"] }))
        ents_m = ents_m.concat(world.getDimension("the_end").getEntities({ families: ["mtc_rail"] }))
        for (const ent of ents_m) {
            const eloc = ent.location
            const p1 = ent.getDynamicProperty("mtc_bz_p1")
            const p2 = ent.getDynamicProperty("mtc_bz_p2")
            const p3 = ent.getDynamicProperty("mtc_bz_p3")

            if (ent.dimension.getEntities({ type: "player", location: eloc, maxDistance: 64, closest: 1 }).length > 0) {
                ent.runCommand(`particle minecraft:sculk_soul_particle ${(eloc.x).toFixed(5)} ${(eloc.y).toFixed(5)} ${(eloc.z).toFixed(5)}`);

                if (ent.typeId === "mtc:rail_def0" || ent.typeId === "mtc:rail2_def0" || ent.typeId === "mtc:rail_def11" || ent.typeId === "mtc:rail2_def11") {

                    const len = bezierLength(p1, p2, p3, 0, 1)
                    let offset = 0
                    if (ent.typeId === "mtc:rail_def11" || ent.typeId === "mtc:rail2_def11") offset = 2
                    for (let t = 0; t <= 1; t += 1 / len) {
                        if (Math.random() <= 0.5) {
                            const p = getBezier(p1, p2, p3, t)
                            if (ent.dimension.getEntities({ type: "player", location: p, maxDistance: 64, closest: 1 }).length > 0) {
                                ent.runCommand(`particle minecraft:villager_happy ${(p.x).toFixed(5)} ${(p.y + offset).toFixed(5)} ${(p.z).toFixed(5)}`)
                            } else {
                                t += 4 / len
                            }
                        }
                    }
                }
            }
        }
    }

    //マーカーパーティクル
    let ents_m = []
    ents_m = ents_m.concat(world.getDimension("overworld").getEntities({ families: ["mtc_marker"] }))
    ents_m = ents_m.concat(world.getDimension("nether").getEntities({ families: ["mtc_marker"] }))
    ents_m = ents_m.concat(world.getDimension("the_end").getEntities({ families: ["mtc_marker"] }))
    let own_ids = {}
    let final_ent = undefined
    let first_ent = undefined
    let final_index = -1
    for (const ent of ents_m) {
        own_ids[ent.getDynamicProperty("mtc_owner")] = ent
        const pre_pos = ent.getDynamicProperty("mtc_pre_pos")
        const index = ent.getDynamicProperty("mtc_mark_index")
        if (index > final_index) {
            final_ent = ent
            final_index = index
        }
        if (index == 0) {
            first_ent = ent
        }
        if (pre_pos !== undefined && index > 0) {
            const dx = ent.location.x - pre_pos.x
            const dy = ent.location.y - pre_pos.y
            const dz = ent.location.z - pre_pos.z
            const len = Math.sqrt(dx ** 2 + dy ** 2 + dz ** 2)
            for (let t = 0; t <= 1; t += 0.5 / len) {
                if (Math.random() <= 0.5) {
                    const p = { x: ent.location.x - dx * t, y: ent.location.y - dy * t + 0.5, z: ent.location.z - dz * t }

                    if (ent.dimension.getEntities({ type: "player", location: p, maxDistance: 64, closest: 1 }).length > 0) {
                        ent.runCommand(`particle minecraft:villager_happy ${(p.x).toFixed(5)} ${(p.y).toFixed(5)} ${(p.z).toFixed(5)}`)
                    } else {
                        t += 4 / len
                    }
                }
            }
        } else if (index === 0 && ent.typeId == "mtc:marker0") {
            //playAni(ent, "animation.mtc_marker.show", "marker_show")
        }

    }

    //マーカー位置表示
    if (final_ent !== undefined) {
        const pl = world.getEntity(final_ent.getDynamicProperty("mtc_owner"))
        let trg_pos = pl.location

        const blh = pl.getBlockFromViewDirection()
        if (blh !== undefined) {
            let blp = blh.block.location
            const fcp = blh.faceLocation
            blp.x += fcp.x
            blp.y += fcp.y
            blp.z += fcp.z

            blp.x = Math.floor(blp.x) + 0.5
            blp.y = Math.floor(blp.y * 2) / 2
            blp.z = Math.floor(blp.z) + 0.5

            trg_pos = blp
        }

        const di = dist(final_ent.location, trg_pos)
        const dx = trg_pos.x - final_ent.location.x
        const dy = trg_pos.y - final_ent.location.y
        const dz = trg_pos.z - final_ent.location.z

        pl.runCommand(`title @s actionbar ${di.toFixed(1)}m  dx: ${dx.toFixed(1)}  dy: ${dy.toFixed(1)}  dz: ${dz.toFixed(1)}`)

        {
            const dx = trg_pos.x - first_ent.location.x
            const dz = trg_pos.z - first_ent.location.z
            for (let i = -3; i < 4; i++) {
                let dr = Math.round(dz / 20) * 20 + 10 * i
                let ds = Math.round(dx / 20) * 20
                let d = Math.abs(dr)
                dr -= 0.6
                pl.runCommand(`particle mtc:ud ${(first_ent.location.x + 1.6 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                pl.runCommand(`particle mtc:num${d % 10} ${(first_ent.location.x + 0.6 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 10) pl.runCommand(`particle mtc:num${Math.trunc(d / 10) % 10} ${(first_ent.location.x + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 100) pl.runCommand(`particle mtc:num${Math.trunc(d / 100) % 10} ${(first_ent.location.x - 0.6 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 1000) pl.runCommand(`particle mtc:num${Math.trunc(d / 1000) % 10} ${(first_ent.location.x - 1.2 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 10000) pl.runCommand(`particle mtc:num${Math.trunc(d / 10000) % 10} ${(first_ent.location.x - 1.8 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
            }
            for (let i = -3; i < 4; i++) {
                let dr = Math.round(dx / 20) * 20 + 10 * i
                let ds = Math.round(dz / 20) * 20 + 0.6
                let d = Math.abs(dr)
                pl.runCommand(`particle mtc:lr ${(first_ent.location.x + 1.6 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                pl.runCommand(`particle mtc:num${d % 10} ${(first_ent.location.x + 0.6 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 10) pl.runCommand(`particle mtc:num${Math.trunc(d / 10) % 10} ${(first_ent.location.x + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 100) pl.runCommand(`particle mtc:num${Math.trunc(d / 100) % 10} ${(first_ent.location.x - 0.6 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 1000) pl.runCommand(`particle mtc:num${Math.trunc(d / 1000) % 10} ${(first_ent.location.x - 1.2 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 10000) pl.runCommand(`particle mtc:num${Math.trunc(d / 10000) % 10} ${(first_ent.location.x - 1.8 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
            }


            for (let i = -1; i < 2; i++) {
                for (let j = -1; j < 2; j++) {
                    let dx2 = Math.round(i + dx / 20) * 20
                    let dz2 = Math.round(j + dz / 20) * 20
                    pl.runCommand(`particle mtc:matrix1 ${(first_ent.location.x + dx2).toFixed(4)} ${(first_ent.location.y + 0.05).toFixed(4)} ${(first_ent.location.z + dz2).toFixed(4)}`)
                }
            }


        }
    }


    //    for (const pl of players_g) {
    for (const own_id in own_ids) {
        const own_ent = own_ids[own_id]
        const opl = world.getEntity(own_id)
        let init_loc
        {
            let marker0s = []
            const bef_ents = own_ent.dimension.getEntities({ type: "mtc:marker0" })
            let n_bef_ent = 0
            for (const ent of bef_ents) {
                if (ent.getDynamicProperty("mtc_owner") === own_id) {
                    n_bef_ent++
                    const index = ent.getDynamicProperty("mtc_mark_index")
                    marker0s[index] = ent.location
                    if (index === 0)
                        init_loc = ent.location;
                }
            }
            if (dist2(marker0s[marker0s.length - 1], opl.location) > 9) {
                const item = opl.getComponent("minecraft:inventory").container.getSlot(opl.selectedSlotIndex)
                if (item.hasItem()) {
                    if (item.typeId == "mtc:i_marker0") {
                        marker0s.push(opl.location)
                    }
                }
            }
            if (n_bef_ent > 0) {
                const bzs = splitBezier(marker0s)
                for (const bz of bzs) {
                    const len = bezierLength(bz[0], bz[1], bz[2], 0, 1)
                    for (let t = 0; t <= 1; t += 1 / len) {
                        const loc = getBezier(bz[0], bz[1], bz[2], t)
                        if (own_ent.dimension.getEntities({ type: "player", location: loc, maxDistance: 64, closest: 1 }).length > 0) {
                            own_ent.runCommand(`particle minecraft:electric_spark_particle ${loc.x.toFixed(5)} ${(loc.y + 0.2).toFixed(5)} ${loc.z.toFixed(5)}`)
                        } else {
                            t += 4 / len
                        }

                    }
                }
            }
        }
        {
            let marker1s = [init_loc]
            const bef_ents = own_ent.dimension.getEntities({ type: "mtc:marker1" })
            let n_bef_ent = 0
            for (const ent of bef_ents) {
                if (ent.getDynamicProperty("mtc_owner") === own_id) {
                    n_bef_ent++
                    const index = ent.getDynamicProperty("mtc_mark_index")
                    marker1s[index] = ent.location
                }
            }
            if (dist2(marker1s[marker1s.length - 1], opl.location) > 9) {
                const item = opl.getComponent("minecraft:inventory").container.getSlot(opl.selectedSlotIndex)
                if (item.hasItem()) {
                    if (item.typeId == "mtc:i_marker1") {
                        marker1s.push(opl.location)
                    }
                }
            }

            if (n_bef_ent > 0) {
                const bzs = splitBezier(marker1s)
                for (const bz of bzs) {
                    const len = bezierLength(bz[0], bz[1], bz[2], 0, 1)
                    for (let t = 0; t <= 1; t += 1 / len) {
                        const loc = getBezier(bz[0], bz[1], bz[2], t)
                        if (own_ent.dimension.getEntities({ type: "player", location: loc, maxDistance: 64, closest: 1 }).length > 0) {
                            own_ent.runCommand(`particle minecraft:electric_spark_particle ${loc.x.toFixed(5)} ${(loc.y + 0.2).toFixed(5)} ${loc.z.toFixed(5)}`);
                        } else {
                            t += 4 / len
                        }

                    }
                }
            }
        }
    }

    //ポールマーカーパーティクル
    let ents_pm = []
    first_ent = undefined
    final_ent = undefined
    final_index = -1
    ents_pm = ents_pm.concat(world.getDimension("overworld").getEntities({ families: ["mtc_pmarker"] }))
    ents_pm = ents_pm.concat(world.getDimension("nether").getEntities({ families: ["mtc_pmarker"] }))
    ents_pm = ents_pm.concat(world.getDimension("the_end").getEntities({ families: ["mtc_pmarker"] }))
    for (const ent of ents_pm) {
        const pre_pos = ent.getDynamicProperty("mtc_pre_pos")
        const index = ent.getDynamicProperty("mtc_mark_index")
        if (index > final_index) {
            final_ent = ent
            final_index = index
        }
        if (index == 0) {
            first_ent = ent
        }
        if (pre_pos !== undefined && index > 0) {
            const dx = ent.location.x - pre_pos.x
            const dy = ent.location.y - pre_pos.y
            const dz = ent.location.z - pre_pos.z
            const len = Math.sqrt(dx ** 2 + dy ** 2 + dz ** 2)
            for (let t = 0; t <= 1; t += 0.5 / len) {
                if (Math.random() <= 0.5) {
                    const p = { x: ent.location.x - dx * t, y: ent.location.y - dy * t + 0.5, z: ent.location.z - dz * t }
                    if (ent.dimension.getEntities({ type: "player", location: p, maxDistance: 64, closest: 1 }).length > 0) {
                        ent.runCommand(`particle minecraft:villager_happy ${(p.x).toFixed(5)} ${(p.y).toFixed(5)} ${(p.z).toFixed(5)}`)
                    } else {
                        t += 4 / len
                    }
                }
            }
        } else if (index === 0) {
            //playAni(ent, "animation.mtc_marker.show", "marker_show")
        }
    }

    if (final_ent !== undefined) {
        const pl = world.getEntity(final_ent.getDynamicProperty("mtc_owner"))
        let trg_pos = pl.location

        const blh = pl.getBlockFromViewDirection()
        if (blh !== undefined) {
            let blp = blh.block.location
            const fcp = blh.faceLocation
            blp.x += fcp.x
            blp.y += fcp.y
            blp.z += fcp.z

            blp.x = Math.floor(blp.x) + 0.5
            blp.y = Math.floor(blp.y * 2) / 2
            blp.z = Math.floor(blp.z) + 0.5

            trg_pos = blp
        }

        const di = dist(final_ent.location, trg_pos)
        const dx = trg_pos.x - final_ent.location.x
        const dy = trg_pos.y - final_ent.location.y
        const dz = trg_pos.z - final_ent.location.z

        pl.runCommand(`title @s actionbar ${di.toFixed(1)}m  dx: ${dx.toFixed(1)}  dy: ${dy.toFixed(1)}  dz: ${dz.toFixed(1)}`)

        {
            const dx = trg_pos.x - first_ent.location.x
            const dz = trg_pos.z - first_ent.location.z
            for (let i = -3; i < 4; i++) {
                let dr = Math.round(dz / 20) * 20 + 10 * i
                let ds = Math.round(dx / 10) * 10
                let d = Math.abs(dr)
                dr -= 0.6
                pl.runCommand(`particle mtc:ud ${(first_ent.location.x + 1.6 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                pl.runCommand(`particle mtc:num${d % 10} ${(first_ent.location.x + 0.6 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 10) pl.runCommand(`particle mtc:num${Math.trunc(d / 10) % 10} ${(first_ent.location.x + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 100) pl.runCommand(`particle mtc:num${Math.trunc(d / 100) % 10} ${(first_ent.location.x - 0.6 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 1000) pl.runCommand(`particle mtc:num${Math.trunc(d / 1000) % 10} ${(first_ent.location.x - 1.2 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
                if (d >= 10000) pl.runCommand(`particle mtc:num${Math.trunc(d / 10000) % 10} ${(first_ent.location.x - 1.8 + ds).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + dr).toFixed(4)}`)
            }
            for (let i = -3; i < 4; i++) {
                let dr = Math.round(dx / 20) * 20 + 10 * i
                let ds = Math.round(dz / 10) * 10 + 0.6
                let d = Math.abs(dr)
                pl.runCommand(`particle mtc:lr ${(first_ent.location.x + 1.6 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                pl.runCommand(`particle mtc:num${d % 10} ${(first_ent.location.x + 0.6 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 10) pl.runCommand(`particle mtc:num${Math.trunc(d / 10) % 10} ${(first_ent.location.x + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 100) pl.runCommand(`particle mtc:num${Math.trunc(d / 100) % 10} ${(first_ent.location.x - 0.6 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 1000) pl.runCommand(`particle mtc:num${Math.trunc(d / 1000) % 10} ${(first_ent.location.x - 1.2 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
                if (d >= 10000) pl.runCommand(`particle mtc:num${Math.trunc(d / 10000) % 10} ${(first_ent.location.x - 1.8 + dr).toFixed(4)} ${(first_ent.location.y + 0.1).toFixed(4)} ${(first_ent.location.z + ds).toFixed(4)}`)
            }


            for (let i = -1; i < 2; i++) {
                for (let j = -1; j < 2; j++) {
                    let dx2 = Math.round(i + dx / 20) * 20
                    let dz2 = Math.round(j + dz / 20) * 20
                    pl.runCommand(`particle mtc:matrix1 ${(first_ent.location.x + dx2).toFixed(4)} ${(first_ent.location.y + 0.05).toFixed(4)} ${(first_ent.location.z + dz2).toFixed(4)}`)
                }
            }


        }
    }


}, 20);

//毎10tick実行
let t0 = getTime()
let tps_g = 20
let scale_g = 1    //アンチラグスケール
const tps_lpf = 0.8
system.runInterval(() => {
    const t = getTime()
    const tps_temp = 10000 / (t - t0)
    tps_g = tps_temp * (1 - tps_lpf) + tps_g * tps_lpf
    tps_g = Math.min(tps_g, 20)
    obj_mtc_global.setScore("tps", Math.round(tps_g))
    if (world.getDynamicProperty("mtc_scale") > 0) {
        scale_g = world.getDynamicProperty("mtc_scale")
    } else {
        const max_scale = world.getDynamicProperty("mtc_max_scale")
        if (max_scale > 1) {
            scale_g = Math.max(1, Math.min(max_scale, 20 / tps_g))
            if (scale_g < 1.05) scale_g = 1;
        } else {
            scale_g = 1
        }
    }

    t0 = t

    world.getDimension("overworld").runCommand("function mtc/tick10")


    //車体傾斜有効時の鉄道座席選択処理
    if (world.getDynamicProperty("mtc_tilt") === 1) {
        for (const ent of bodies_g) {
            if (!ent.hasTag("mtc_selseat") && !ent.hasTag("mtc_norail")) {
                ent.addTag("mtc_selseat")
            }
        }
    }


    //カスタムアニメーション再開
    // プレイヤ付近のbody検出
    for (const pl of players_g) {

        if (ents_around_ids[pl.id] === undefined) {
            ents_around_ids[pl.id] = []
        }
        // 離れを削除
        let new_ids = []
        for (const ent_id of ents_around_ids[pl.id]) {
            try {
                const ent = world.getEntity(ent_id)
                const d = dist2(pl.location, ent.location)
                if (d < visible_dist_2) {//()64^2
                    new_ids.push(ent_id)
                }
            } catch (e) {
            }
        }
        ents_around_ids[pl.id] = new_ids

        //新規接近
        for (const ent of bodies_g) {
            const d = dist2(pl.location, ent.location)
            if (d < visible_dist_2) {//64^2
                if (!ents_around_ids[pl.id].includes(ent.id)) {
                    ents_around_ids[pl.id].push(ent.id)
                    //新規範囲内エンティティから接近したプレイヤにアニメーション
                    // DynamicProperty参照
                    let n_anis = world.scoreboard.getObjective("mtc_max_ani").getScore(ent)
                    if (n_anis === undefined) {
                        n_anis = 2
                    }

                    for (let i = 1; i <= n_anis; i++) {
                        if (ent.getDynamicProperty("ani" + i) === 1) {
                            playAni(ent, "ani" + i, "ani" + i, pl.name)
                        }
                    }

                    let atc_v = ent.getDynamicProperty("mtc_atc")

                    if (atc_v === undefined)
                        atc_v = -1;
                    //ATC(サブカスタムメーター，1/5/10km/h刻みをサポート)
                    if (atc_v >= 0) {
                        playAni(ent, "atc_" + Math.trunc(atc_v / 10) * 10, "mtc_anicon_atc_meter", pl.name)
                        playAni(ent, "atc_" + Math.trunc(atc_v / 5) * 5, "mtc_anicon_atc_meter", pl.name)
                        playAni(ent, "atc_" + atc_v, "mtc_anicon_atc_meter", pl.name)
                    }

                    const v = Math.abs(Math.ceil(obj_mtc_spd.getScore(ent) / 2000))
                    playAni(ent, "v_" + Math.trunc(v / 10) * 10, "mtc_anicon_spd_meter", pl.name)
                    playAni(ent, "v_" + Math.trunc(v / 5) * 5, "mtc_anicon_spd_meter", pl.name)
                    playAni(ent, "v_" + v, "mtc_anicon_spd_meter", pl.name)
                }
            }
        }
    }

    if (bodies_g.length > 0) {
        for (const ent of bodies_g) {
            //音源再生
            let n_sounds = world.scoreboard.getObjective("mtc_max_sound").getScore(ent)
            if (n_sounds === undefined) {
                n_sounds = 1
            }
            for (let i = 1; i <= n_sounds; i++) {
                if (ent.getDynamicProperty("sound" + i) === 1) {
                    //ent.runCommand(`execute positioned ^^^${ent.getDynamicProperty("mtc_body_length")/2} run function mtc/testSound`)
                    testSound(ent)
                    ent.runCommand(`playsound ${getIdBase(ent.typeId) + "_sound" + i} @a[r=32,scores={mtc_sid=0}] ^^^${ent.getDynamicProperty("mtc_body_length") / 2}  64`)
                }
            }
        }

    }
}, 10);


let no_loaded_players = world.getPlayers()
let bodies_sfs_g = {}
//毎5tick実行
system.runInterval(() => {

    world.getDimension("overworld").runCommand("function mtc/tick5")

    let new_pls = []
    for (const pl of players_g) {
        if (pl !== undefined && pl.isValid()) {
            new_pls.push(pl)
        }
    }
    players_g = new_pls

    let new_bds = []
    for (const ent of bodies_g) {
        if (ent.isValid()) {
            new_bds.push(ent)
        }
    }
    bodies_g = new_bds

    for (const ent of bodies_g) {
        bodies_sfs_g[ent.id] = getFormation(ent)
    }


    //レールアニメ高速
    aniInvalidRail()

    //分岐レッドストーン検知
    let ents_rail2 = world.getDimension("overworld").getEntities({ families: ["mtc_rail2"] })
    ents_rail2 = ents_rail2.concat(world.getDimension("nether").getEntities({ families: ["mtc_rail2"] }))
    ents_rail2 = ents_rail2.concat(world.getDimension("the_end").getEntities({ families: ["mtc_rail2"] }))
    for (const ent of ents_rail2) {
        const btm_block = ent.dimension.getBlock({ x: ent.location.x, y: ent.location.y - 1, z: ent.location.z })
        if (btm_block !== undefined) {
            let redstone_on = false
            if (btm_block.typeId == "minecraft:redstone_wire") {
                const st = btm_block.permutation.getAllStates()
                if (st["redstone_signal"] > 0) redstone_on = true
            } else if (btm_block.typeId == "minecraft:redstone_torch") {
                redstone_on = true
            }
            let point_pre = ent.getDynamicProperty("mtc_point_pre")
            if ((redstone_on && point_pre === 1) || point_pre === undefined) {
                ent.setDynamicProperty("mtc_bz_p1", ent.getDynamicProperty("mtc_bz2_p1"))
                ent.setDynamicProperty("mtc_bz_p2", ent.getDynamicProperty("mtc_bz2_p2"))
                ent.setDynamicProperty("mtc_bz_p3", ent.getDynamicProperty("mtc_bz2_p3"))
                ent.setDynamicProperty("mtc_point_pre", 2)
                ent.setDynamicProperty("mtc_now_npt", 2)
                aniRail()
            }
            if ((!redstone_on && point_pre === 2) || point_pre === undefined) {
                ent.setDynamicProperty("mtc_bz_p1", ent.getDynamicProperty("mtc_bz1_p1"))
                ent.setDynamicProperty("mtc_bz_p2", ent.getDynamicProperty("mtc_bz1_p2"))
                ent.setDynamicProperty("mtc_bz_p3", ent.getDynamicProperty("mtc_bz1_p3"))
                ent.setDynamicProperty("mtc_point_pre", 1)
                ent.setDynamicProperty("mtc_now_npt", 1)
                aniRail()
            }
        }
    }

    //高速飛行落下防止
    for (const pl of players_g) {
        //現在の乗車テスト
        //100km/h以上でロック（カウントセット&entity id登録），未満でアンロック（カウント0）
        //ロックしたらカウントセット
        //乗車してないかつカウント>0の場合→乗車トライ,カウントダウン
        const ride_cp = pl.getComponent("minecraft:riding")
        if (ride_cp !== undefined) {
            //乗ってる場合
            const ride = ride_cp.entityRidingOn
            if (ride.getComponent("minecraft:type_family").hasTypeFamily("mtc_body")) {
                if (obj_mtc_spd.getScore(ride) >= 200000 && ride.hasTag("mtc_plane")) {
                    pl.setDynamicProperty("mtc_reride_count", 60)
                    pl.setDynamicProperty("mtc_reride_id", ride.id)
                } else {
                    pl.setDynamicProperty("mtc_reride_count", 0)
                }
            }
        } else {
            //乗ってない場合
            const count = pl.getDynamicProperty("mtc_reride_count")
            const eid = pl.getDynamicProperty("mtc_reride_id")
            if (count !== undefined) {
                if (count > 0) {
                    pl.setDynamicProperty("mtc_reride_count", count - 1)
                    try {
                        const ent = world.getEntity(eid)
                        if (obj_mtc_spd.getScore(ent) >= 200000) {
                            const ridable_cp = ent.getComponent("minecraft:rideable")
                            if (ridable_cp !== undefined) ridable_cp.addRider(pl)
                        } else {
                            pl.setDynamicProperty("mtc_reride_count", 0)
                        }
                    } catch (e) {
                    }
                }
            }
        }
    }

    //取り残された座席消去
    let ents_seat = world.getDimension("overworld").getEntities({ type: "mtc:seat" })
    ents_seat = ents_seat.concat(world.getDimension("nether").getEntities({ type: "mtc:seat" }))
    ents_seat = ents_seat.concat(world.getDimension("the_end").getEntities({ type: "mtc:seat" }))
    for (const seat of ents_seat) {
        const ride_cp = seat.getComponent("minecraft:riding")
        if (ride_cp === undefined) {
            //乗ってない場合
            seat.remove()
        }
    }

    // 回転召喚補正
    if (obj_mtc_global.getScore("dir_preset") > 0) {
        obj_mtc_global.addScore("dir_preset", -1)
    }

    // 起動検知
    if (no_loaded_players.length > 0) {
        let new_list = []
        for (const pl of no_loaded_players) {
            if (pl.isValid()) {
                if (pl.getVelocity().x !== 0 || pl.getVelocity().y !== 0 || pl.getVelocity().z !== 0) {
                    ents_around_ids[pl.id] = []
                    players_g.push(pl)
                } else {
                    new_list.push(pl)
                }
            }
        }
        no_loaded_players = new_list
    }

    //イベント(速度用)
    for (const ent of bodies_g) {

        if (ent.hasTag("mtc_parent") && !ent.hasTag("mtc_norail")) {
            const v = Math.abs(Math.ceil(obj_mtc_spd.getScore(ent) / 2000))

            let ats_v = Math.ceil(obj_mtc_ats.getScore(ent) / 2000)
            let ato_v = Math.ceil(obj_mtc_ato.getScore(ent) / 2000)

            if (obj_mtc_ats.getScore(ent) < 0) {
                ats_v = -1
            }
            if (obj_mtc_ato.getScore(ent) < 0) {
                ato_v = -1
            }

            // 親車両個々から実行

            // 実行主mtc_fidと同じmtc_fidを持つ車体を取得
            const ents_f = getFormation(ent)


            const not = obj_not.getScore(ent)
            const notBM = obj_notBM.getScore(ent)
            for (const ent_f of ents_f) {
                // メーターアニメーション
                //const name = ent_f.typeId.split(":")[1]
                const name2 = getIdBase(ent_f.typeId)

                //速度(1/5/10km/h刻みをサポート)
                const spd_v_bef = getState(ent_f, "spd_ani_bef")
                if (spd_v_bef !== v) {
                    setState(ent_f, "spd_ani_bef", v)
                    playAni(ent_f, "v_" + Math.trunc(v / 10) * 10, "mtc_anicon_spd_meter")
                    playAni(ent_f, "v_" + Math.trunc(v / 5) * 5, "mtc_anicon_spd_meter")
                    playAni(ent_f, "v_" + v, "mtc_anicon_spd_meter")
                }

                //ATS(1/5/10km/h刻みをサポート)
                if (ats_v < 0) {
                    if (getState(ent_f, "disable_ats") !== 1) {
                        setState(ent_f, "disable_ats", 1)
                        stopAni(ent_f, "mtc_anicon_ats_meter")
                        stopAni(ent_f, "ats_on")
                    }
                } else {
                    setState(ent_f, "disable_ats", 0)
                    playAni(ent_f, "ats_" + Math.trunc(ats_v / 10) * 10, "mtc_anicon_ats_meter")
                    playAni(ent_f, "ats_" + Math.trunc(ats_v / 5) * 5, "mtc_anicon_ats_meter")
                    playAni(ent_f, "ats_" + ats_v, "mtc_anicon_ats_meter")
                    playAni(ent_f, "ats_on", "ats_on")
                }

                //ATO(1/5/10km/h刻みをサポート)
                if (ato_v < 0) {
                    if (getState(ent_f, "disable_ato") !== 1) {
                        setState(ent_f, "disable_ato", 1)
                        stopAni(ent_f, "mtc_anicon_ato_meter")
                        stopAni(ent_f, "ato_on")
                    }
                } else {
                    setState(ent_f, "disable_ato", 0)
                    playAni(ent_f, "ato_" + Math.trunc(ato_v / 10) * 10, "mtc_anicon_ato_meter")
                    playAni(ent_f, "ato_" + Math.trunc(ato_v / 5) * 5, "mtc_anicon_ato_meter")
                    playAni(ent_f, "ato_" + ato_v, "mtc_anicon_ato_meter")
                    playAni(ent_f, "ato_on", "ato_on")
                }

                //TASC
                if (ent_f.hasTag("mtc_tasc")) {
                    setState(ent_f, "disable_tasc", 0)
                    playAni(ent_f, "tasc_on", "tasc_on")
                } else {
                    if (getState(ent_f, "disable_tasc") !== 1) {
                        setState(ent_f, "disable_tasc", 1)
                        stopAni(ent_f, "tasc_on")
                    }
                }


                //走行音(通常エンジン)
                if (!ent_f.hasTag("mtc_soundengine2")) {
                    testSound(ent_f, ents_f)
                    const v2 = Math.abs(v)

                    if (not == 0 || not == notBM) {
                        if (!(not == notBM && ent_f.hasTag("mtc_bus"))) ent_f.runCommand(`playsound ${name2}_n${v2} @a[r=96,scores={mtc_sid=0}] ^^^${ent_f.getDynamicProperty("mtc_body_length") / 2} 64`);
                    } else if (not > 0) {
                        ent_f.runCommand(`playsound ${name2}_a${v2} @a[r=96,scores={mtc_sid=0}] ^^^${ent_f.getDynamicProperty("mtc_body_length") / 2} 64`)
                    } else {
                        ent_f.runCommand(`playsound ${name2}_b${v2} @a[r=96,scores={mtc_sid=0}] ^^^${ent_f.getDynamicProperty("mtc_body_length") / 2} 64`)
                    }
                }
            }

            // 0km/h処理
            if (v == 0) {
                ent.addTag("mtc_stop")
            } else {
                ent.removeTag("mtc_stop")
            }
        } else if (ent.hasTag("mtc_plane")) {
            const name = getIdBase(ent.typeId)
            const v = 0.54 * obj_mtc_spd.getScore(ent) / 2000//ノット
            const raw_atc_v = ent.getDynamicProperty("mtc_atc")
            const eng_pow_int = Math.trunc(ent.getDynamicProperty("mtc_engine"))
            const altitude = ent.location.y * 3.2808//10フィート1ステップ
            let dir = ent.getRotation().y
            if (dir < 0)
                dir += 360;

            let atc_v = -1
            if (raw_atc_v !== undefined)
                atc_v = raw_atc_v;

            //高度計算
            let height = 20000.0
            let h_loc = ent.location

            if (h_loc.y > 330)
                h_loc.y = 330;
            for (let i = 0; i < 5; i++) {
                const ublock = ent.dimension.getBlockFromRay(h_loc, { x: 0, y: -1, z: 0 })
                if (ublock !== undefined) {
                    height = ent.location.y - ublock.block.y - 1
                    break
                } else if (h_loc.y > -64) {
                    h_loc.y -= 200
                } else {
                    break
                }
            }
            height *= 3.2808//10フィート1ステップ

            //飛行機用アニメーション
            //タコメーター(1%刻み)
            playAni(ent, "e_" + eng_pow_int, "ani_mtc_plane_e")

            //速度(1,5,10kt刻みをサポート)
            playAni(ent, "v_" + Math.trunc(v / 10) * 10, "ani_mtc_plane_v")
            playAni(ent, "v_" + Math.trunc(v / 5) * 5, "ani_mtc_plane_v")
            playAni(ent, "v_" + Math.trunc(v), "ani_mtc_plane_v")

            //これらは10,50,100,500ft刻みのアニメーションをサポート
            //高度(ft)
            playAni(ent, "a_" + Math.trunc(altitude / 500) * 500, "ani_mtc_plane_a")
            playAni(ent, "a_" + Math.trunc(altitude / 100) * 100, "ani_mtc_plane_a")
            playAni(ent, "a_" + Math.trunc(altitude / 50) * 50, "ani_mtc_plane_a")
            playAni(ent, "a_" + Math.trunc(altitude / 10) * 10, "ani_mtc_plane_a")
            //高さ(ft)
            playAni(ent, "h_" + Math.trunc(height / 500) * 500, "ani_mtc_plane_h")
            playAni(ent, "h_" + Math.trunc(height / 100) * 100, "ani_mtc_plane_h")
            playAni(ent, "h_" + Math.trunc(height / 50) * 50, "ani_mtc_plane_h")
            playAni(ent, "h_" + Math.trunc(height / 10) * 10, "ani_mtc_plane_h")


            //方位(1,2,5degree刻みをサポート)
            playAni(ent, "d_" + Math.trunc(dir / 5) * 5, "ani_mtc_plane_h")
            playAni(ent, "d_" + Math.trunc(dir / 2) * 2, "ani_mtc_plane_h")
            playAni(ent, "d_" + Math.trunc(dir), "ani_mtc_plane_h")

            /*            console.warn(Math.round(dir))
                        console.warn(Math.trunc(ent.getDynamicProperty("mtc_dx")))
                        console.warn(Math.trunc(ent.getDynamicProperty("mtc_dy")))
                        console.warn(Math.trunc(height / 10) * 10)
                        console.warn(Math.trunc(height / 50) * 50)
            */
            //姿勢pitch(x, degree)
            playAni(ent, "p_" + Math.trunc(-ent.getDynamicProperty("mtc_dx")), "ani_mtc_p")
            //姿勢roll(y, degree)
            playAni(ent, "r_" + Math.trunc(ent.getDynamicProperty("mtc_dy")), "ani_mtc_r")

            //ATC(サブカスタムメーター)
            // 1,2,5刻みをサポート
            if (atc_v < 0) {
                if (getState(ent, "disable_atc") !== 1) {
                    setState(ent, "disable_atc", 1)
                    stopAni(ent, "mtc_anicon_atc_meter")
                }
            } else {
                setState(ent, "disable_atc", 0)
                playAni(ent, "atc_" + Math.trunc(atc_v / 5) * 5, "mtc_anicon_atc_meter")
                playAni(ent, "atc_" + Math.trunc(atc_v / 2) * 2, "mtc_anicon_atc_meter")
                playAni(ent, "atc_" + Math.trunc(atc_v), "mtc_anicon_atc_meter")
            }

            //飛行機用エンジン音源
            //world.playSound(name+"_a"+eng_pow_int,ent.location,{volume:512})
            ent.runCommand(`playsound ${name}_a${eng_pow_int} @a[r=100] ~~~ 512`)

        }
    }

}, 5);

//毎tick実行
const run_entity_interfaec = { families: ["mtc_body"] }
let count_g = 0
system.runInterval(() => {

    const section_scale = scale_g
    count_g++

    for (const ent of bodies_g) {
        if (ent.hasTag("mtc_parent")) {
            //const sf_ents = getFormation(ent)
            let sf_ents = bodies_sfs_g[ent.id]
            if (sf_ents === undefined) sf_ents = []

            //加速演算
            if (!ent.hasTag("mtc_norail")) {
                const unit_ch = 0.2 * section_scale
                const prev_spd2k = obj_mtc_spd.getScore(ent)
                const prev_not = obj_mtc_prenot.getScore(ent)
                const init_not = obj_mtc_not.getScore(ent)
                let not = init_not
                let spd2k = prev_spd2k
                if (!ent.hasTag("mtc_tasc_do")) {
                    const ato_v = obj_mtc_ato.getScore(ent)
                    if (ato_v < 0) {
                        let zero_inv_flag = false
                        let acc
                        const accN = obj_mtc_accN.getScore(ent)
                        if (not > 0) {
                            let racc = not * obj_accDA.getScore(ent)
                            const rspd = obj_mtc_Rspd.getScore(ent)
                            if (rspd > 0 && spd2k > rspd) {
                                racc = rspd * racc / spd2k
                            }
                            acc = racc + accN
                        } else if (not < 0) {
                            if (prev_spd2k < 0) {
                                acc = - not * obj_accDB.getScore(ent) + accN
                                zero_inv_flag = true
                            } else if (prev_spd2k > 0) {
                                acc = not * obj_accDB.getScore(ent) + accN
                            } else {
                                acc = 0
                            }
                        } else {
                            if (prev_spd2k < 0) {
                                if (world.getDynamicProperty("mtc_resist_off") === 1) {
                                    acc = 0
                                } else {
                                    acc = -accN
                                }
                                zero_inv_flag = true
                            } else if (prev_spd2k > 0) {
                                if (world.getDynamicProperty("mtc_resist_off") === 1) {
                                    acc = 0
                                } else {
                                    acc = accN
                                }
                            } else {
                                acc = 0
                            }
                        }
                        spd2k += acc * unit_ch
                        if (not <= 0) {
                            if (zero_inv_flag) {
                                if (spd2k > 0) spd2k = 0
                            } else {
                                if (spd2k < 0) spd2k = 0
                            }
                        }
                        if (not === 0) {
                            if (obj_mtc_gradacc.hasParticipant(ent) && world.getDynamicProperty("mtc_resist_off") !== 1) {
                                spd2k += obj_mtc_gradacc.getScore(ent) * unit_ch
                            }
                        }
                        if (obj_mtc_ats.getScore(ent) >= 0) {
                            if (Math.abs(spd2k) >= obj_mtc_ats.getScore(ent) - 1000 && not > 0) {
                                not = 0
                            }
                            if (Math.abs(spd2k) > obj_mtc_ats.getScore(ent)) {
                                not = obj_notBM.getScore(ent)
                            }
                        }

                    } else {
                        //ATO
                        if (spd2k < ato_v) {
                            const notAM = obj_notAM.getScore(ent)
                            spd2k += unit_ch * (obj_accDA.getScore(ent) * notAM + obj_mtc_accN.getScore(ent))
                            if (spd2k > ato_v) spd2k = ato_v
                            not = notAM
                        } else if (spd2k > ato_v) {
                            const notBM = obj_notBM.getScore(ent)
                            spd2k += unit_ch * ((obj_accDB.getScore(ent) + 1) * notBM + obj_mtc_accN.getScore(ent))
                            if (spd2k < ato_v) spd2k = ato_v
                            not = notBM + 1
                        } else {
                            not = 0
                        }
                    }

                }
                if (init_not !== not) {
                    //ATS/ATOによる変更
                    for (const ent_f of sf_ents) {
                        ent.addTag("mtc_mas_v2")
                    }
                }
                if (prev_not !== not) {
                    //変更全般
                    if (prev_not < 0 && not >= 0) {
                        //ブレーキ緩解
                        if (Math.abs(prev_spd2k) < 1000) {
                            for (const ent_f of sf_ents) {
                                ent_f.addTag("mtc_air1")
                            }
                        } else {
                            for (const ent_f of sf_ents) {
                                ent_f.addTag("mtc_air2")
                            }
                        }
                    }

                }
                if (ent.hasTag("mtc_manual")) {
                    if (spd2k > 260000) spd2k = 260000
                    if (spd2k < -260000) spd2k = -260000
                }
                const spd2kmax = obj_maxSpd.getScore(ent)
                if (spd2k > spd2kmax) spd2k = spd2kmax
                if (spd2k < -spd2kmax) spd2k = -spd2kmax
                obj_mtc_spd.setScore(ent, Math.round(spd2k))
                obj_mtc_prenot.setScore(ent, not)
                obj_mtc_not.setScore(ent, not)
            }

            //拡張サウンドエンジン
            if ((!ent.hasTag("mtc_norail")) && (count_g % 2 == 0)) {
                const not = obj_mtc_not.getScore(ent)
                const notBM = obj_notBM.getScore(ent)
                const v = Math.abs(Math.round(obj_mtc_spd.getScore(ent) / 200))//km/h*10
                for (const ent_f of sf_ents) {
                    if (ent_f.hasTag("mtc_soundengine2")) {
                        const name2 = getIdBase(ent_f.typeId)
                        testSound(ent_f)
                        if (not == 0 || not == notBM) {
                            if (!(not == notBM && ent_f.hasTag("mtc_bus"))) ent_f.runCommand(`playsound ${name2}_n${v} @a[r=96,scores={mtc_sid=0}] ^^^${ent_f.getDynamicProperty("mtc_body_length") / 2} 64`);
                        } else if (not > 0) {
                            ent_f.runCommand(`playsound ${name2}_a${v} @a[r=96,scores={mtc_sid=0}] ^^^${ent_f.getDynamicProperty("mtc_body_length") / 2} 64`)
                        } else {
                            ent_f.runCommand(`playsound ${name2}_b${v} @a[r=96,scores={mtc_sid=0}] ^^^${ent_f.getDynamicProperty("mtc_body_length") / 2} 64`)
                        }
                    }
                }
            }

            //先頭車
            if (!ent.hasTag("mtc_norail")) {
                const spd2k = obj_mtc_spd.getScore(ent)
                const mv_delta = 0.000006944445 * spd2k * section_scale

                //TASC
                if (ent.hasTag("mtc_tasc")) {
                    const diff = (ent.getDynamicProperty("tasc_dist") - ent.getDynamicProperty("dist"))
                    if (diff > 0) {
                        const b_mid = ent.getDynamicProperty("tasc_b_mid")//常用最大
                        const trg_mid = Math.sqrt(diff * b_mid * 0.8) * 240
                        const now_spd = obj_mtc_spd.getScore(ent)

                        if (now_spd >= trg_mid) {
                            ent.addTag("mtc_tasc_do")
                            obj_mtc_ato.setScore(ent, -1)
                        }

                        if (ent.hasTag("mtc_tasc_do")) {
                            let trg_spd = trg_mid
                            let diff = now_spd - trg_spd
                            if (diff < 0) {
                                diff = 0.0
                            } else if (diff * 5 > b_mid) {
                                diff = b_mid / 5.0
                            }
                            trg_spd = now_spd - diff * section_scale

                            if (trg_spd <= 1000 / section_scale) {
                                obj_mtc_spd.setScore(ent, 1000 / section_scale)
                                obj_mtc_not.setScore(ent, -1)
                            } else {
                                obj_mtc_spd.setScore(ent, trg_spd)
                                obj_mtc_not.setScore(ent, Math.min(-1, Math.trunc((world.scoreboard.getObjective("mtc_notBM").getScore(ent) + 1) * diff * 5 / b_mid)))
                            }
                        }
                    } else {
                        //解除
                        if (obj_mtc_spd.getScore(ent) <= 2000) {
                            obj_mtc_spd.setScore(ent, 0)
                            obj_mtc_not.setScore(ent, world.scoreboard.getObjective("mtc_notBM").getScore(ent) + 1)
                        } else {
                            obj_mtc_not.setScore(ent, world.scoreboard.getObjective("mtc_notBM").getScore(ent))
                        }
                        ent.removeTag("mtc_tasc")
                        ent.removeTag("mtc_tasc_do")
                    }
                }


                //鉄道走行演算
                if (spd2k !== 0 || count_g % 10 == 0) {
                    const prev_uvec = getState(ent, "mtc_prev_uvec")
                    if (ent.hasTag("mtc_on_newrail_b") && ent.hasTag("mtc_on_newrail_h") && prev_uvec !== undefined) {
                        let new_loc = {
                            x: ent.location.x + mv_delta * prev_uvec.x,
                            y: ent.location.y + mv_delta * prev_uvec.y,
                            z: ent.location.z + mv_delta * prev_uvec.z
                        }
                        ent.teleport(new_loc)
                    } else {
                        let roty = ent.getRotation().y
                        let rotx = getState(ent, "mtc_tilt_x")
                        if (rotx === undefined) rotx = 0

                        rotx *= -1
                        roty *= -1
                        const bx_uz = Math.sin(0.0174533 * roty) * Math.cos(0.0174533 * rotx)
                        const by_uz = -Math.sin(0.0174533 * rotx)
                        const bz_uz = Math.cos(0.0174533 * roty) * Math.cos(0.0174533 * rotx)
                        let sign = 1
                        if (ent.hasTag("mtc_rev")) {
                            sign *= -1
                        }
                        let new_loc = {
                            x: ent.location.x + mv_delta * bx_uz * sign,
                            y: ent.location.y + mv_delta * by_uz * sign,
                            z: ent.location.z + mv_delta * bz_uz * sign
                        }
                        ent.teleport(new_loc)
                    }

                    //seat追従
                    if (world.getDynamicProperty("mtc_tilt") === 1) {
                        let rotx = getState(ent, "mtc_tilt_x")
                        let rotz = getState(ent, "mtc_tilt_z")
                        if (rotx === undefined) rotx = 0
                        if (rotz === undefined) rotz = 0
                        rotz *= -1
                        const buz = Math.sin(0.0174533 * rotx)
                        const bux = Math.sin(0.0174533 * rotz)
                        const com = ent.getComponent("minecraft:rideable")
                        if (com !== undefined) {
                            const seats = com.getSeats()
                            const riders = com.getRiders()
                            for (let i = 0; i < seats.length; i++) {
                                const rider = riders[i]
                                if (rider !== undefined && rider.typeId == "mtc:seat") {
                                    const seat = seats[i]
                                    const dy = seat.position.z * buz + seat.position.x * bux
                                    let index = Math.round(dy * 64)
                                    if (index < -256) index = -256
                                    if (index > 256) index = 256
                                    const index_old = getState(rider, "mtc_tilt_old")
                                    if (index !== index_old) {
                                        setState(rider, "mtc_tilt_old", index)
                                        if (index >= 0) {
                                            rider.triggerEvent("ev_p" + index)
                                        } else {
                                            rider.triggerEvent("ev_m" + (-index))
                                        }
                                    }
                                }

                            }
                        }
                    }


                    let joint_min = 0     //各車両が検出したジョイント間隔の最小値(0は無検出)
                    let sign = 1
                    if (ent.hasTag("mtc_rev")) {
                        sign *= -1
                    }

                    for (const entf of sf_ents) {
                        //付随車移動
                        if (!entf.hasTag("mtc_parent")) {
                            let roty = entf.getRotation().y
                            let rotx = getState(entf, "mtc_tilt_x")
                            if (rotx === undefined) rotx = 0
                            rotx *= -1
                            roty *= -1
                            const bx_uz = Math.sin(0.0174533 * roty) * Math.cos(0.0174533 * rotx)
                            const by_uz = -Math.sin(0.0174533 * rotx)
                            const bz_uz = Math.cos(0.0174533 * roty) * Math.cos(0.0174533 * rotx)

                            const new_loc = {
                                x: entf.location.x + mv_delta * bx_uz * sign,
                                y: entf.location.y + mv_delta * by_uz * sign,
                                z: entf.location.z + mv_delta * bz_uz * sign
                            }
                            entf.teleport(new_loc)
                            setState(entf, "mtc_prev", new_loc)

                            //seat追従
                            if (world.getDynamicProperty("mtc_tilt") === 1) {
                                rotx = getState(entf, "mtc_tilt_x")
                                let rotz = getState(entf, "mtc_tilt_z")
                                if (rotx === undefined) rotx = 0
                                if (rotz === undefined) rotz = 0
                                rotz *= -1
                                const buz = Math.sin(0.0174533 * rotx)
                                const bux = Math.sin(0.0174533 * rotz)
                                const com = entf.getComponent("minecraft:rideable")
                                if (com !== undefined) {
                                    const seats = com.getSeats()
                                    const riders = com.getRiders()
                                    for (let i = 0; i < seats.length; i++) {
                                        const rider = riders[i]
                                        if (rider !== undefined && rider.typeId == "mtc:seat") {
                                            const seat = seats[i]
                                            const dy = seat.position.z * buz + seat.position.x * bux
                                            let index = Math.round(dy * 64)
                                            if (index < -256) index = -256
                                            if (index > 256) index = 256
                                            const index_old = getState(rider, "mtc_tilt_old")
                                            if (index !== index_old) {
                                                setState(rider, "mtc_tilt_old", index)
                                                if (index >= 0) {
                                                    rider.triggerEvent("ev_p" + index)
                                                } else {
                                                    rider.triggerEvent("ev_m" + (-index))
                                                }
                                            }
                                        }

                                    }
                                }
                            }

                            //測距
                            let now = entf.getDynamicProperty("dist")
                            if (now === undefined) {
                                now = 0.0
                            }
                            now += mv_delta
                            entf.setDynamicProperty("dist", now)

                            //ジョイント
                            let joint = entf.getDynamicProperty("mtc_joint")
                            if (joint > 0) {
                                joint = Number(joint)
                                if (joint_min === 0 || joint_min > joint) {
                                    joint_min = joint
                                }
                            }

                        }
                    }

                    let now = ent.getDynamicProperty("dist")
                    if (now === undefined) {
                        now = 0.0
                    }
                    now += mv_delta
                    ent.setDynamicProperty("dist", now)
                    obj_mtc_dist.setScore(ent, Math.round(now * 100))

                    //ジョイント
                    let joint = ent.getDynamicProperty("mtc_joint")
                    let joint_last_dist = ent.getDynamicProperty("mtc_joint_last_dist")
                    let is_joint = false
                    if (joint > 0) {
                        joint = Number(joint)
                        if (joint_min === 0 || joint_min > joint) {
                            joint_min = joint
                        }
                        if (joint_last_dist === undefined) {
                            ent.setDynamicProperty("mtc_joint_last_dist", now)
                            is_joint = true
                        } else {
                            joint_last_dist = Number(joint_last_dist)
                            const diff = now - joint_last_dist
                            if (diff >= joint_min) {
                                is_joint = true
                                if (diff < joint_min * 2) {
                                    ent.setDynamicProperty("mtc_joint_last_dist", joint_last_dist + joint_min)
                                } else {
                                    ent.setDynamicProperty("mtc_joint_last_dist", now)
                                }
                            }
                        }
                        if (is_joint) {
                            runJoint(ent, sf_ents)
                        }
                    }

                    trace_newrail(ent, sf_ents)
                    setState(ent, "mtc_prev", ent.location)


                } else {
                    let mtc_prev = getState(ent, "mtc_prev")
                    if (mtc_prev === undefined) {
                        mtc_prev = { x: ent.location.x, y: ent.location.y, z: ent.location.z }
                        setState(ent, "mtc_prev", mtc_prev)
                    }
                    //                if (dist2(ent.location, mtc_prev) > 0) {
                    if (ent.hasTag("mtc_on_newrail_b") || obj_mtc_rot.getScore(ent) <= 10) {
                        //振動抑制位置固定
                        let nx, nz
                        switch (count_g % 4) {
                            case 0:
                                nz = 0.002
                                nx = 0.002
                                break
                            case 1:
                                nz = 0.002
                                nx = -0.002
                                break
                            case 2:
                                nz = -0.002
                                nx = -0.002
                                break
                            case 3:
                                nz = -0.002
                                nx = 0.002
                                break
                        }
                        const loc_e = { x: mtc_prev.x + nx, y: mtc_prev.y + Math.random() * 0.001, z: mtc_prev.z + nz }
                        ent.teleport(loc_e, { rotation: ent.getRotation() })
                    } else {
                        setState(ent, "mtc_prev", ent.location)
                    }
                }

                let new_loc = ent.location
                let mtc_car = ent.dimension.getEntities({ families: ["mtc_car", "mtc_runnable"], location: new_loc, closest: 1 })
                if (mtc_car.length > 0) {
                    new_loc.y -= 2.3
                    mtc_car[0].teleport(new_loc)
                }


            } else if (ent.hasTag("mtc_plane")) {
                //飛行機計算    

                //飛行機視線取得(相対)
                let rider_res = undefined
                const riders_cp = ent.getComponent("minecraft:rideable")
                if (riders_cp !== undefined) {
                    const riders = riders_cp.getRiders()
                    if (riders.length > 0) {
                        const rider = riders[0]
                        if (rider.typeId == "minecraft:player") {
                            rider_res = rider
                        } else if (rider.typeId !== "mtc:seat") {
                            const riders = rider.getComponent("minecraft:rideable").getRiders()
                            if (riders.length > 0) {
                                const rider = riders[0]
                                if (rider.typeId == "minecraft:player") {
                                    rider_res = rider
                                }
                            }
                        }
                    }
                }
                if (rider_res !== undefined) {
                    const prot = rider_res.getRotation()
                    const erot = ent.getRotation()
                    let rx = prot.x - erot.x
                    let ry = prot.y - erot.y
                    if (ry > 180)
                        ry -= 360;
                    if (ry < -180)
                        ry += 360;
                    setState(ent, "mtc_rx", rx)
                    setState(ent, "mtc_ry", ry)
                } else {
                    setState(ent, "mtc_rx", 0.0)
                    setState(ent, "mtc_ry", 0.0)
                }

                //高度計算
                let height = 1000.0
                const ublock = ent.dimension.getBlockFromRay(ent.location, { x: 0, y: -1, z: 0 })
                if (ublock !== undefined) {
                    height = ent.location.y - ublock.block.y - 1
                }

                //スロットル計算
                let not = obj_not.getScore(ent)
                const notAM = world.scoreboard.getObjective("mtc_notAM").getScore(ent)
                const notBM = world.scoreboard.getObjective("mtc_notBM").getScore(ent)


                let trg_pow = 0.0
                if (not >= 0) {
                    trg_pow = 20 + 80 * Math.max(0, not) / notAM
                } else {
                    //制動方向に入れてる場合逆噴射のみ許可
                    if (ent.hasTag("mtc_rev")) {
                        trg_pow = 20 - 80 * Math.max(0, -not) / (notBM + 1)
                    } else {
                        trg_pow = 20
                    }
                }

                if (not === notBM)
                    trg_pow = 0.0

                let now_pow = ent.getDynamicProperty("mtc_engine")
                if (now_pow === undefined)
                    now_pow = 0.0
                let diff = trg_pow - now_pow

                if (now_pow < 20) {
                    if (diff > 0.2)
                        diff = 0.2;
                    if (diff < -0.2)
                        diff = -0.2;
                } else {
                    if (diff > 3)
                        diff = 3;
                    if (diff < -3)
                        diff = -3;
                }
                now_pow += diff
                if (now_pow < 0)
                    now_pow = 0.0;
                if (now_pow > 100)
                    now_pow = 100.0;

                ent.setDynamicProperty("mtc_engine", now_pow)

                let now_bz
                let n_bz
                let p1, p2, p3
                let now_t
                //オートパイロット終了判定
                if (ent.hasTag("mtc_autopirot")) {
                    now_bz = ent.getDynamicProperty("mtc_autopirot_now")
                    n_bz = ent.getDynamicProperty("mtc_autopirot_n")

                    p1 = ent.getDynamicProperty("mtc_autopirot_bz" + now_bz + "p1")
                    p2 = ent.getDynamicProperty("mtc_autopirot_bz" + now_bz + "p2")
                    p3 = ent.getDynamicProperty("mtc_autopirot_bz" + now_bz + "p3")

                    now_t = getBezierNeart(p1, p2, p3, ent.location)
                    ent.removeTag("mtc_rev")

                    if (now_t >= 1 && now_bz === n_bz - 1) {
                        ent.removeTag("mtc_autopirot")
                        not = notBM + 1
                        obj_not.setScore(ent, not)
                        ent.addTag("mtc_rev")

                    }
                }

                //オートパイロット本体
                if (ent.hasTag("mtc_autopirot")) {
                    if (now_t >= 1) {
                        if (now_bz < n_bz - 1) {
                            now_bz++
                            ent.setDynamicProperty("mtc_autopirot_now", now_bz)
                            p1 = ent.getDynamicProperty("mtc_autopirot_bz" + now_bz + "p1")
                            p2 = ent.getDynamicProperty("mtc_autopirot_bz" + now_bz + "p2")
                            p3 = ent.getDynamicProperty("mtc_autopirot_bz" + now_bz + "p3")

                            now_t = getBezierNeart(p1, p2, p3, ent.location)
                        }

                    }

                    //機体向きベクトル
                    const dir = bezierTangent(p1, p2, p3, now_t)
                    const dir_size = Math.sqrt(dir.x ** 2 + dir.y ** 2 + dir.z ** 2)
                    const dir_n = { x: dir.x / dir_size, y: dir.y / dir_size, z: dir.z / dir_size }
                    //回転x,y計算
                    const ry = Math.atan2(-dir_n.x, dir_n.z) * 57.29578
                    const rx = -Math.asin(dir_n.y) * 57.29578

                    //速度計算

                    //推力計算
                    let now_spd2k = obj_mtc_spd.getScore(ent)

                    let engine_out = (now_pow - 20) * 1.25
                    if (engine_out < 0)
                        engine_out = 0;
                    if (ent.hasTag("mtc_rev"))
                        engine_out *= -0.5

                    let acc = engine_out * obj_accDA.getScore(ent) * 0.01
                    let brk = obj_mtc_accN.getScore(ent)//<0

                    //走行抵抗(飛ぶと無くなる)
                    if (height < 0.01) {
                        if (now_spd2k + acc >= -brk) {
                            acc += brk
                        } else if (now_spd2k + acc <= brk) {
                            acc -= brk
                        } else {
                            acc -= now_spd2k + acc
                        }
                    }

                    //ブレーキ(空中でも制動がいる)
                    //空中のブレーキは最大空気抵抗(フラップの空気抵抗増大をシミュレーション)
                    if (not < 0) {
                        if (height < 0.01) {
                            brk = obj_accDB.getScore(ent) * not
                            if (now_spd2k + acc >= -brk) {
                                acc += brk
                            } else if (now_spd2k + acc <= brk) {
                                acc -= brk
                            } else {
                                acc -= now_spd2k + acc
                            }
                        } else {
                            acc -= (100 * ((now_spd2k / 2000) * obj_mtc_air.getScore(ent) / 100000) ** 2) * (not / (notBM + 1))
                        }
                    }


                    //空気抵抗
                    acc -= 100 * ((now_spd2k / 2000) * obj_mtc_air.getScore(ent) / 100000) ** 2

                    //速度計算
                    const spdMax = obj_maxSpd.getScore(ent)
                    now_spd2k += acc

                    if (now_spd2k > spdMax)
                        now_spd2k = spdMax;

                    if (now_spd2k < -spdMax)
                        now_spd2k = -spdMax;

                    //距離計算
                    let dist = 0
                    for (let i = n_bz - 1; i > now_bz; i--) {
                        const p1x = ent.getDynamicProperty("mtc_autopirot_bz" + i + "p1")
                        const p2x = ent.getDynamicProperty("mtc_autopirot_bz" + i + "p2")
                        const p3x = ent.getDynamicProperty("mtc_autopirot_bz" + i + "p3")
                        dist += bezierLength(p1x, p2x, p3x, 0, 1)
                    }

                    dist += bezierLength(p1, p2, p3, now_t, 1)


                    //速度制御
                    //減速度1m/s^2固定
                    const v0 = obj_mtc_Rspd.getScore(ent) / 3.6//m/s
                    const vmax = Math.sqrt(2 * dist + v0 ** 2) * 7200//v=sqrt(2ax+v0^2) (kmph*2000)


                    if (now_spd2k > vmax) {
                        now_spd2k = vmax
                        not = 0
                    } else {
                        not = Math.trunc(notAM * 0.9)
                    }

                    obj_not.setScore(ent, not)

                    const v = 0.000006944445 * now_spd2k

                    const next_t = getBezierNeart(p1, p2, p3, { x: ent.location.x + dir_n.x * v, y: ent.location.y + dir_n.y * v, z: ent.location.z + dir_n.z * v })
                    const p_trg = getBezier(p1, p2, p3, next_t)
                    const rot = ent.getRotation()
                    ent.teleport(p_trg, { rotation: { x: rx, y: ry } })

                    obj_mtc_spd.setScore(ent, Math.trunc(now_spd2k))


                    if (height < 0.01) {
                        ent.setDynamicProperty("mtc_dy", 0)
                        ent.setDynamicProperty("mtc_dx", 0)
                    } else {
                        ent.setDynamicProperty("mtc_dy", (ry - rot.y) * 10)
                        ent.setDynamicProperty("mtc_dx", -rx)
                    }
                } else {

                    //推力計算
                    let now_spd2k = obj_mtc_spd.getScore(ent)

                    let engine_out = (now_pow - 20) * 1.25
                    if (engine_out < 0)
                        engine_out = 0;
                    if (ent.hasTag("mtc_rev"))
                        engine_out *= -0.5

                    let acc = engine_out * obj_accDA.getScore(ent) * 0.01
                    let brk = obj_mtc_accN.getScore(ent)//<0

                    //走行抵抗(飛ぶと無くなる)
                    if (height < 0.01) {
                        if (now_spd2k + acc >= -brk) {
                            acc += brk
                        } else if (now_spd2k + acc <= brk) {
                            acc -= brk
                        } else {
                            acc -= now_spd2k + acc
                        }
                    }

                    //ブレーキ(空中でも制動がいる)
                    //空中のブレーキは最大空気抵抗(フラップの空気抵抗増大をシミュレーション)
                    if (not < 0) {
                        if (height < 0.01) {
                            brk = obj_accDB.getScore(ent) * not
                            if (now_spd2k + acc >= -brk) {
                                acc += brk
                            } else if (now_spd2k + acc <= brk) {
                                acc -= brk
                            } else {
                                acc -= now_spd2k + acc
                            }
                        } else {
                            acc -= (100 * ((now_spd2k / 2000) * obj_mtc_air.getScore(ent) / 100000) ** 2) * (not / (notBM + 1))
                        }
                    }


                    //空気抵抗
                    acc -= 100 * ((now_spd2k / 2000) * obj_mtc_air.getScore(ent) / 100000) ** 2

                    //速度計算
                    const spdMax = obj_maxSpd.getScore(ent)
                    now_spd2k += acc

                    if (now_spd2k > spdMax)
                        now_spd2k = spdMax;

                    if (now_spd2k < -spdMax)
                        now_spd2k = -spdMax;

                    //回転
                    const now_rot = ent.getRotation()
                    let dx = getState(ent, "mtc_rx")
                    let dy = getState(ent, "mtc_ry") * 0.1
                    if (dy > 4)
                        dy = 4;
                    if (dy < -4)
                        dy = -4;
                    if (now_spd2k > 1 || now_spd2k < -1) {
                        //ent.setRotation({ x: 0, y: dy + now_rot.y })
                        ent.teleport(ent.location, { rotation: { x: 0, y: dy + now_rot.y } })
                    } else {
                        dy = 0
                    }

                    //昇降計算
                    const up_spd_2k = Math.sin(-dx * 0.0174533) * now_spd2k
                    //m/tick
                    let up_spd = 0.000006944445 * up_spd_2k//m/tick
                    const up_spd_max = 0.0005 * obj_mtc_up.getScore(ent) * (now_spd2k / 2000 - obj_mtc_Rspd.getScore(ent))

                    up_spd = Math.min(up_spd, up_spd_max)
                    up_spd = Math.max(up_spd, -height, -50)

                    //正面衝突判定
                    if (now_spd2k > 0) {
                        const fblock = ent.dimension.getBlockFromRay({ x: ent.location.x, y: ent.location.y + 1.5, z: ent.location.z }, { x: -Math.sin((dy + now_rot.y) * 0.0174533), y: 0, z: Math.cos((dy + now_rot.y) * 0.0174533) })
                        if (fblock !== undefined) {
                            const d = (ent.location.z - fblock.block.z - 0.5) ** 2 + (ent.location.x - fblock.block.x - 0.5) ** 2
                            if (d < (0.000006944445 * now_spd2k + 1) ** 2) {
                                now_spd2k = 0
                            }
                        }
                    } else if (now_spd2k < 0) {
                        const fblock = ent.dimension.getBlockFromRay({ x: ent.location.x, y: ent.location.y + 1.5, z: ent.location.z }, { x: Math.sin((dy + now_rot.y) * 0.0174533), y: 0, z: -Math.cos((dy + now_rot.y) * 0.0174533) })
                        if (fblock !== undefined) {
                            const d = (ent.location.z - fblock.block.z - 0.5) ** 2 + (ent.location.x - fblock.block.x - 0.5) ** 2
                            if (d < (0.000006944445 * (-now_spd2k) + 1) ** 2) {
                                now_spd2k = 0
                            }
                        }
                    }

                    //飛行計算
                    now_spd2k = Math.trunc(now_spd2k * 1000) / 1000
                    const mv_delta = 0.000006944445 * now_spd2k
                    /*
                    const rot_y = ent.getRotation().y
                    const mv_delta_x = -mv_delta * Math.sin(rot_y * 0.0174533)
                    const mv_delta_z = mv_delta * Math.cos(rot_y * 0.0174533)
                    const new_loc = { x: ent.location.x + mv_delta_x, y: ent.location.y + up_spd, z: ent.location.z + mv_delta_z }

                    ent.teleport(new_loc)
                    */
                    ent.runCommand(`tp @s ^^${up_spd}^${mv_delta}`)
                    obj_mtc_spd.setScore(ent, Math.trunc(now_spd2k))

                    if (height < 0.01) {
                        ent.setDynamicProperty("mtc_dy", 0)
                        ent.setDynamicProperty("mtc_dx", 0)
                    } else {
                        ent.setDynamicProperty("mtc_dy", dy * 10)
                        ent.setDynamicProperty("mtc_dx", -dx)
                    }

                }

            }

            //マスコンアニメーション
            // 実行主mtc_fidと同じmtc_fidを持つ車体を取得

            if (ent.hasTag("mtc_mas_v2") || ent.hasTag("mtc_mode_v2")) {
                if (ent.hasTag("mtc_mas_v2")) {
                    ent.removeTag("mtc_mas_v2")
                    const not = obj_not.getScore(ent)
                    for (const ent_f of sf_ents) {
                        //マスコンアニメーション
                        if (not < 0) {
                            playAni(ent_f, "mas_b" + (-not), "mtc_anicon_mas")
                        } else if (not > 0) {
                            playAni(ent_f, "mas_p" + not, "mtc_anicon_mas")
                        } else {
                            playAni(ent_f, "mas_nc", "mtc_anicon_mas")
                        }
                    }
                }
                if (ent.hasTag("mtc_mode_v2")) {
                    ent.removeTag("mtc_mode_v2")
                    const mtc_maku = obj_mtc_maku.getScore(ent)
                    for (const ent_f of sf_ents) {
                        //幕イベント発生
                        //playAni(ent_f, "mode" + (mtc_maku + 1), "mtc_anicom_maku")
                        try {
                            ent_f.triggerEvent("mode" + (mtc_maku + 1))
                        } catch (e) { }
                    }
                }

            }
        } else {
            //付随車補正
            if (!ent.hasTag("mtc_norail")) {
                //付随車方向制御
                const parents = bodies_g
                let parent = undefined
                let master = undefined
                let b1 = false
                let b2 = false
                for (const p of parents) {
                    if (obj_mtc_uid.getScore(p) === obj_mtc_parent.getScore(ent)) {
                        parent = p
                        b1 = true
                    }
                    if (obj_mtc_uid.getScore(p) === obj_mtc_fid.getScore(ent)) {
                        master = p
                        b2 = true
                    }
                    if (b1 && b2) break
                }
                if (parent !== undefined && master !== undefined) {
                    if (Math.abs(obj_mtc_spd.getScore(master)) > 0) {
                        //方向追従
                        const loc_e = ent.location
                        const loc_p = parent.location
                        const deg_y = Math.atan2(-(loc_p.x - loc_e.x), loc_p.z - loc_e.z) * 57.29578
                        const deg_y2 = getState(ent, "midcar_trace_deg")
                        //ent.setRotation({ x: 0, y: deg_y })
                        if (deg_y2 !== undefined && Math.abs(deg_y2 - deg_y) < 20) {
                            ent.teleport(loc_e, { rotation: { x: 0, y: deg_y2 } })
                        } else {
                            ent.teleport(loc_e, { rotation: { x: 0, y: deg_y } })
                        }
                    } else {
                        //振動抑制
                        let nx, nz
                        switch (count_g % 4) {
                            case 0:
                                nz = 0.002
                                nx = 0.002
                                break
                            case 1:
                                nz = 0.002
                                nx = -0.002
                                break
                            case 2:
                                nz = -0.002
                                nx = -0.002
                                break
                            case 3:
                                nz = -0.002
                                nx = 0.002
                                break
                        }
                        const loc_e = { x: ent.location.x + nx, y: ent.location.y + Math.random() * 0.001, z: ent.location.z + nz }
                        ent.teleport(loc_e)
                    }

                }

            }

        }

    }

}, 1)


system.afterEvents.scriptEventReceive.subscribe((event) => {
    let { id, message, sourceEntity, sourceBlock, sourceType } = event;
    let initiator = undefined
    if (message.slice(0, 1) === "\"" && message.slice(-1) === "\"") {
        message = message.slice(1, -1)
    }

    if (sourceType == "Entity" || sourceType == "Block" || sourceType == "NPCDialogue") {
        initiator = sourceEntity
        let x, y, z, dim
        let org_loc

        if (sourceType == "Entity" || sourceType == "NPCDialogue") {
            dim = sourceEntity.dimension
            x = sourceEntity.location.x
            y = sourceEntity.location.y
            z = sourceEntity.location.z
            org_loc = sourceEntity.location

            //乗務確認
            if (sourceEntity.typeId == "minecraft:player") {
                sourceEntity.runCommand("function mtc/testBoard")
                sourceEntity.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_calcj1 = @s mtc_calc1")
                const jomu_ents = getSelectorEntities("@e[family=mtc_body,tag=mtc_parent,scores={mtc_calc1=0},c=1]", sourceEntity)

                if (jomu_ents.length > 0) {
                    const jomu_ent = jomu_ents[0]
                    x = jomu_ent.location.x
                    y = jomu_ent.location.y
                    z = jomu_ent.location.z
                }
            }

        } else if (sourceType == "Block") {
            initiator = sourceBlock
            dim = sourceBlock.dimension
            x = sourceBlock.location.x
            y = sourceBlock.location.y
            z = sourceBlock.location.z
            org_loc = sourceBlock.location
        }

        const base_bodys = getSelectorEntities2(`@e[x=${x},y=${y},z=${z},family=mtc_body,tag=mtc_parent,c=1]`, dim)

        if (id == "mtc:set_crail_max") {
            world.setDynamicProperty("mtc_clearrail_max_len", Number(message))
            world.sendMessage("Clear Rail Max Distance = " + Number(message))
            world.sendMessage("Default is 16")
        } else if (id == "mtc:antilag_max") {
            world.setDynamicProperty("mtc_max_scale", Number(message))
            world.sendMessage("AntiLag System Max Scale = " + Number(message))
            world.sendMessage("Default is 1")
        } else if (id == "mtc:antilag_scale") {
            world.setDynamicProperty("mtc_scale", Number(message))
            world.sendMessage("AntiLag System Scale (Manual) = " + Number(message))
            world.sendMessage("Default is 0")
        } else if (id == "mtc:setjoint") {
            sourceEntity.setDynamicProperty("mtc_jointsound", message)
        } else if (id == "mtc:summon") {
            const args = message.split(" ")
            const ename = args[0]
            let arg = ""
            if (args.length >= 2) {
                arg = args[1]
                for (let i = 2; i < args.length; i++) {
                    arg += " " + args[i]
                }
            }

            if (args.length >= 2) {
                obj_mtc_global.setScore("dir_preset", 2)
            }
            if (sourceType == "Entity" || sourceType == "NPCDialogue") {
                initiator.runCommand(`summon ${ename} ${arg}`)

            } else if (sourceType == "Block") {
                x += 0.5
                z += 0.5
                dim.runCommand(`execute positioned ${x} ${y} ${z} run summon ${ename} ${arg}`)
            }

        } else if (id == "mtc:inner_body_length") {
            //ダミーprocを先においてそれとの距離を測定
            const ents = dim.getEntities({ type: "mtc:mtc_headloc" })
            let ent_p = undefined
            for (const ent of ents) {
                const sc_ca2 = world.scoreboard.getObjective("mtc_calc2")
                if (obj_mtc_uid.hasParticipant(sourceEntity) && sc_ca2.hasParticipant(ent)) {
                    if (world.scoreboard.getObjective("mtc_calc2").getScore(ent) === obj_mtc_uid.getScore(sourceEntity)) {
                        ent_p = ent
                        break
                    }
                }
            }
            if (ent_p === undefined) {
                sourceEntity.setDynamicProperty("mtc_body_length", 20.0)
            } else {
                sourceEntity.setDynamicProperty("mtc_body_length", dist(sourceEntity.location, ent_p.location))
                ent_p.remove()
            }
            trace_newrail(sourceEntity, getFormation(sourceEntity))
        } else if (id == "mtc:inner_body_length_d") {
            const ents = dim.getEntities({ type: "mtc:mtc_headloc" })
            let ent_p = undefined
            for (const ent of ents) {
                const sc_uid = world.scoreboard.getObjective("mtc_uid")
                const sc_ca2 = world.scoreboard.getObjective("mtc_calc2")

                if (sc_uid.hasParticipant(sourceEntity) && sc_ca2.hasParticipant(ent)) {
                    if (world.scoreboard.getObjective("mtc_calc2").getScore(ent) === world.scoreboard.getObjective("mtc_uid").getScore(sourceEntity) + 1) {
                        ent_p = ent
                        break
                    }
                }
            }
            //台車位置情報は連結先頭以外使えないことに注意
            if (ent_p === undefined) {
                sourceEntity.setDynamicProperty("mtc_d_length", 17.5)
            } else {
                sourceEntity.setDynamicProperty("mtc_d_length", dist(sourceEntity.location, ent_p.location))
                sourceEntity.addTag("mtc_has_dp")
                ent_p.remove()
            }
            trace_newrail(sourceEntity, getFormation(sourceEntity))
        } else if (id == "mtc:conrot") {
            //連結時向き補正
            const ent = getSelectorEntities("@e[family=mtc_body,c=1,tag=mtc_temp_conn]", sourceEntity)[0]
            const rot1 = sourceEntity.getRotation().y
            const rot2 = ent.getRotation().y
            let diff = rot1 - rot2
            if (diff < -90 || diff > 90) {


                const rails = sourceEntity.dimension.getEntities({ families: ["mtc_rail"], location: sourceEntity.location, maxDistance: 40 })
                let min = 1e30
                let m_rail = undefined
                for (const rail of rails) {
                    const p1 = rail.getDynamicProperty("mtc_bz_p1")
                    const p2 = rail.getDynamicProperty("mtc_bz_p2")
                    const p3 = rail.getDynamicProperty("mtc_bz_p3")
                    const t = getBezierNeart(p1, p2, p3, sourceEntity.location)

                    const p = getBezier(p1, p2, p3, t)
                    const d2 = dist2(sourceEntity.location, p)
                    if (d2 < min) {
                        min = d2
                        m_rail = rail
                    }
                }

                //新線路上の場合は反対方向に台車を伸ばす場合の近傍点
                if (min <= 25) {
                    const p1 = m_rail.getDynamicProperty("mtc_bz_p1")
                    const p2 = m_rail.getDynamicProperty("mtc_bz_p2")
                    const p3 = m_rail.getDynamicProperty("mtc_bz_p3")
                    const t = getBezierNeart(p1, p2, p3, sourceEntity.location)
                    const p = getBezier(p1, p2, p3, t)
                    const dir = bezierTangent(p1, p2, p3, t)
                    let deg = Math.atan2(-dir.x, dir.z) * 57.29578
                    let diff = deg - rot2
                    if (diff < -90) {
                        diff += 180
                    }
                    if (diff > 90) {
                        diff -= 180
                    }
                    deg = rot2 + diff

                    sourceEntity.teleport(p)

                    let def_d_length = sourceEntity.getDynamicProperty("mtc_d_length")
                    if (def_d_length === undefined) {
                        sourceEntity.setDynamicProperty("mtc_d_length", def_d_length)
                        def_d_length = 18
                    }
                    let h_min = 1e30
                    let h_rail = undefined
                    let head_loc
                    const n_spl = 0.5 / Math.round(def_d_length)
                    for (let j = n_spl; j <= 1; j += n_spl) {
                        const rot = { x: 0, y: deg }
                        const bx_uz = -Math.sin(0.0174533 * deg)
                        const by_uz = 0
                        const bz_uz = Math.cos(0.0174533 * rot.y)

                        const sx = sourceEntity.location.x + def_d_length * j * bx_uz
                        const sy = sourceEntity.location.y + def_d_length * j * by_uz
                        const sz = sourceEntity.location.z + def_d_length * j * bz_uz
                        head_loc = { x: sx, y: sy, z: sz }

                        h_min = 1e30
                        h_rail = undefined
                        for (const rail of rails) {
                            const p1 = rail.getDynamicProperty("mtc_bz_p1")
                            const p2 = rail.getDynamicProperty("mtc_bz_p2")
                            const p3 = rail.getDynamicProperty("mtc_bz_p3")
                            const tlm = rail.getDynamicProperty("mtc_tlm")
                            const vrail = rail.getDynamicProperty("mtc_vrail")
                            const t = getBezierNeart(p1, p2, p3, head_loc)

                            const p = getBezier(p1, p2, p3, t)
                            const d2 = dist2(head_loc, p)
                            if (d2 < h_min) {
                                h_min = d2
                                h_rail = rail
                                deg = Math.atan2(-(p.x - sourceEntity.location.x), p.z - sourceEntity.location.z) * 57.29578
                                sourceEntity.setDynamicProperty("mtc_head_p1", p1)
                                sourceEntity.setDynamicProperty("mtc_head_p2", p2)
                                sourceEntity.setDynamicProperty("mtc_head_p3", p3)
                                sourceEntity.setDynamicProperty("mtc_head_tlm", tlm)
                                sourceEntity.setDynamicProperty("mtc_head_vrail", vrail)
                            }
                        }
                    }
                    sourceEntity.setRotation({ x: 0, y: deg })
                } else {
                    //通常レールなら反転
                    if (diff < -90)
                        diff += 180;
                    if (diff > 90)
                        diff -= 180;
                    sourceEntity.setRotation({ x: 0, y: rot2 + diff })
                }
            }
            sourceEntity.runCommand("tag @e remove mtc_temp_conn")
        } else if (id == "mtc:npt") {
            const splits = message.split(" ")
            let id = splits[0]
            let accept = (splits.length <= 2)
            const trg_ents = dim.getEntities({ families: ["mtc_rail2"], location: { x: x, y: y, z: z }, closest: 1 })

            if (trg_ents.length > 0) {
                const trg_ent = trg_ents[0]

                if (splits.length == 2) {
                    //幕一致検索
                    if (base_bodys.length > 0) {
                        const base_body = base_bodys[0]
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    } else {
                        accept = false
                    }
                }

                if (accept) {
                    trg_ent.setDynamicProperty("mtc_bz_p1", trg_ent.getDynamicProperty("mtc_bz" + id + "_p1"))
                    trg_ent.setDynamicProperty("mtc_bz_p2", trg_ent.getDynamicProperty("mtc_bz" + id + "_p2"))
                    trg_ent.setDynamicProperty("mtc_bz_p3", trg_ent.getDynamicProperty("mtc_bz" + id + "_p3"))
                    trg_ent.setDynamicProperty("mtc_now_npt", Number(id))
                    aniRail()
                }
            }

            //sourceEntity.setDynamicProperty("mtc_point_pre",Number(message))//これ直前のレッドストーン用なのでここでは書き込まない
        } else if (id == "mtc:init") {
            loadObjs()
        } else if (id == "mtc:setpgop") {
            let ent_pg = dim.getEntities({ excludeTypes: ["minecraft:player"], excludeFamilies: ["mtc_rail", "mtc_obj"], location: org_loc, closest: 1 })
            if (ent_pg.length > 0) {
                ent_pg[0].setDynamicProperty("mtc_pgop", message)
            }
        } else if (id == "mtc:setpgcl") {
            let ent_pg = dim.getEntities({ excludeTypes: ["minecraft:player"], excludeFamilies: ["mtc_rail", "mtc_obj"], location: org_loc, closest: 1 })
            if (ent_pg.length > 0) {
                ent_pg[0].setDynamicProperty("mtc_pgcl", message)
            }
        } else {


            if (base_bodys.length > 0) {
                const base_body = base_bodys[0]

                //編成全体取得
                const fid = world.scoreboard.getObjective("mtc_uid").getScore(base_body)
                let ents_f = []
                for (const ent of bodies_g) {
                    if (world.scoreboard.getObjective("mtc_fid").getScore(ent) == fid) {
                        ents_f.push(ent)
                    }
                }

                if (id == "mtc:stop") {
                    base_body.runCommand("scoreboard players operation @s mtc_not = @s mtc_notBM")
                    base_body.runCommand("tag @s add mtc_mas_v2")
                    base_body.runCommand("scoreboard players set @s mtc_ato -1")
                    base_body.runCommand("scoreboard players set @s mtc_spd 0")
                    world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.stop" }] })
                } else if (id == "mtc:stopa") {
                    base_body.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players operation @s mtc_not = @s mtc_notBM")
                    base_body.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run tag @s add mtc_mas_v2")
                    base_body.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players set @s mtc_ato -1")
                    base_body.runCommand("execute as @e[family=mtc_body,tag=mtc_parent] run scoreboard players set @s mtc_spd 0")
                    world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.stop" }] })
                } else if (id == "mtc:inner_pg_openL") {
                    if (!obj_mtc_global.hasParticipant("pg_off")) {
                        obj_mtc_global.setScore("pg_off", 0)
                    }
                    if (obj_mtc_global.getScore("pg_off") !== 1) {
                        const len = base_body.getDynamicProperty("mtc_body_length")
                        if (len !== undefined) {
                            let js = js_high
                            let je = je_high
                            if (sourceEntity.hasTag("mtc_pglow")) {
                                js = js_low
                                je = je_low
                            }

                            const loc = sourceEntity.location
                            const roty = sourceEntity.getRotation().y
                            let rotx = getState(sourceEntity, "mtc_tilt_x")
                            if (rotx === undefined) rotx = 0;
                            const ux_x = Math.cos(roty * 0.0174533)
                            const ux_z = Math.sin(roty * 0.0174533)
                            const uz_x = -Math.sin(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                            const uz_z = Math.cos(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                            const uz_y = Math.sin(rotx * 0.0174533)
                            let ents_pg = {}
                            const targ_ents = sourceEntity.dimension.getEntities({ location: loc, maxDistance: len * 2, excludeFamilies: ["mtc_obj", "mtc_rail"], excludeTypes: ["player", "mtc:seat"] })

                            for (let i = -4; i <= Math.ceil(len * 2) + 4; i++) {
                                for (let j = js; j <= je; j++) {
                                    for (let k = 1; k <= 3; k++) {
                                        const dz = 0.5 * i
                                        const dx = k
                                        const sloc = { x: loc.x + dx * ux_x + dz * uz_x, y: loc.y + dz * uz_y + j, z: loc.z + dx * ux_z + dz * uz_z }
                                        for (const s_ent of targ_ents) {
                                            if (dist2(sloc, s_ent.location) <= 0.81) ents_pg[s_ent.id] = s_ent;
                                        }
                                    }
                                }
                            }
                            for (const key in ents_pg) {
                                const pg_ent = ents_pg[key]
                                pg_ent.addTag("pg_open")
                                try {
                                    pg_ent.triggerEvent("open")
                                } catch (e) { }
                                try {
                                    pg_ent.triggerEvent("pgop")
                                } catch (e) { }

                                const sound = pg_ent.getDynamicProperty("mtc_pgop")
                                if (sound !== undefined) {
                                    pg_ent.runCommand(`playsound ${sound} @a ~~~ 10`)
                                }
                            }
                        }
                    }
                } else if (id == "mtc:inner_pg_openR") {
                    if (!obj_mtc_global.hasParticipant("pg_off")) {
                        obj_mtc_global.setScore("pg_off", 0)
                    }
                    if (obj_mtc_global.getScore("pg_off") !== 1) {
                        const len = base_body.getDynamicProperty("mtc_body_length")
                        if (len !== undefined) {
                            if (len !== undefined) {
                                let js = js_high
                                let je = je_high
                                if (sourceEntity.hasTag("mtc_pglow")) {
                                    js = js_low
                                    je = je_low
                                }

                                const loc = sourceEntity.location
                                const roty = sourceEntity.getRotation().y
                                let rotx = getState(sourceEntity, "mtc_tilt_x")
                                if (rotx === undefined) rotx = 0;
                                const ux_x = Math.cos(roty * 0.0174533)
                                const ux_z = Math.sin(roty * 0.0174533)
                                const uz_x = -Math.sin(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                                const uz_z = Math.cos(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                                const uz_y = Math.sin(rotx * 0.0174533)
                                let ents_pg = {}
                                const targ_ents = sourceEntity.dimension.getEntities({ location: loc, maxDistance: len * 2, excludeFamilies: ["mtc_obj", "mtc_rail"], excludeTypes: ["player", "mtc:seat"] })

                                for (let i = -4; i <= Math.ceil(len * 2) + 4; i++) {
                                    for (let j = js; j <= je; j++) {
                                        for (let k = 1; k <= 3; k++) {
                                            const dz = 0.5 * i
                                            const dx = -k
                                            const sloc = { x: loc.x + dx * ux_x + dz * uz_x, y: loc.y + dz * uz_y + j, z: loc.z + dx * ux_z + dz * uz_z }
                                            for (const s_ent of targ_ents) {
                                                if (dist2(sloc, s_ent.location) <= 0.81) ents_pg[s_ent.id] = s_ent;
                                            }
                                        }
                                    }
                                }
                                for (const key in ents_pg) {
                                    const pg_ent = ents_pg[key]

                                    pg_ent.addTag("pg_open")
                                    try {
                                        pg_ent.triggerEvent("open")
                                    } catch (e) { }
                                    try {
                                        pg_ent.triggerEvent("pgop")
                                    } catch (e) { }

                                    const sound = pg_ent.getDynamicProperty("mtc_pgop")
                                    if (sound !== undefined) {
                                        pg_ent.runCommand(`playsound ${sound} @a ~~~ 10`)
                                    }
                                }
                            }
                        }
                    }
                } else if (id == "mtc:inner_pg_closeL") {
                    if (!obj_mtc_global.hasParticipant("pg_off")) {
                        obj_mtc_global.setScore("pg_off", 0)
                    }
                    if (obj_mtc_global.getScore("pg_off") !== 1) {

                        const len = base_body.getDynamicProperty("mtc_body_length")
                        if (len !== undefined) {
                            if (len !== undefined) {
                                let js = js_high
                                let je = je_high
                                if (sourceEntity.hasTag("mtc_pglow")) {
                                    js = js_low
                                    je = je_low
                                }

                                const loc = sourceEntity.location
                                const roty = sourceEntity.getRotation().y
                                let rotx = getState(sourceEntity, "mtc_tilt_x")
                                if (rotx === undefined) rotx = 0;
                                const ux_x = Math.cos(roty * 0.0174533)
                                const ux_z = Math.sin(roty * 0.0174533)
                                const uz_x = -Math.sin(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                                const uz_z = Math.cos(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                                const uz_y = Math.sin(rotx * 0.0174533)
                                let ents_pg = {}
                                const targ_ents = sourceEntity.dimension.getEntities({ location: loc, maxDistance: len * 2, excludeFamilies: ["mtc_obj", "mtc_rail"], excludeTypes: ["player", "mtc:seat"] })

                                for (let i = -4; i <= Math.ceil(len * 2) + 4; i++) {
                                    for (let j = js; j <= je; j++) {
                                        for (let k = 1; k <= 3; k++) {
                                            const dz = 0.5 * i
                                            const dx = k
                                            const sloc = { x: loc.x + dx * ux_x + dz * uz_x, y: loc.y + dz * uz_y + j, z: loc.z + dx * ux_z + dz * uz_z }
                                            for (const s_ent of targ_ents) {
                                                if (dist2(sloc, s_ent.location) <= 0.81) ents_pg[s_ent.id] = s_ent;
                                            }
                                        }
                                    }
                                }
                                for (const key in ents_pg) {
                                    const pg_ent = ents_pg[key]

                                    pg_ent.removeTag("pg_open")
                                    try {
                                        pg_ent.triggerEvent("close")
                                    } catch (e) { }
                                    try {
                                        pg_ent.triggerEvent("pgcl")
                                    } catch (e) { }

                                    const sound = pg_ent.getDynamicProperty("mtc_pgcl")
                                    if (sound !== undefined) {
                                        pg_ent.runCommand(`playsound ${sound} @a ~~~ 10`)
                                    }
                                }
                            }
                        }
                    }
                } else if (id == "mtc:inner_pg_closeR") {
                    if (!obj_mtc_global.hasParticipant("pg_off")) {
                        obj_mtc_global.setScore("pg_off", 0)
                    }
                    if (obj_mtc_global.getScore("pg_off") !== 1) {

                        const len = base_body.getDynamicProperty("mtc_body_length")
                        if (len !== undefined) {
                            if (len !== undefined) {
                                let js = js_high
                                let je = je_high
                                if (sourceEntity.hasTag("mtc_pglow")) {
                                    js = js_low
                                    je = je_low
                                }

                                const loc = sourceEntity.location
                                const roty = sourceEntity.getRotation().y
                                let rotx = getState(sourceEntity, "mtc_tilt_x")
                                if (rotx === undefined) rotx = 0;
                                const ux_x = Math.cos(roty * 0.0174533)
                                const ux_z = Math.sin(roty * 0.0174533)
                                const uz_x = -Math.sin(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                                const uz_z = Math.cos(roty * 0.0174533) * Math.cos(rotx * 0.0174533)
                                const uz_y = Math.sin(rotx * 0.0174533)
                                let ents_pg = {}
                                const targ_ents = sourceEntity.dimension.getEntities({ location: loc, maxDistance: len * 2, excludeFamilies: ["mtc_obj", "mtc_rail"], excludeTypes: ["player", "mtc:seat"] })

                                for (let i = -4; i <= Math.ceil(len * 2) + 4; i++) {
                                    for (let j = js; j <= je; j++) {
                                        for (let k = 1; k <= 3; k++) {
                                            const dz = 0.5 * i
                                            const dx = -k
                                            const sloc = { x: loc.x + dx * ux_x + dz * uz_x, y: loc.y + dz * uz_y + j, z: loc.z + dx * ux_z + dz * uz_z }
                                            for (const s_ent of targ_ents) {
                                                if (dist2(sloc, s_ent.location) <= 0.81) ents_pg[s_ent.id] = s_ent;
                                            }
                                        }
                                    }
                                }
                                for (const key in ents_pg) {
                                    const pg_ent = ents_pg[key]

                                    pg_ent.removeTag("pg_open")
                                    try {
                                        pg_ent.triggerEvent("close")
                                    } catch (e) { }
                                    try {
                                        pg_ent.triggerEvent("pgcl")
                                    } catch (e) { }
                                    const sound = pg_ent.getDynamicProperty("mtc_pgcl")
                                    if (sound !== undefined) {
                                        pg_ent.runCommand(`playsound ${sound} @a ~~~ 10`)
                                    }

                                }
                            }
                        }
                    }
                } else if (id == "mtc:anion") {
                    const splits = message.split(" ")
                    let ani_id = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {
                        base_body.addTag("mtc_ani" + ani_id)
                        for (const ent of ents_f) {
                            ent.setDynamicProperty("ani" + ani_id, 1)
                            playAni(ent, "ani" + ani_id, "ani" + ani_id)
                            try { ent.runCommand(`function ${getIdBase(ent.typeId)}/ani/ani${ani_id}`) } catch (e) { }
                            const name = getIdBase(ent.typeId)
                            ent.dimension.playSound(name + "_ani" + ani_id, ent.location, { volume: 256 })
                        }
                    }
                } else if (id == "mtc:anioff") {
                    const splits = message.split(" ")
                    let ani_id = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {
                        base_body.removeTag("mtc_ani" + ani_id)
                        for (const ent of ents_f) {
                            ent.setDynamicProperty("ani" + ani_id, 0)
                            stopAni(ent, "ani" + ani_id)
                            playAni(ent, "ani" + ani_id + "e", "ani" + ani_id)
                            try { ent.runCommand(`function ${getIdBase(ent.typeId)}/ani/ani${ani_id}e`) } catch (e) { }
                            const name = getIdBase(ent.typeId)
                            ent.dimension.playSound(name + "_ani" + ani_id + "e", ent.location, { volume: 256 })
                        }
                    }
                } else if (id == "mtc:soundon") {
                    const splits = message.split(" ")
                    let sound_id = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {
                        for (const ent of ents_f) {
                            ent.setDynamicProperty("sound" + sound_id, 1)
                            ent.addTag("mtc_nsound" + sound_id)
                        }
                    }
                } else if (id == "mtc:soundoff") {
                    const splits = message.split(" ")
                    let sound_id = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {
                        for (const ent of ents_f) {
                            ent.setDynamicProperty("sound" + sound_id, 0)
                            ent.removeTag("mtc_nsound" + sound_id)
                            ent.removeTag("mtc_sound" + sound_id)
                        }
                    }
                } else if (id == "mtc:horn") {
                    const splits = message.split(" ")
                    let sound_id = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {
                        dim.runCommand("execute as @e[family=mtc_body] run scoreboard players operation @s mtc_calc2 = @s mtc_fid")
                        dim.runCommand(`execute positioned ${x} ${y} ${z} run scoreboard players operation @e[family=mtc_body] mtc_calc2 -= @e[family=mtc_body,tag=mtc_parent,scores={mtc_calcj1=0},c=1] mtc_fid`)
                        const ents2 = getSelectorEntities2("@e[family=mtc_body,scores={mtc_calc2=0}]", dim)
                        for (const ent of ents2) {
                            ent.runCommand(`playsound ${getIdBase(ent.typeId) + "_horn" + sound_id} @a[r=32] ~~~ 64`)
                        }
                    }
                } else if (id == "mtc:tasc") {
                    const splits = message.split(" ")
                    let dist = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {
                        if (dist === 0) {
                            base_body.removeTag("mtc_tasc")
                            base_body.removeTag("mtc_tasc_do")
                        } else {

                            //ブロック位置を考慮した真の距離を計算したい
                            //早く反応したか遅く反応したか確かめるため，位置と速度見たい
                            if (sourceType == "Block") {
                                x += 0.5
                                y += 0.5
                                z += 0.5

                                let spd = 0.0005 * obj_mtc_spd.getScore(base_body);
                                let sign = 1
                                if (base_body.hasTag("mtc_rev")) {
                                    spd *= -1
                                    sign = -1
                                }

                                const rot = base_body.getRotation()

                                const uz = Math.cos(0.0174533 * rot.y) * Math.cos(0.0174533 * rot.x)
                                const uy = Math.sin(0.0174533 * rot.x)
                                const ux = -Math.sin(0.0174533 * rot.y) * Math.cos(0.0174533 * rot.x)

                                const dx = x - base_body.location.x
                                const dy = y - base_body.location.y
                                const dz = z - base_body.location.z
                                const svx = sign * ux
                                const svy = sign * uy
                                const svz = sign * uz

                                const dot_product = dx * svx + dy * svy + dz * svz

                                let diff = Math.sqrt(dx ** 2 + dz ** 2)
                                if (dot_product < 0) {
                                    //遅く反応した場合
                                    diff *= -1

                                }
                                dist += diff
                            }
                            tascSet(base_body, dist)
                        }
                    }
                } else if (id == "mtc:run") {
                    const splits = message.split(" ")
                    let raw_spd = Number(splits[0])
                    let dist = Number(splits[1])
                    let accept = (splits.length == 2 || splits.length == 3)

                    if (splits.length == 3) {
                        //幕一致検索
                        accept = testMode(splits[2], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {

                        //ブロック位置を考慮した真の距離を計算したい
                        //早く反応したか遅く反応したか確かめるため，位置と速度見たい
                        if (sourceType == "Block") {
                            x += 0.5
                            y += 0.5
                            z += 0.5

                            let spd = 0.0005 * obj_mtc_spd.getScore(base_body);
                            let sign = 1
                            if (base_body.hasTag("mtc_rev")) {
                                spd *= -1
                                sign = -1
                            }

                            const rot = base_body.getRotation()
                            const loc = base_body.location

                            const uz = Math.cos(0.0174533 * rot.y) * Math.cos(0.0174533 * rot.x)
                            const uy = Math.sin(0.0174533 * rot.x)
                            const ux = -Math.sin(0.0174533 * rot.y) * Math.cos(0.0174533 * rot.x)

                            const dx = x - loc.x
                            const dy = y - loc.y
                            const dz = z - loc.z
                            const svx = sign * ux
                            const svy = sign * uy
                            const svz = sign * uz

                            const dot_product = dx * svx + dy * svy + dz * svz

                            let diff = Math.sqrt(dx ** 2 + dz ** 2)
                            if (dot_product < 0) {
                                //遅く反応した場合
                                diff *= -1

                            }
                            dist += diff
                        }
                        tascSet(base_body, dist)
                        if (raw_spd < 0) {
                            world.scoreboard.getObjective("mtc_ato").setScore(base_body, -1)
                        } else {
                            world.scoreboard.getObjective("mtc_ato").setScore(base_body, Math.trunc(raw_spd * 2000))
                        }
                    }
                } else if (id == "mtc:dist") {
                    if (base_body.getDynamicProperty("dist") === undefined) base_body.setDynamicProperty("dist", 0.0);
                    const now_dist = base_body.getDynamicProperty("dist")
                    const last_dist = base_body.getDynamicProperty("last_dist")
                    if (last_dist === undefined) {
                        world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.from_spawn" }, { "text": " : " + (Math.round(now_dist * 1000) / 1000) + " m" }] })
                    } else {
                        world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.from_last" }, { "text": " : " + (Math.round((now_dist - last_dist) * 1000) / 1000) + " m" }] })
                    }
                    base_body.setDynamicProperty("last_dist", now_dist)
                } else if (id == "mtc:ats") {
                    const splits = message.split(" ")
                    let spd_raw = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {

                        if (spd_raw < 0) {
                            world.scoreboard.getObjective("mtc_ats").setScore(base_body, -1)
                        } else {
                            world.scoreboard.getObjective("mtc_ats").setScore(base_body, Math.trunc(spd_raw * 2000))
                        }
                    }
                } else if (id == "mtc:ato") {
                    const splits = message.split(" ")
                    let spd_raw = Number(splits[0])
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {

                        if (spd_raw < 0) {
                            world.scoreboard.getObjective("mtc_ato").setScore(base_body, -1)
                        } else {
                            world.scoreboard.getObjective("mtc_ato").setScore(base_body, Math.trunc(spd_raw * 2000))
                        }
                    }
                } else if (id == "mtc:atc") {
                    const splits = message.split(" ")
                    let spd_raw = Math.trunc(Number(splits[0]))
                    if (spd_raw < 0)
                        spd_raw = -1;
                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }

                    if (accept) {

                        for (const ent_f of ents_f) {
                            ent_f.setDynamicProperty("mtc_atc", spd_raw)
                            if (spd_raw < 0) {
                                stopAni(ent_f, "mtc_anicon_atc_meter")
                            } else {
                                playAni(ent_f, "atc_" + Math.trunc(spd_raw / 10) * 10, "mtc_anicon_atc_meter")
                                playAni(ent_f, "atc_" + Math.trunc(spd_raw / 5) * 5, "mtc_anicon_atc_meter")
                                playAni(ent_f, "atc_" + spd_raw, "mtc_anicon_atc_meter")
                            }
                        }
                    }
                } else if (id == "mtc:ap") {
                    if (base_body.hasTag("mtc_plane")) {
                        //文法 飛行経路
                        //機能 着陸以外エンジン出力90%で連続動作
                        // 飛行経路の書き方:x,y,z x,y,z x,y,z ...
                        // 離陸する点の手前から接地する点の先まで
                        const str_points = message.split(" ")
                        let ct_p = [base_body.location]

                        for (const str_p of str_points) {
                            if (str_p !== "") {
                                const ps = str_p.split(",")
                                ct_p.push({ x: Number(ps[0]), y: Number(ps[1]), z: Number(ps[2]) })
                            }
                        }

                        const pe2 = ct_p[ct_p.length - 1]
                        const pe3 = ct_p[ct_p.length - 2]
                        const vx = pe2.x - pe3.x
                        const vy = 0
                        const vz = pe2.z - pe3.z
                        const vl = Math.sqrt(vx ** 2 + vy ** 2 + vz ** 2)
                        ct_p.push({ x: pe2.x + vx * 10 / vl, y: pe2.y + vy * 10 / vl, z: pe2.z + vz * 10 / vl })

                        const pi2 = ct_p[1]
                        const pi3 = ct_p[0]
                        const vx2 = pi2.x - pi3.x
                        const vy2 = 0
                        const vz2 = pi2.z - pi3.z
                        const vl2 = Math.sqrt(vx2 ** 2 + vy2 ** 2 + vz2 ** 2)
                        ct_p.splice(2, 0, { x: pi2.x + vx2 * 10 / vl2, y: pi2.y + vy2 * 10 / vl2, z: pi2.z + vz2 * 10 / vl2 })

                        const bzs = splitBezier(ct_p)

                        for (let i = 0; i < bzs.length; i++) {
                            const bz = bzs[i]
                            base_body.setDynamicProperty("mtc_autopirot_bz" + i + "p1", bz[0])
                            base_body.setDynamicProperty("mtc_autopirot_bz" + i + "p2", bz[1])
                            base_body.setDynamicProperty("mtc_autopirot_bz" + i + "p3", bz[2])
                        }
                        base_body.setDynamicProperty("mtc_autopirot_n", bzs.length)
                        base_body.setDynamicProperty("mtc_autopirot_now", 0)
                        base_body.addTag("mtc_autopirot")
                    } else {
                        world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_autopirot" }] })
                    }

                } else if (id == "mtc:apoff") {
                    base_body.removeTag("mtc_autopirot")
                } else if (id == "mtc:rider") {
                    let buf = ""
                    let splits = []
                    let indc = false
                    for (const ch of message) {
                        if (ch === "\'") {
                            indc = !indc
                        } else if (!indc && ch === " ") {
                            if (buf != "") {
                                splits.push(buf)
                                buf = ""
                            }
                        } else {
                            buf += ch
                        }
                    }
                    if (buf != "") {
                        splits.push(buf)
                    }

                    let accept = (splits.length <= 2)

                    if (splits.length == 2) {
                        //幕一致検索
                        accept = testMode(splits[1], 1 + world.scoreboard.getObjective("mtc_maku").getScore(base_body))
                    }


                    if (accept) {

                        let pls = []
                        for (const ent of ents_f) {
                            pls = pls.concat(getRiderPlayer(ent))
                        }
                        for (const pl of pls) {
                            try {
                                pl.runCommand(splits[0])
                            } catch (e) { }
                        }
                    }

                } else {
                    world.sendMessage("§cInvalid Command!")
                }
            } else {
                world.sendMessage({ rawtext: [{ "translate": "mtc:mtc.warn.no_controll" }] })
            }
        }

    } else {
        console.warn("Cannot run from server!")
        return
    }
});

function getRiderPlayer(ent) {
    let res = []
    const riders_cp = ent.getComponent("minecraft:rideable")
    if (riders_cp !== undefined) {
        const riders = riders_cp.getRiders()
        for (const rider of riders) {
            if (rider.typeId !== "mtc:seat") {
                res.push(rider)
            } else {
                res = res.concat(rider.getComponent("minecraft:rideable").getRiders())
            }
        }
    }
    return res
}


world.beforeEvents.entityRemove.subscribe((e) => {
    const ent = e.removedEntity
    const dim = ent.dimension
    const loc = ent.location
    const rot = ent.getRotation()
    const type = ent.typeId
    const is_rail = (ent.getComponent("minecraft:type_family") !== undefined && (ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_rail") || ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_pole")))
    const mtc_safe_remove = ent.hasTag("mtc_safe_remove")
    let props = {}
    let n_prop = 0
    for (const key of ent.getDynamicPropertyIds()) {
        props[key] = ent.getDynamicProperty(key)
        n_prop++
    }


    system.run(() => {
        if (n_prop > 0 && !mtc_safe_remove && is_rail) {
            let new_ent = undefined
            try {
                new_ent = dim.spawnEntity(type, loc)
                new_ent.setRotation(rot)
                for (const key in props) {
                    new_ent.setDynamicProperty(key, props[key])
                }
                setState(new_ent, "mtc_rail_rest_rot", 20)
            } catch (e) {
                if (new_ent !== undefined) {
                    new_ent.remove()
                }
            }

        }
    })
})

//スポーン時
world.afterEvents.playerSpawn.subscribe((eventData) => {
    let { player, initialSpawn } = eventData;
    //if (!initialSpawn) return;
    no_loaded_players.push(player)
});

world.afterEvents.entityLoad.subscribe(

    (event) => {

        if (event.entity.getComponent("minecraft:type_family") !== undefined && event.entity.getComponent("minecraft:type_family").hasTypeFamily("mtc_body")) {
            bodies_g.push(event.entity)
        }
    }


);

players_g = world.getPlayers()
loadAllBodies()
//エンティティスポーン
world.afterEvents.entitySpawn.subscribe((entityEvent) => {
    spawnFunc(entityEvent.entity)
    if (entityEvent.entity.getComponent("minecraft:type_family") !== undefined && entityEvent.entity.getComponent("minecraft:type_family").hasTypeFamily("mtc_body")) {
        loadAllBodies()
    }
});


function loadAllBodies() {
    bodies_g = world.getDimension("overworld").getEntities(run_entity_interfaec)
    bodies_g = bodies_g.concat(world.getDimension("nether").getEntities(run_entity_interfaec))
    bodies_g = bodies_g.concat(world.getDimension("the_end").getEntities(run_entity_interfaec))
}

async function spawnFunc(ent_s) {
    if (ent_s.isValid()) {
        if (ent_s.hasTag("mtc_plane")) {
            ent_s.setDynamicProperty("mtc_engine", 0.0)
            ent_s.setDynamicProperty("mtc_dx", 0.0)
            ent_s.setDynamicProperty("mtc_dy", 0.0)
        } else if (!ent_s.hasTag("mtc_norail") && ent_s.getComponent("minecraft:type_family") !== undefined && ent_s.getComponent("minecraft:type_family").hasTypeFamily("mtc_body")) {
            //初期設定終わるまで待機
            const spawn_inv = world.getDynamicProperty("mtc_nextspawn_inv")
            world.setDynamicProperty("mtc_nextspawn_inv", false)

            while (true) {
                if (ent_s.hasTag("mtc_init")) break
                await sleep(1)
            }

            if (spawn_inv === true) {
                ent_s.setRotation({ x: 0, y: ent_s.getRotation().y + 180 })
            }

            let on_rail = false
            const ublock = ent_s.dimension.getBlockFromRay(ent_s.location, { x: 0, y: -1, z: 0 })
            if (ublock !== undefined) {
                if (ublock.block.typeId.slice(-4) == "rail") {
                    on_rail = true
                }
            }

            if (!on_rail) {
                const rails = ent_s.dimension.getEntities({ families: ["mtc_rail"], location: ent_s.location, maxDistance: 40 })
                let min = 1e30
                let min_f = 1e30
                let m_rail = undefined
                for (const rail of rails) {
                    const p1 = rail.getDynamicProperty("mtc_bz_p1")
                    const p2 = rail.getDynamicProperty("mtc_bz_p2")
                    const p3 = rail.getDynamicProperty("mtc_bz_p3")
                    const t = getBezierNeart(p1, p2, p3, ent_s.location)

                    const p = getBezier(p1, p2, p3, t)
                    const d2 = dist2(ent_s.location, p)
                    if (d2 < min) {
                        min = d2
                        min_f = (ent_s.location.x - p.x) ** 2 + (ent_s.location.z - p.z) ** 2
                        m_rail = rail
                    }
                }

                if (min_f <= 25) {
                    const p1 = m_rail.getDynamicProperty("mtc_bz_p1")
                    const p2 = m_rail.getDynamicProperty("mtc_bz_p2")
                    const p3 = m_rail.getDynamicProperty("mtc_bz_p3")
                    const tlm = m_rail.getDynamicProperty("mtc_tlm")
                    const joint = m_rail.getDynamicProperty("mtc_joint")
                    const vrail = m_rail.getDynamicProperty("mtc_vrail")
                    const t = getBezierNeart(p1, p2, p3, ent_s.location)
                    const p = getBezier(p1, p2, p3, t)
                    const dir = bezierTangent(p1, p2, p3, t)

                    let deg = Math.atan2(-dir.x, dir.z) * 57.29578
                    const init_deg = ent_s.getRotation().y
                    let diff = deg - init_deg
                    if (diff < -90) {
                        diff += 180
                    }
                    if (diff > 90) {
                        diff -= 180
                    }
                    deg = init_deg + diff

                    //レンジを+-180に修正
                    if (deg < -180) {
                        deg += 360
                    }
                    if (deg > 180) {
                        deg -= 360
                    }
                    //-135~45の範囲外なら反転
                    if (deg < -135) {
                        deg += 180
                    }
                    if (deg > 45) {
                        deg -= 180
                    }

                    if (spawn_inv === true) {
                        deg += 180
                        if (deg > 180) deg -= 360
                    }

                    ent_s.teleport(p)
                    ent_s.setDynamicProperty("mtc_body_p1", p1)
                    ent_s.setDynamicProperty("mtc_body_p2", p2)
                    ent_s.setDynamicProperty("mtc_body_p3", p3)
                    ent_s.setDynamicProperty("mtc_body_tlm", tlm)
                    ent_s.setDynamicProperty("mtc_joint", joint)
                    ent_s.setDynamicProperty("mtc_body_vrail", vrail)
                    ent_s.addTag("mtc_on_newrail_b")
                    ent_s.addTag("mtc_on_newrail_h")
                    setState(ent_s, "mtc_prev", ent_s.location)


                    let def_length = ent_s.getDynamicProperty("mtc_body_length")
                    if (def_length === undefined) {
                        ent_s.setDynamicProperty("mtc_body_length", def_length)
                        def_length = 18
                    }
                    let def_d_length = ent_s.getDynamicProperty("mtc_d_length")
                    if (def_d_length === undefined) {
                        ent_s.setDynamicProperty("mtc_d_length", def_d_length)
                        def_d_length = 18
                    }

                    let h_min = 1e30
                    let h_rail = undefined
                    let head_loc
                    const n_spl = 0.5 / Math.round(def_d_length)
                    for (let j = n_spl; j <= 1; j += n_spl) {
                        const rot = { x: 0, y: deg }
                        const bx_uz = -Math.sin(0.0174533 * deg)
                        const by_uz = 0
                        const bz_uz = Math.cos(0.0174533 * rot.y)

                        const sx = ent_s.location.x + def_d_length * j * bx_uz
                        const sy = ent_s.location.y + def_d_length * j * by_uz
                        const sz = ent_s.location.z + def_d_length * j * bz_uz
                        head_loc = { x: sx, y: sy, z: sz }

                        h_min = 1e30
                        h_rail = undefined
                        for (const rail of rails) {
                            const p1 = rail.getDynamicProperty("mtc_bz_p1")
                            const p2 = rail.getDynamicProperty("mtc_bz_p2")
                            const p3 = rail.getDynamicProperty("mtc_bz_p3")
                            const tlm = rail.getDynamicProperty("mtc_tlm")
                            const vrail = rail.getDynamicProperty("mtc_vrail")
                            const t = getBezierNeart(p1, p2, p3, head_loc)

                            const p = getBezier(p1, p2, p3, t)
                            const d2 = dist2(head_loc, p)
                            if (d2 < h_min) {
                                h_min = d2
                                h_rail = rail
                                deg = Math.atan2(-(p.x - ent_s.location.x), p.z - ent_s.location.z) * 57.29578
                                ent_s.setDynamicProperty("mtc_head_p1", p1)
                                ent_s.setDynamicProperty("mtc_head_p2", p2)
                                ent_s.setDynamicProperty("mtc_head_p3", p3)
                                ent_s.setDynamicProperty("mtc_head_tlm", tlm)
                                ent_s.setDynamicProperty("mtc_head_vrail", vrail)
                            }
                        }
                    }
                    ent_s.setRotation({ x: 0, y: deg })

                }
            }
        }
    }

}

world.afterEvents.entityHitEntity.subscribe((e) => {
    const ent = e.hitEntity
    const pl = e.damagingEntity
    const item = pl.getComponent("minecraft:inventory").container.getSlot(pl.selectedSlotIndex)
    if (item.hasItem()) {
        if ((item.typeId == "mtc:i_marker0" || item.typeId == "mtc:i_marker1") && ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_marker")) {
            pl.runCommand("playsound random.click @s")
            showRAILmenu0(ent, pl)
        } else if ((item.typeId == "mtc:i_marker0") && ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_rail")) {
            pl.runCommand("playsound random.anvil_land @a ~~~")
            ent.addTag("mtc_safe_remove")
            ent.remove()
        } else if ((item.typeId == "mtc:i_marker1") && ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_rail")) {
            pl.runCommand("playsound random.anvil_land @a ~~~")
            let ent_r = ent

            while (true) {
                const next_pos = ent_r.getDynamicProperty("mtc_bz_p3")
                const ents = ent_r.dimension.getEntities({ families: ["mtc_rail"], location: next_pos, maxDistance: 2 })
                ent_r.addTag("mtc_safe_remove")
                ent_r.remove()
                if (ents.length == 0) {
                    break
                } else {
                    ent_r = ents[0]
                }
            }
        } else if ((item.typeId == "mtc:i_marker2") && ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_pmarker")) {
            pl.runCommand("playsound random.click @s")
            showPOLEmenu0(ent, pl)
        } else if ((item.typeId == "mtc:i_marker2") && ent.getComponent("minecraft:type_family").hasTypeFamily("mtc_pole")) {
            pl.runCommand("playsound random.anvil_land @a ~~~")
            let ent_r = ent

            while (true) {
                const next_pos = ent_r.getDynamicProperty("mtc_po_p2")
                const ents = ent_r.dimension.getEntities({ families: ["mtc_pole"], location: next_pos, maxDistance: 2 })
                ent_r.addTag("mtc_safe_remove")
                ent_r.remove()
                if (ents.length == 0) {
                    break
                } else {
                    ent_r = ents[0]
                    const hide_base = ent_r.getDynamicProperty("mtc_pole_base_h")
                    if (hide_base !== true) break;

                }
            }
        }
    }
})


async function setPole(ent, pl, rail_type, end_pole = false) {
    const name_add = pole_types[rail_type]
    let pole_max_len = 16


    const owner_id = ent.getDynamicProperty("mtc_owner")

    let final_remove_markers = []

    const ticker = ent.dimension.spawnEntity("mtc:marker0", ent.location)
    await sleep(5)

    let marker0s = []
    {
        const bef_ents = pl.dimension.getEntities({ type: "mtc:marker2" })
        let n_bef_ent = 0
        for (const ent of bef_ents) {
            if (ent.getDynamicProperty("mtc_owner") === owner_id) {
                n_bef_ent++
                const index = ent.getDynamicProperty("mtc_mark_index")
                marker0s[index] = ent.location
                final_remove_markers.push(ent)
            }
        }
    }

    {
        let spl_pts = []//分割架線の始点，終点，親かどうか
        {

            for (let i = 0; i < marker0s.length; i++) {
                const p1 = marker0s[i]
                let p2
                if (i < marker0s.length - 1) {
                    p2 = marker0s[i + 1]
                } else {
                    p2 = marker0s[i]
                }
                const d = dist(p1, p2)
                if (d <= pole_max_len) {
                    spl_pts.push([p1, p2, true])
                } else {
                    const n_spl = Math.ceil(d / pole_max_len)
                    for (let j = 0; j < n_spl; j++) {
                        const dx = (p2.x - p1.x) / n_spl
                        const dy = (p2.y - p1.y) / n_spl
                        const dz = (p2.z - p1.z) / n_spl
                        const p1n = { x: p1.x + dx * j, y: p1.y + dy * j, z: p1.z + dz * j }
                        const p2n = { x: p1.x + dx * (j + 1), y: p1.y + dy * (j + 1), z: p1.z + dz * (j + 1) }
                        spl_pts.push([p1n, p2n, j === 0])
                    }
                }
            }
        }

        for (let i = 0; i < spl_pts.length; i++) {
            if (i == spl_pts.length - 1 && end_pole === false) break;
            const po1 = spl_pts[i][0]
            const po2 = spl_pts[i][1]
            const pop = spl_pts[i][2]

            let ent = undefined
            while (ent === undefined) {
                try {
                    ticker.teleport(po1)
                    await sleep(1)
                    ent = pl.dimension.spawnEntity("mtc:pole_" + name_add, po1)
                    ent.setDynamicProperty("location", po1)
                    suc = true
                } catch (e) {
                }
                if (ent === undefined)
                    await sleep(1)

            }
            pl.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.setrail1" }, { "text": ` : ${Math.round((i + 1) * 100 / spl_pts.length)} ％` }] })

            let dir = { x: po2.x - po1.x, y: po2.y - po1.y, z: po2.z - po1.z }
            if (i === spl_pts.length - 1) {
                if (i === 0) {
                    dir = { x: 0, y: 0, z: 1 }
                } else {
                    const po1b = spl_pts[i - 1][0]
                    dir = { x: po1.x - po1b.x, y: po1.y - po1b.y, z: po1.z - po1b.z }
                }
            } else if (i > 0) {
                const po1b = spl_pts[i - 1][0]
                const vec1 = { x: po1.x - po1b.x, y: po1.y - po1b.y, z: po1.z - po1b.z }
                const vec2 = { x: po2.x - po1.x, y: po2.y - po1.y, z: po2.z - po1.z }
                const len1 = dist(po1, po1b)
                const len2 = dist(po1, po2)

                dir = { x: vec2.x / len2 + vec1.x / len1, y: vec2.y / len2 + vec1.y / len1, z: vec2.z / len2 + vec1.z / len1 }
            }
            let deg_org = Math.atan2(-dir.x, dir.z) * 57.29578

            const near_rails = ent.dimension.getEntities({ families: ["mtc_rail"], location: ent.location, maxDistance: 40 })
            let min_d2 = 1e30
            let min_vec
            for (const ent_r of near_rails) {
                const bz1 = ent_r.getDynamicProperty("mtc_bz_p1")
                const bz2 = ent_r.getDynamicProperty("mtc_bz_p2")
                const bz3 = ent_r.getDynamicProperty("mtc_bz_p3")
                const t = getBezierNeart(bz1, bz2, bz3, ent.location)
                const pr = getBezier(bz1, bz2, bz3, t)
                const d2 = dist2(pr, ent.location)
                if (d2 < min_d2) {
                    min_d2 = d2
                    min_vec = bezierTangent(bz1, bz2, bz3, t)
                }
            }
            if (min_d2 < 36) {
                dir = min_vec
            }


            let deg = Math.atan2(-dir.x, dir.z) * 57.29578

            if (Math.abs(deg - deg_org) >= 180) {
                deg += 360
                if (deg > 360) deg -= 360
            }
            if (Math.abs(deg - deg_org) >= 90) {
                deg += 180
                if (deg > 180) deg -= 360
            }
            const deg2 = Math.round(deg / 45) * 45
            ent.setRotation({ x: 0, y: deg2 })

            const offset = deg - deg2

            //animation info
            ent.setDynamicProperty("mtc_po_p1", po1)
            ent.setDynamicProperty("mtc_po_p2", po2)

            if (pop) {
                ent.setDynamicProperty("mtc_pole_base_h", false)
                ent.setDynamicProperty("mtc_pole_base_deg", offset)
            } else {
                ent.setDynamicProperty("mtc_pole_base_h", true)
            }
            const p_dist = Math.ceil(dist(po1, po2) * 2)

            setState(ent, "mtc_rail_rest_rot", 20)  //強制回転階数(tick5関数で消費しながら回転)
            if (i === spl_pts.length - 1) {
                ent.setDynamicProperty("n_s", 0)
            } else {
                ent.setDynamicProperty("n_s", p_dist)
            }

            const deg_ud = Math.round(Math.atan2(po2.y - po1.y, Math.sqrt((po2.x - po1.x) ** 2 + (po2.z - po1.z) ** 2)) * 57.29578)
            ent.setDynamicProperty("s_ud", deg_ud)
            let deg_lr = Math.round(Math.atan2(-(po2.x - po1.x), po2.z - po1.z) * 57.29578 - deg2)
            if (deg_lr < -180) deg_lr += 360
            if (deg_lr > 180) deg_lr -= 360
            deg_lr = Math.min(63, Math.max(-63, deg_lr))
            ent.setDynamicProperty("s_lr", deg_lr)
        }
    }


    for (const ent of final_remove_markers) {
        ent.remove()
    }

    ticker.remove()
    pl.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.setrailok" }] })

}

async function setRail(ent, pl, rail_type, tlm, vrail, joint, tunnel = false, dl = 0, dr = 0, du = 0, dd = 0, rani_off = false, po_sel = 0) {
    const name_add = rail_types[rail_type]

    let rail_max_len = 16
    if (name_add == "def0" || name_add == "def11") {
        rail_max_len = world.getDynamicProperty("mtc_clearrail_max_len")
        if (rail_max_len === undefined) rail_max_len = 16;
    }


    const owner_id = ent.getDynamicProperty("mtc_owner")
    let init_ent
    let y_offset = 0.5      //線路高さオフセット
    if (rail_type >= 4) {
        y_offset = 0.68
    }
    let init_y1             //初期高さ
    let init_offert = 0     //初期角オフセット

    let final_remove_markers = []

    const ticker = ent.dimension.spawnEntity("mtc:marker0", ent.location)
    await sleep(5)

    let marker0s = []
    {
        const bef_ents = pl.dimension.getEntities({ type: "mtc:marker0" })
        let n_bef_ent = 0
        for (const ent of bef_ents) {
            if (ent.getDynamicProperty("mtc_owner") === owner_id) {
                n_bef_ent++
                const index = ent.getDynamicProperty("mtc_mark_index")
                marker0s[index] = ent.location
                final_remove_markers.push(ent)
            }
        }
    }

    let marker2s = [marker0s[0]]
    let n_bef_ent2 = 1
    {
        const bef_ents = pl.dimension.getEntities({ type: "mtc:marker1" })
        for (const ent of bef_ents) {
            if (ent.getDynamicProperty("mtc_owner") === owner_id) {
                n_bef_ent2++
                const index = ent.getDynamicProperty("mtc_mark_index")
                marker2s[index] = ent.location
                final_remove_markers.push(ent)
            }
        }
    }

    let init_p1_bz

    {
        let spl_bzs = []
        {
            const bzs = splitBezier(marker0s)
            init_p1_bz = bzs[0]
            let j_len = undefined
            if (n_bef_ent2 > 1) {
                //ポイント向けに分岐の長さ調整
                const bzs = splitBezier(marker2s)
                let t
                for (t = 0; t <= 1; t += 0.001) {
                    const p_now = getBezier(bzs[0][0], bzs[0][1], bzs[0][2], t)
                    const t_near = getBezierNeart(init_p1_bz[0], init_p1_bz[1], init_p1_bz[2], p_now)
                    const p_near = getBezier(init_p1_bz[0], init_p1_bz[1], init_p1_bz[2], t_near)
                    const d = dist(p_now, p_near)
                    if (d >= 0.5) break
                }
                j_len = Math.min(rail_max_len, bezierLength(bzs[0][0], bzs[0][1], bzs[0][2], 0, t))
            }
            for (let i = 0; i < bzs.length; i++) {
                const bz = bzs[i]
                if (i === 0 && j_len !== undefined) {
                    spl_bzs = spl_bzs.concat(splitBezierDist(bz[0], bz[1], bz[2], rail_max_len, j_len))
                } else {
                    spl_bzs = spl_bzs.concat(splitBezierDist(bz[0], bz[1], bz[2], rail_max_len))
                }
            }
        }

        let bef_po_len = 0
        for (let i = 0; i < spl_bzs.length; i++) {
            const bz = spl_bzs[i]
            let ent = undefined
            while (ent === undefined) {
                try {
                    ticker.teleport(bz[0])
                    await sleep(1)
                    if (i === 0 && n_bef_ent2 > 1) {
                        ent = pl.dimension.spawnEntity("mtc:rail2_" + name_add, bz[0])
                    } else {
                        ent = pl.dimension.spawnEntity("mtc:rail_" + name_add, bz[0])
                    }
                    ent.setDynamicProperty("location", bz[0])
                    suc = true
                } catch (e) {
                }
                if (ent === undefined)
                    await sleep(1)

            }
            pl.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.setrail1" }, { "text": ` : ${Math.round((i + 1) * 100 / spl_bzs.length)} ％` }] })

            if (i === 0)
                init_ent = ent

            let comp_variant = ent.getComponent("minecraft:variant")
            if (comp_variant !== undefined) {
                y_offset = comp_variant.value * 0.01
            }

            let bz1 = { x: bz[0].x, y: bz[0].y + y_offset, z: bz[0].z }
            let bz2 = { x: bz[1].x, y: bz[1].y + y_offset, z: bz[1].z }
            let bz3 = { x: bz[2].x, y: bz[2].y + y_offset, z: bz[2].z }
            ent.setDynamicProperty("mtc_bz_p1", bz1)
            ent.setDynamicProperty("mtc_bz_p2", bz2)
            ent.setDynamicProperty("mtc_bz_p3", bz3)
            if (i === 0 && n_bef_ent2 > 1) {
                ent.setDynamicProperty("mtc_bz1_p1", bz1)
                ent.setDynamicProperty("mtc_bz1_p2", bz2)
                ent.setDynamicProperty("mtc_bz1_p3", bz3)
            }
            ent.setDynamicProperty("mtc_tlm", tlm)
            ent.setDynamicProperty("mtc_vrail", vrail)
            ent.setDynamicProperty("mtc_joint", joint)

            if (!rani_off) ent.setDynamicProperty("mtc_pani_off", 1);

            /*
            if (po_sel > 0) {
                const rail_len = bezierLength(bz[0], bz[1], bz[2], 0, 1)
                let n_po = 0
                for (let j = 0; j < rail_len; j++) {
                    if (j - bef_po_len >= 0) {
                        n_po++
                        bef_po_len += po_sel
                        ent.setDynamicProperty("mtc_po_m" + n_po, (j + 1))
                    }
                }
                ent.setDynamicProperty("mtc_po_n", n_po)
                bef_po_len -= rail_len
            }
            */

            if (tunnel) {
                await sleep(5)
                makeTunnel(ent.dimension, bz[0], bz[1], bz[2], dl, dr, du, dd)
            }

            const dir = bezierTangent(bz1, bz2, bz3, 0)
            const deg = Math.atan2(-dir.x, dir.z) * 57.29578
            const deg2 = Math.round(deg / 45) * 45
            ent.setRotation({ x: 0, y: deg2 })
            const offset = deg - deg2
            if (i === 0)
                init_offert = offset

            //animation info
            const bz_len = bezierLength(bz1, bz2, bz3, 0, 1)
            const n_sec = Math.ceil(bz_len * 2)
            const over = Math.ceil(bz_len * 2) / 2 - bz_len
            let degs_y = []
            let degs_x = []
            const dir_first = bezierTangent(bz1, bz2, bz3, 0)
            let stack_y = Math.atan2(-dir_first.x, dir_first.z) * 57.29578 - offset
            let stack_x = 0
            if (i === 0)
                init_y1 = stack_y

            let rail_head = { x: bz1.x, y: bz1.y, z: bz1.z }

            for (let j = 0; j < n_sec; j++) {
                let t = 0.5
                let df = 0.25
                if (j == n_sec - 1) {
                    t = 1
                } else {
                    for (let i = 0; i < 32; i++) {
                        const d = bezierLength(bz1, bz2, bz3, 0, t)
                        if (d > (j + 1) * rail_unit_size) {
                            t -= df
                        } else {
                            t += df
                        }
                        df *= 0.5
                    }
                }
                const tpos = getBezier(bz1, bz2, bz3, t)
                let deg_y = Math.round(Math.atan2(-(tpos.x - rail_head.x), (tpos.z - rail_head.z)) * 57.29578 - stack_y)
                if (deg_y > 180)
                    deg_y -= 360
                if (deg_y < -180)
                    deg_y += 360
                let deg_x = Math.round(Math.atan2((tpos.y - rail_head.y), Math.sqrt((tpos.z - rail_head.z) ** 2 + (tpos.x - rail_head.x) ** 2)) * 57.29578 - stack_x)


                if (j == n_sec - 1) {
                    const dir = bezierTangent(bz1, bz2, bz3, t)
                    deg_y = Math.round(Math.atan2(-dir.x, dir.z) * 57.29578 - stack_y)
                    if (deg_y > 180)
                        deg_y -= 360
                    if (deg_y < -180)
                        deg_y += 360
                    deg_x = Math.round(Math.atan2(dir.y, Math.sqrt(dir.z ** 2 + dir.x ** 2)) * 57.29578 - stack_x)
                }

                degs_y.push(deg_y)
                degs_x.push(deg_x)
                stack_y += deg_y
                stack_x += deg_x

                let step = rail_unit_size
                if (j == n_sec - 1)
                    step = rail_unit_size - over

                rail_head.y += step * Math.sin(stack_x * 0.0174533)
                const hy_r = Math.cos(stack_x * 0.0174533)
                rail_head.z += hy_r * step * Math.cos(stack_y * 0.0174533)
                rail_head.x -= hy_r * step * Math.sin(stack_y * 0.0174533)
            }

            setState(ent, "mtc_rail_rest_rot", 20)  //強制回転階数(tick5関数で消費しながら回転)
            if (n_sec === 0) {
                ent.setDynamicProperty("n_s", 1)
                ent.setDynamicProperty(`s1_lr`, 0)
                ent.setDynamicProperty(`s1_ud`, 0)
            } else {
                ent.setDynamicProperty("n_s", n_sec)
            }
            for (let j = 0; j < n_sec; j++) {
                const deg_y = degs_y[j]
                const deg_x = degs_x[j]
                ent.setDynamicProperty(`s${j + 1}_lr`, deg_y)
                ent.setDynamicProperty(`s${j + 1}_ud`, deg_x)
            }
        }
    }

    if (n_bef_ent2 > 1) {
        {
            let spl_bzs = []
            {
                const bzs = splitBezier(marker2s)

                //ポイント向けに分岐の長さ調整
                let t
                for (t = 0; t <= 1; t += 0.001) {
                    const p_now = getBezier(bzs[0][0], bzs[0][1], bzs[0][2], t)
                    const t_near = getBezierNeart(init_p1_bz[0], init_p1_bz[1], init_p1_bz[2], p_now)
                    const p_near = getBezier(init_p1_bz[0], init_p1_bz[1], init_p1_bz[2], t_near)
                    const d = dist(p_now, p_near)
                    if (d >= 0.3) break
                }
                const j_len = Math.min(rail_max_len, bezierLength(bzs[0][0], bzs[0][1], bzs[0][2], 0, t))

                for (let i = 0; i < bzs.length; i++) {
                    const bz = bzs[i]
                    if (i === 0) {
                        spl_bzs = spl_bzs.concat(splitBezierDist(bz[0], bz[1], bz[2], rail_max_len, j_len))
                    } else {
                        spl_bzs = spl_bzs.concat(splitBezierDist(bz[0], bz[1], bz[2], rail_max_len))
                    }
                }
            }

            let bef_po_len = 0
            for (let i = 0; i < spl_bzs.length; i++) {
                const bz = spl_bzs[i]
                let ent = undefined
                if (i === 0) {
                    ent = init_ent
                } else {
                    while (ent === undefined) {
                        try {
                            ticker.teleport(bz[0])
                            await sleep(1)
                            ent = pl.dimension.spawnEntity("mtc:rail_" + name_add, bz[0])
                            ent.setDynamicProperty("location", bz[0])
                            suc = true
                        } catch (e) {
                        }
                        if (ent === undefined)
                            await sleep(1)

                    }

                }
                pl.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.setrail2" }, { "text": ` : ${Math.round((i + 1) * 100 / spl_bzs.length)} ％` }] })

                let comp_variant = ent.getComponent("minecraft:variant")
                if (comp_variant !== undefined) {
                    y_offset = comp_variant.value * 0.01
                }

                let bz1 = { x: bz[0].x, y: bz[0].y + y_offset, z: bz[0].z }
                let bz2 = { x: bz[1].x, y: bz[1].y + y_offset, z: bz[1].z }
                let bz3 = { x: bz[2].x, y: bz[2].y + y_offset, z: bz[2].z }

                let offset
                if (i === 0) {
                    ent.setDynamicProperty("mtc_bz2_p1", bz1)
                    ent.setDynamicProperty("mtc_bz2_p2", bz2)
                    ent.setDynamicProperty("mtc_bz2_p3", bz3)
                    offset = init_offert
                } else {
                    ent.setDynamicProperty("mtc_bz_p1", bz1)
                    ent.setDynamicProperty("mtc_bz_p2", bz2)
                    ent.setDynamicProperty("mtc_bz_p3", bz3)
                    ent.setDynamicProperty("mtc_tlm", tlm)
                    ent.setDynamicProperty("mtc_vrail", vrail)
                    ent.setDynamicProperty("mtc_joint", joint)

                    const dir = bezierTangent(bz1, bz2, bz3, 0)
                    const deg = Math.atan2(-dir.x, dir.z) * 57.29578
                    const deg2 = Math.round(deg / 45) * 45
                    ent.setRotation({ x: 0, y: deg2 })
                    offset = deg - deg2
                }

                if (!rani_off) ent.setDynamicProperty("mtc_pani_off", 1);


                if (tunnel) {
                    await sleep(5)
                    makeTunnel(ent.dimension, bz[0], bz[1], bz[2], dl, dr, du, dd)
                }

                //animation info
                const bz_len = bezierLength(bz1, bz2, bz3, 0, 1)
                const n_sec = Math.ceil(bz_len * 2)
                const over = Math.ceil(bz_len * 2) / 2 - bz_len
                let degs_y = []
                let degs_x = []
                const dir_first = bezierTangent(bz1, bz2, bz3, 0)
                let stack_y = Math.atan2(-dir_first.x, dir_first.z) * 57.29578 - offset
                let stack_x = 0
                let diff = stack_y - init_y1
                if (diff > 180)
                    diff -= 360
                if (diff < -180)
                    diff += 360
                if (i === 0)
                    stack_y -= diff

                let rail_head = { x: bz1.x, y: bz1.y, z: bz1.z }

                for (let j = 0; j < n_sec; j++) {
                    let t = 0.5
                    let df = 0.25
                    if (j == n_sec - 1) {
                        t = 1
                    } else {
                        for (let i = 0; i < 32; i++) {
                            const d = bezierLength(bz1, bz2, bz3, 0, t)
                            if (d > (j + 1) * rail_unit_size) {
                                t -= df
                            } else {
                                t += df
                            }
                            df *= 0.5
                        }
                    }

                    const tpos = getBezier(bz1, bz2, bz3, t)
                    let deg_y = Math.round(Math.atan2(-(tpos.x - rail_head.x), (tpos.z - rail_head.z)) * 57.29578 - stack_y)
                    if (deg_y > 180)
                        deg_y -= 360
                    if (deg_y < -180)
                        deg_y += 360
                    let deg_x = Math.round(Math.atan2((tpos.y - rail_head.y), Math.sqrt((tpos.z - rail_head.z) ** 2 + (tpos.x - rail_head.x) ** 2)) * 57.29578 - stack_x)

                    if (j == n_sec - 1) {
                        const dir = bezierTangent(bz1, bz2, bz3, t)
                        deg_y = Math.round(Math.atan2(-dir.x, dir.z) * 57.29578 - stack_y)
                        if (deg_y > 180)
                            deg_y -= 360
                        if (deg_y < -180)
                            deg_y += 360
                        deg_x = Math.round(Math.atan2(dir.y, Math.sqrt(dir.z ** 2 + dir.x ** 2)) * 57.29578 - stack_x)
                    }

                    degs_y.push(deg_y)
                    degs_x.push(deg_x)
                    stack_y += deg_y
                    stack_x += deg_x

                    let step = rail_unit_size
                    if (j == n_sec - 1)
                        step = rail_unit_size - over

                    rail_head.y += step * Math.sin(stack_x * 0.0174533)
                    const hy_r = Math.cos(stack_x * 0.0174533)
                    rail_head.z += hy_r * step * Math.cos(stack_y * 0.0174533)
                    rail_head.x -= hy_r * step * Math.sin(stack_y * 0.0174533)
                }

                setState(ent, "mtc_rail_rest_rot", 20)  //強制回転階数(tick5関数で消費しながら回転)

                if (i === 0) {
                    if (n_sec === 0) {
                        ent.setDynamicProperty("n_p2s", 1)
                        ent.setDynamicProperty(`p2s1_lr`, 0)
                        ent.setDynamicProperty(`p2s1_ud`, 0)
                    } else {
                        ent.setDynamicProperty("n_p2s", n_sec)
                    }

                    for (let j = 0; j < n_sec; j++) {
                        const deg_y = degs_y[j]
                        const deg_x = degs_x[j]
                        ent.setDynamicProperty(`p2s${j + 1}_lr`, deg_y)
                        ent.setDynamicProperty(`p2s${j + 1}_ud`, deg_x)
                    }
                } else {
                    if (n_sec === 0) {
                        ent.setDynamicProperty("n_s", 1)
                        ent.setDynamicProperty(`s1_lr`, 0)
                        ent.setDynamicProperty(`s1_ud`, 0)
                    } else {
                        ent.setDynamicProperty("n_s", n_sec)
                    }

                    for (let j = 0; j < n_sec; j++) {
                        const deg_y = degs_y[j]
                        const deg_x = degs_x[j]
                        ent.setDynamicProperty(`s${j + 1}_lr`, deg_y)
                        ent.setDynamicProperty(`s${j + 1}_ud`, deg_x)
                    }
                }

            }
        }

    }

    for (const ent of final_remove_markers) {
        ent.remove()
    }

    ticker.remove()
    pl.sendMessage({ rawtext: [{ "translate": "mtc:mtc.ui.setrailok" }] })

}

function command(source, command) {
    system.run(() => {
        source.runCommand("execute as \"" + source.name + "\" at @s run " + command)
    })
}

function playAni(ent, ani, con = "", ply = null) {

    if (ply === null) {
        /*
        ent.playAnimation(ani, { controller: con, nextState: ""})
        */
        const pls = ent.dimension.getEntities({ type: "player", location: ent.location, maxDistance: 77 })
        let pls_name = []
        for (const pl of pls) {
            pls_name.push(pl.name)
        }
        if (pls_name.length > 0) ent.playAnimation(ani, { controller: con, nextState: "", players: pls_name });

    } else {
        ent.playAnimation(ani, { controller: con, nextState: "", players: [ply] })
    }
}

function stopAni(ent, con = "", ply = null) {
    if (ply === null) {
        ent.playAnimation("animation.npc.general", { controller: con, nextState: "" })
    } else {
        ent.playAnimation("animation.npc.general", { controller: con, nextState: "", players: [ply] })
    }
}

//同一編成エンティティ取得
function getFormation(ent) {
    const ents = bodies_g
    const t_fid = obj_mtc_fid.getScore(ent)
    let ret = []
    for (const ent2 of ents) {
        const fid = obj_mtc_fid.getScore(ent2)
        if (fid == t_fid) {
            ret.push(ent2)
        }
    }
    return ret
}

function getSelectorEntities(selector, player) {
    const id = "ID_" + Math.floor(Math.random() * 1000000000000000);

    let err = true
    while (err) {
        try {
            player.runCommand("tag " + selector + " add " + id)
            var ents = player.dimension.getEntities({ tags: [id] })
            for (const ent of ents) {
                ent.removeTag(id)
            }
            err = false
        } catch (e) {

        }
    }
    return ents
}

function getSelectorEntities2(selector, dim) {
    const id = "ID_" + Math.floor(Math.random() * 1000000000000000);
    let err = true
    while (err) {
        try {
            dim.runCommand("tag " + selector + " add " + id)
            var ents = dim.getEntities({ tags: [id] })
            for (const ent of ents) {
                ent.removeTag(id)
            }
            err = false
        } catch (e) {

        }
    }

    return ents
}

// 席を考慮した最寄り車両クラス取得
function getNearestCar(player) {
    let player_nearcar = null
    let player_nearD = 3.4e38

    if (bodies_g.length > 0) {
        for (const ent of bodies_g) {
            const rot = ent.getRotation()
            const loc = ent.location

            const bx_ux = Math.cos(0.0174533 * rot.y) * Math.cos(0.0174533 * rot.x)
            const bx_uy = Math.sin(0.0174533 * rot.x)
            const bx_uz = -Math.sin(0.0174533 * rot.y) * Math.cos(0.0174533 * rot.x)

            const by_ux = -Math.sin(0.0174533 * rot.x) * Math.cos(0.0174533 * rot.y)
            const by_uy = Math.cos(0.0174533 * rot.x)
            const by_uz = Math.sin(0.0174533 * rot.x) * Math.sin(0.0174533 * rot.y)

            const bz_ux = Math.sin(0.0174533 * rot.y)
            const bz_uy = 0
            const bz_uz = Math.cos(0.0174533 * rot.y)

            const seats_cp = ent.getComponent("minecraft:rideable")
            let seats = []
            if (seats_cp !== undefined) seats = seats_cp.getSeats()

            for (const seat of seats) {
                const sx = loc.x + seat.position.x * bx_ux + seat.position.y * bx_uy + seat.position.z * bx_uz
                const sy = loc.y + seat.position.x * by_ux + seat.position.y * by_uy + seat.position.z * by_uz
                const sz = loc.z + seat.position.x * bz_ux + seat.position.y * bz_uy + seat.position.z * bz_uz
                const d = Math.sqrt((player.location.x - sx) ** 2 + (player.location.y - sy) ** 2 + (player.location.z - sz) ** 2)
                if (d < player_nearD) {
                    player_nearD = d
                    player_nearcar = ent
                }
            }
            const d = dist(player.location, loc)
            if (d < player_nearD) {
                player_nearD = d
                player_nearcar = ent
            }

        }
    }

    return player_nearcar
}

// trg EntityにTASCセット
function tascSet(trg, x) {
    // tascモード
    trg.addTag("mtc_tasc")
    let now = trg.getDynamicProperty("dist")
    if (now === undefined) {
        trg.setDynamicProperty("dist", 0.0)
        now = 0.0
    }
    trg.setDynamicProperty("tasc_dist", now + x)
    trg.removeTag("mtc_tasc_do")
    trg.setDynamicProperty("tasc_b_mid", (-world.scoreboard.getObjective("mtc_notBM").getScore(trg) + 1) * world.scoreboard.getObjective("mtc_accDB").getScore(trg))
}


function dist(vec1, vec2) {
    return Math.sqrt((vec1.x - vec2.x) ** 2 + (vec1.y - vec2.y) ** 2 + (vec1.z - vec2.z) ** 2)
}
function dist2(vec1, vec2) {
    return ((vec1.x - vec2.x) ** 2 + (vec1.y - vec2.y) ** 2 + (vec1.z - vec2.z) ** 2)
}
//entの音を聞かせるプレーヤー選択
function testSound(ent, ents_f = undefined) {
    // 車両から実行
    // 同一編成calc3=0
    const ent_clen = ent.getDynamicProperty("mtc_body_length") / 2
    if (ents_f === undefined) {
        ents_f = getFormation(ent)
    }

    for (const pl of players_g) {
        let min = 1.0e30
        for (const ent_f of ents_f) {
            if (!ent_f.hasTag("mtc_nrs")) {
                const loc = ent_f.location
                const roty = ent_f.getRotation().y
                const bx_uz = -Math.sin(0.0174533 * roty)
                const by_uz = 0
                const bz_uz = Math.cos(0.0174533 * roty)

                const s = {
                    x: loc.x + ent_clen * bx_uz,
                    y: loc.y + ent_clen * by_uz,
                    z: loc.z + ent_clen * bz_uz
                }

                const d2 = dist2(pl.location, s)
                if (d2 < min) {
                    min = d2
                    if (ent.id === ent_f.id) {
                        obj_mtc_sid.setScore(pl, 0)
                    } else {
                        obj_mtc_sid.setScore(pl, 1)
                    }
                }
            }

        }
    }
    //ent.runCommand("execute as @a at @s run scoreboard players operation @s mtc_sid = @e[family=mtc_body,tag=!mtc_nrs,scores={mtc_calc3=0},c=1] mtc_uid")
    // 対象者のsid=0
    //ent.runCommand("scoreboard players operation @a mtc_sid -= @s mtc_uid")
}

//mtc:mtcXXXX_[car]からmtcXXXXを切り出し
function getIdBase(s) {
    let names = s.split(":")[1].split("_")
    let name = ""
    for (let i = 0; i < names.length - 2; i++) {
        name += names[i] + "_"
    }
    return name + names[names.length - 2]

}

/**
 * mode_text文法
 * ~2,4,6~8,10~ -> ~2,4,6,6,8,10~
 */
function testMode(mode_text, mode_id) {
    let res = false
    const strs = mode_text.split(",")
    for (const t of strs) {
        const spl = t.split("~")
        if (t.search("^-?[0-9]+~-?[0-9]+$") != -1) {
            if (mode_id >= Number(spl[0]) && mode_id <= Number(spl[1])) {
                res = true
                break
            }
        } else if (t.search("^~-?[0-9]+$") != -1) {
            if (mode_id <= Number(spl[1])) {
                res = true
                break
            }

        } else if (t.search("^-?[0-9]+~$") != -1) {
            if (mode_id >= Number(spl[0])) {
                res = true
                break
            }

        } else if (t.search("^-?[0-9]+$") != -1) {
            if (mode_id == Number(spl[0])) {
                res = true
                break
            }

        } else {
            world.sendMessage("§cCommand Syntax Error!")
            break
        }

    }
    return res
}

function solveCubic(a, b, c, d) {
    if (Math.abs(a) < 1e-3) {
        if (Math.abs(b) < 1e-3) {
            if (Math.abs(c) < 1e-3) {
                //Dim=0
                return []
            } else {
                //Dim=1
                return [-d / c]
            }
        } else {
            //Dim=2
            const D = c * c - 4 * b * d
            if (D < 0) {
                return [(-c + Math.sqrt(D)) / (2 * b), (-c - Math.sqrt(D)) / (2 * b)]
            } else if (D > 0) {
                return [-c / (2 * b)]
            } else {
                return []
            }

        }
    }

    // Normalize coefficients
    b /= a;
    c /= a;
    d /= a;

    const p = (3 * c - b * b) / 3;
    const q = (2 * b * b * b - 9 * b * c + 27 * d) / 27;

    const discriminant = (q * q) / 4 + (p * p * p) / 27;

    if (discriminant > 0) {
        const u = Math.cbrt(-q / 2 + Math.sqrt(discriminant));
        const v = Math.cbrt(-q / 2 - Math.sqrt(discriminant));
        const x1 = u + v - b / 3;
        return [x1];
    } else if (discriminant === 0) {
        const u = Math.cbrt(-q / 2);
        const x1 = 2 * u - b / 3;
        const x2 = -u - b / 3;
        return [x1, x2];
    } else {
        const r = Math.sqrt(-(p * p * p) / 27);
        const phi = Math.acos(-q / (2 * r));
        const x1 = 2 * Math.cbrt(r) * Math.cos(phi / 3) - b / 3;
        const x2 = 2 * Math.cbrt(r) * Math.cos((phi + 2 * Math.PI) / 3) - b / 3;
        const x3 = 2 * Math.cbrt(r) * Math.cos((phi + 4 * Math.PI) / 3) - b / 3;
        return [x1, x2, x3];
    }
}

//左から始点制御点終点
function getBezier(p1, p2, p3, t) {
    return { x: (t * t * p3.x + 2 * t * (1 - t) * p2.x + (1 - t) * (1 - t) * p1.x), y: (t * t * p3.y + 2 * t * (1 - t) * p2.y + (1 - t) * (1 - t) * p1.y), z: (t * t * p3.z + 2 * t * (1 - t) * p2.z + (1 - t) * (1 - t) * p1.z) }
}

//左から始点制御点終点
function getBezierNeart(p1, p2, p3, p) {

    //直線検出
    const va1 = p2.x - p1.x
    const va2 = p2.y - p1.y
    const va3 = p2.z - p1.z
    const vb1 = p3.x - p2.x
    const vb2 = p3.y - p2.y
    const vb3 = p3.z - p2.z
    const del = Math.abs(va2 * vb3 - va3 * vb2) + Math.abs(va3 * vb1 - vb3 * va1) + Math.abs(va1 * vb2 - vb1 * va2)

    if (del < 0.001) {
        p2.x = (p1.x + p3.x) / 2
        p2.y = (p1.y + p3.y) / 2
        p2.z = (p1.z + p3.z) / 2
    }

    let a = 4 * (p3.x ** 2) - 16 * p3.x * p2.x + 8 * p3.x * p1.x + 16 * (p2.x ** 2) - 16 * p2.x * p1.x + 4 * (p1.x ** 2)
    let b = 12 * p3.x * p2.x - 12 * p3.x * p1.x - 24 * (p2.x ** 2) + 36 * p2.x * p1.x - 12 * (p1.x ** 2)
    let c = 4 * p3.x * p1.x - 4 * p3.x * p.x + 8 * (p2.x ** 2) - 24 * p2.x * p1.x + 8 * p2.x * p.x + 12 * (p1.x ** 2) - 4 * p1.x * p.x
    let d = 4 * p2.x * p1.x - 4 * p2.x * p.x - 4 * (p1.x ** 2) + 4 * p1.x * p.x

    a += 4 * (p3.y ** 2) - 16 * p3.y * p2.y + 8 * p3.y * p1.y + 16 * (p2.y ** 2) - 16 * p2.y * p1.y + 4 * (p1.y ** 2)
    b += 12 * p3.y * p2.y - 12 * p3.y * p1.y - 24 * (p2.y ** 2) + 36 * p2.y * p1.y - 12 * (p1.y ** 2)
    c += 4 * p3.y * p1.y - 4 * p3.y * p.y + 8 * (p2.y ** 2) - 24 * p2.y * p1.y + 8 * p2.y * p.y + 12 * (p1.y ** 2) - 4 * p1.y * p.y
    d += 4 * p2.y * p1.y - 4 * p2.y * p.y - 4 * (p1.y ** 2) + 4 * p1.y * p.y

    a += 4 * (p3.z ** 2) - 16 * p3.z * p2.z + 8 * p3.z * p1.z + 16 * (p2.z ** 2) - 16 * p2.z * p1.z + 4 * (p1.z ** 2)
    b += 12 * p3.z * p2.z - 12 * p3.z * p1.z - 24 * (p2.z ** 2) + 36 * p2.z * p1.z - 12 * (p1.z ** 2)
    c += 4 * p3.z * p1.z - 4 * p3.z * p.z + 8 * (p2.z ** 2) - 24 * p2.z * p1.z + 8 * p2.z * p.z + 12 * (p1.z ** 2) - 4 * p1.z * p.z
    d += 4 * p2.z * p1.z - 4 * p2.z * p.z - 4 * (p1.z ** 2) + 4 * p1.z * p.z

    if (del < 0.001) {
        if (Math.abs(a) < 1e-2) a = 0;
        if (Math.abs(a) < 1e-2 && Math.abs(b) < 1e-2) b = 0;
    }

    const res = solveCubic(a, b, c, d);
    let min = (p.x - p3.x) ** 2 + (p.y - p3.y) ** 2 + (p.z - p3.z) ** 2
    let to = 1
    const p3d2 = (p.x - p1.x) ** 2 + (p.y - p1.y) ** 2 + (p.z - p1.z) ** 2
    if (p3d2 < min) {
        min = p3d2
        to = 0
    }
    for (const r of res) {
        if (r <= 1 && r >= 0) {
            const po = getBezier(p1, p2, p3, r)
            const d2 = (po.x - p.x) ** 2 + (po.y - p.y) ** 2 + (po.z - p.z) ** 2
            if (d2 < min) {
                min = d2
                to = r
            }
        }
    }

    return to
}


//左から始点制御点終点
//t0<=t1
function bezierLength(p0, p1, p2, t0, t1) {

    //直線検出
    const va1 = p1.x - p0.x
    const va2 = p1.y - p0.y
    const va3 = p1.z - p0.z
    const vb1 = p2.x - p1.x
    const vb2 = p2.y - p1.y
    const vb3 = p2.z - p1.z
    const del = Math.abs(va2 * vb3 - va3 * vb2) + Math.abs(va3 * vb1 - vb3 * va1) + Math.abs(va1 * vb2 - vb1 * va2)

    if (del < 0.001) {
        p1.x = (p0.x + p2.x) / 2
        p1.y = (p0.y + p2.y) / 2
        p1.z = (p0.z + p2.z) / 2
    }

    const u0 = p0.x - p1.x
    const v0 = p0.y - p1.y
    const w0 = p0.z - p1.z
    const u1 = p0.x - 2 * p1.x + p2.x
    const v1 = p0.y - 2 * p1.y + p2.y
    const w1 = p0.z - 2 * p1.z + p2.z

    const a = u1 ** 2 + v1 ** 2 + w1 ** 2
    const b = u1 * u0 + v1 * v0 + w1 * w0
    const c = u0 ** 2 + v0 ** 2 + w0 ** 2
    const d = a * c - b ** 2

    let l = 0

    if (a > 1e-3) {
        if (d > 1e-3) {
            const x1 = (a * t1 - b) / Math.sqrt(d)
            const x0 = (a * t0 - b) / Math.sqrt(d)
            l = d * ((Math.log(x1 + Math.sqrt(x1 ** 2 + 1)) + x1 * Math.sqrt(x1 ** 2 + 1)) - (Math.log(x0 + Math.sqrt(x0 ** 2 + 1)) + x0 * Math.sqrt(x0 ** 2 + 1))) / (a * Math.sqrt(a))
        } else {
            l = ((a * t1 - b) * Math.abs((a * t1 - b)) - (a * t0 - b) * Math.abs((a * t0 - b))) / (a * Math.sqrt(a))
        }
    } else {
        l = 2 * Math.sqrt(c) * (t1 - t0)
    }
    return l
}

//接線
function bezierTangent(p1, p2, p3, t) {
    const v1x = (1 - t) * p1.x + t * p2.x
    const v1y = (1 - t) * p1.y + t * p2.y
    const v1z = (1 - t) * p1.z + t * p2.z
    const v2x = (1 - t) * p2.x + t * p3.x
    const v2y = (1 - t) * p2.y + t * p3.y
    const v2z = (1 - t) * p2.z + t * p3.z
    return { x: v2x - v1x, y: v2y - v1y, z: v2z - v1z }
}

function splitBezier(points) {
    const n_points = points.length

    if (n_points == 1) {
        return [[points[0], points[0], points[0]]]
    } else if (n_points == 2) {
        const c = { x: (points[0].x + points[1].x) / 2, y: (points[0].y + points[1].y) / 2, z: (points[0].z + points[1].z) / 2 }
        return [[points[0], c, points[1]]]
    } else if (n_points == 3) {
        return [[points[0], points[1], points[2]]]
    } else {
        let p1 = points[0]
        let p2 = { x: (points[1].x + points[2].x) / 2, y: (points[1].y + points[2].y) / 2, z: (points[1].z + points[2].z) / 2 }
        let res = [[p1, points[1], p2]]
        for (let i = 0; i < n_points - 4; i++) {
            p1 = p2
            p2 = { x: (points[i + 2].x + points[i + 3].x) / 2, y: (points[i + 2].y + points[i + 3].y) / 2, z: (points[i + 2].z + points[i + 3].z) / 2 }
            res.push([p1, points[i + 2], p2])
        }
        p1 = p2
        res.push([p1, points[n_points - 2], points[n_points - 1]])
        return res
    }
}

function splitBezierDist(p1, p2, p3, max_len, j_len = undefined) {

    //直線検出
    const va1 = p2.x - p1.x
    const va2 = p2.y - p1.y
    const va3 = p2.z - p1.z
    const vb1 = p3.x - p2.x
    const vb2 = p3.y - p2.y
    const vb3 = p3.z - p2.z
    const del = Math.abs(va2 * vb3 - va3 * vb2) + Math.abs(va3 * vb1 - vb3 * va1) + Math.abs(va1 * vb2 - vb1 * va2)

    if (del < 0.001) {
        p2.x = (p1.x + p3.x) / 2
        p2.y = (p1.y + p3.y) / 2
        p2.z = (p1.z + p3.z) / 2
    }


    let min_len = max_len
    if (j_len !== undefined) min_len = j_len
    let splits = []
    const org_len = bezierLength(p1, p2, p3, 0, 1)
    if (org_len <= min_len) {
        splits.push([p1, p2, p3])
    } else {
        let n_split
        let new_len
        if (j_len === undefined) {
            n_split = Math.ceil(org_len / max_len)
            new_len = org_len / n_split
        } else {
            n_split = Math.ceil((org_len - j_len) / max_len) + 1
            new_len = (org_len - j_len) / (n_split - 1)
        }

        let new_len2
        for (let i = 0; i < n_split - 1; i++) {
            if (i == 0 && j_len !== undefined) {
                new_len2 = j_len
            } else {
                new_len2 = new_len
            }
            let t = 0.5
            let df = 0.25
            for (let i = 0; i < 32; i++) {
                const d = bezierLength(p1, p2, p3, 0, t)
                if (d > new_len2) {
                    t -= df
                } else {
                    t += df
                }
                df *= 0.5
            }


            const new_p2 = { x: p2.x * t + p1.x * (1 - t), y: p2.y * t + p1.y * (1 - t), z: p2.z * t + p1.z * (1 - t) }
            const new_p3 = getBezier(p1, p2, p3, t)

            splits.push([p1, new_p2, new_p3])

            p1 = new_p3
            p2 = { x: p3.x * t + p2.x * (1 - t), y: p3.y * t + p2.y * (1 - t), z: p3.z * t + p2.z * (1 - t) }
        }
        //最後の1線
        splits.push([p1, p2, p3])
    }
    return splits
}

function warnVec3(p) {
    console.warn("Vec3 : " + p.x + ", " + p.y + ", " + p.z)
}


//載っているかの判定まで行う
function trace_newrail(ent, ent_f) {
    //const ent_f = getFormation(ent)
    let tilt_ud = 0
    let n_tilt_ud = 0
    for (const ent of ent_f) {
        const ret = trace_newrail2(ent)
        if (ret !== undefined) {
            tilt_ud += ret
            n_tilt_ud++
        }
    }
    if (n_tilt_ud > 0) {
        tilt_ud /= n_tilt_ud
    }
    let sign = 1
    if (ent.hasTag("mtc_rev")) {
        sign *= -1
    }

    let acc = Math.abs(17640 * Math.sin(tilt_ud * 0.0174533))
    if (tilt_ud > 0) {
        obj_mtc_gradacc.setScore(ent, -sign * acc)
    } else {
        obj_mtc_gradacc.setScore(ent, sign * acc)
    }
}

function trace_newrail2(ent) {
    const tilt_mode = (world.getDynamicProperty("mtc_tilt") === 1)
    let body_vec = undefined
    let head_vec = undefined
    let search_b = false
    let search_h = false
    let tilt_ud = undefined
    if (!ent.hasTag("mtc_on_newrail_b")) {
        //body,head両方独立で線路上にいるか確認
        // いなければレール追従探索
        const loc = ent.location
        const rot = ent.getRotation()

        const on_rail = testOnRail(ent, { x: loc.x, y: loc.y + 1, z: loc.z }, rot)
        if (!on_rail) {
            search_b = true
            ent.addTag("mtc_on_newrail_b")
        } else {
            setState(ent, "mtc_railb_rot", undefined)
        }
    }
    if (!ent.hasTag("mtc_on_newrail_h") && (ent.hasTag("mtc_parent") || tilt_mode)) {
        //body,head両方独立で線路上にいるか確認
        // いなければレール追従探索
        const loc = ent.location
        let deg = ent.getRotation().y
        const def_d_length = ent.getDynamicProperty("mtc_d_length")

        const rot = { x: 0, y: deg }
        const bx_uz = -Math.sin(0.0174533 * deg)
        const by_uz = 0
        const bz_uz = Math.cos(0.0174533 * deg)

        const sx = loc.x + def_d_length * bx_uz
        const sy = loc.y + def_d_length * by_uz + 2
        const sz = loc.z + def_d_length * bz_uz
        const head_loc = { x: sx, y: sy, z: sz }
        const on_rail = testOnRail(ent, head_loc, rot)
        if (!on_rail) {
            search_h = true
            ent.addTag("mtc_on_newrail_h")
        } else {
            setState(ent, "mtc_railh_rot", undefined)
        }
    }

    let bp = undefined
    let bt, bp1, bp2, bp3
    if (ent.hasTag("mtc_on_newrail_b")) {
        let p1, p2, p3, tlm, vrail, t, p, d2, d22, joint
        let old_deg = undefined
        let loc = ent.location
        const rot_y = ent.getRotation().y
        let dd_len = 0
        const db_length = ent.getDynamicProperty("mtc_d_length")
        if (db_length !== undefined) {
            const dbody_length = ent.getDynamicProperty("mtc_body_length")
            if (dbody_length !== undefined) {
                dd_len = dbody_length - db_length
                if (dd_len > db_length - 1) dd_len = db_length - 1
                if (dd_len < 0) dd_len = 0;
            }
        }
        const dz = dd_len * Math.cos(rot_y * 0.0174533)
        const dx = -dd_len * Math.sin(rot_y * 0.0174533)
        let dy = 0
        const deg_x = getState(ent, "mtc_tilt_x")
        if (deg_x !== undefined) {
            dy = dd_len * Math.sin(deg_x * 0.0174533)
        }

        loc.z += dz
        loc.x += dx
        loc.y += dy

        if (!search_b) {
            p1 = ent.getDynamicProperty("mtc_body_p1")
            if (p1 === undefined) {
                search_b = true
            } else {
                p2 = ent.getDynamicProperty("mtc_body_p2")
                p3 = ent.getDynamicProperty("mtc_body_p3")
                tlm = ent.getDynamicProperty("mtc_body_tlm")
                vrail = ent.getDynamicProperty("mtc_body_vrail")
                joint = ent.getDynamicProperty("mtc_joint")
                t = getBezierNeart(p1, p2, p3, loc)

                let t2
                if (t < 0.5) t2 = 0
                if (t >= 0.5) t2 = 1
                const vec = bezierTangent(p1, p2, p3, t2)
                old_deg = Math.atan2(-vec.x, vec.z) * 57.29578
                setState(ent, "mtc_railb_rot", old_deg)
            }
        }

        if (t === 0 || t === 1 || search_b) {
            const rails = ent.dimension.getEntities({ families: ["mtc_rail"], location: loc, maxDistance: 40 })
            d2 = 1e30
            d22 = 1e30
            let found = false
            for (const rail of rails) {
                const p1x = rail.getDynamicProperty("mtc_bz_p1")
                const p2x = rail.getDynamicProperty("mtc_bz_p2")
                const p3x = rail.getDynamicProperty("mtc_bz_p3")
                const tlmx = rail.getDynamicProperty("mtc_tlm")
                const jointx = rail.getDynamicProperty("mtc_joint")
                const vrailx = rail.getDynamicProperty("mtc_vrail")
                const tx = getBezierNeart(p1x, p2x, p3x, loc)

                const px = getBezier(p1x, p2x, p3x, tx)
                const d2x = dist2(loc, px)
                const dh = Math.abs(loc.y - px.y)
                let d2x2 = d2x
                old_deg = getState(ent, "mtc_railb_rot")
                if (old_deg !== undefined) {
                    let tx2
                    if (tx < 0.5) tx2 = 0
                    if (tx >= 0.5) tx2 = 1
                    const vec = bezierTangent(p1x, p2x, p3x, tx2)
                    let deg_diff = old_deg - Math.atan2(-vec.x, vec.z) * 57.29578
                    if (deg_diff < -180) deg_diff += 360
                    if (deg_diff > 180) deg_diff -= 360
                    if (deg_diff < -90) deg_diff += 180
                    if (deg_diff > 90) deg_diff -= 180
                    d2x2 += Math.abs(deg_diff) * 10
                }
                if (d2x2 < d22 && /*tx !== 0 && tx !== 1 &&*/ dh < 5) {
                    d22 = d2x2
                    d2 = d2x
                    p1 = p1x
                    p2 = p2x
                    p3 = p3x
                    tlm = tlmx
                    vrail = vrailx
                    joint = jointx
                    t = tx
                    p = px
                    found = true
                }
            }
            if (found) {
                ent.setDynamicProperty("mtc_body_p1", p1)
                ent.setDynamicProperty("mtc_body_p2", p2)
                ent.setDynamicProperty("mtc_body_p3", p3)
                ent.setDynamicProperty("mtc_body_tlm", tlm)
                ent.setDynamicProperty("mtc_body_vrail", vrail)
                ent.setDynamicProperty("mtc_joint", joint)
            }
        } else {
            p = getBezier(p1, p2, p3, t)
            d2 = dist2(loc, p)
        }


        let rot = ent.getRotation()
        if (!((t === 0 || t === 1) && d2 > 0) && d2 < 25) {
            body_vec = bezierTangent(p1, p2, p3, t)
            p.z -= dz
            p.x -= dx
            p.y -= dy
            ent.teleport(p)
            bp = p
            bt = t
            bp1 = p1
            bp2 = p2
            bp3 = p3
        } else {
            //線路に戻るときに角度を3°単位に戻す
            rot.y = Math.round(rot.y / 3) * 3
            ent.teleport(ent.location, { rotation: rot })
            //ent.setRotation(rot)
            ent.removeTag("mtc_on_newrail_b")
            ent.setDynamicProperty("mtc_joint", 0)
        }
    }

    if (!tilt_mode) setState(ent, "midcar_trace_deg", undefined);
    if (ent.hasTag("mtc_on_newrail_h") && (ent.hasTag("mtc_parent") || tilt_mode)) {//&& ent.hasTag("mtc_parent")

        //head
        const loc = ent.location
        let deg = ent.getRotation().y
        let def_d_length = ent.getDynamicProperty("mtc_d_length")
        if (def_d_length === undefined) {
            def_d_length = ent.getDynamicProperty("mtc_body_length")
        }

        const bx_uz = -Math.sin(0.0174533 * deg)
        const by_uz = 0
        const bz_uz = Math.cos(0.0174533 * deg)

        const sx = loc.x + def_d_length * bx_uz
        const sy = loc.y + def_d_length * by_uz
        const sz = loc.z + def_d_length * bz_uz
        const head_loc = { x: sx, y: sy, z: sz }


        let p1, p2, p3, tlm, vrail, t, p, d2, d22
        let d2f
        let old_deg = undefined

        if (!search_h) {
            p1 = ent.getDynamicProperty("mtc_head_p1")
            if (p1 === undefined) {
                search_h = true
            } else {
                p2 = ent.getDynamicProperty("mtc_head_p2")
                p3 = ent.getDynamicProperty("mtc_head_p3")
                tlm = ent.getDynamicProperty("mtc_head_tlm")
                vrail = ent.getDynamicProperty("mtc_head_vrail")
                t = getBezierNeart(p1, p2, p3, head_loc)

                let t2
                if (t < 0.5) t2 = 0
                if (t >= 0.5) t2 = 1
                const vec = bezierTangent(p1, p2, p3, t2)
                old_deg = Math.atan2(-vec.x, vec.z) * 57.29578
                setState(ent, "mtc_railh_rot", old_deg)
            }
        }


        if (t === 0 || t === 1 || search_h) {
            const rails = ent.dimension.getEntities({ families: ["mtc_rail"], location: head_loc, maxDistance: 40 })
            d2 = 1e30
            d22 = 1e30
            let found = false
            for (const rail of rails) {
                const p1x = rail.getDynamicProperty("mtc_bz_p1")
                const p2x = rail.getDynamicProperty("mtc_bz_p2")
                const p3x = rail.getDynamicProperty("mtc_bz_p3")
                const tlmx = rail.getDynamicProperty("mtc_tlm")
                const vrailx = rail.getDynamicProperty("mtc_vrail")
                const tx = getBezierNeart(p1x, p2x, p3x, head_loc)

                const px = getBezier(p1x, p2x, p3x, tx)
                const d2x = dist2(head_loc, px)
                const dh = Math.abs(loc.y - px.y)

                let d2x2 = d2x

                old_deg = getState(ent, "mtc_railh_rot")
                if (old_deg !== undefined) {
                    let tx2
                    if (tx < 0.5) tx2 = 0
                    if (tx >= 0.5) tx2 = 1
                    const vec = bezierTangent(p1x, p2x, p3x, tx2)
                    let deg_diff = old_deg - Math.atan2(-vec.x, vec.z) * 57.29578
                    if (deg_diff < -180) deg_diff += 360
                    if (deg_diff > 180) deg_diff -= 360
                    if (deg_diff < -90) deg_diff += 180
                    if (deg_diff > 90) deg_diff -= 180
                    d2x2 += Math.abs(deg_diff) * 10
                }


                if (d2x2 < d22 && /*tx !== 0 && tx !== 1 && */dh < 5) {
                    d22 = d2x2
                    d2 = d2x
                    d2f = (px.x - head_loc.x) ** 2 + (px.z - head_loc.z) ** 2
                    p1 = p1x
                    p2 = p2x
                    p3 = p3x
                    tlm = tlmx
                    vrail = vrailx
                    t = tx
                    p = px
                    found = true
                }
            }
            if (found) {
                ent.setDynamicProperty("mtc_head_p1", p1)
                ent.setDynamicProperty("mtc_head_p2", p2)
                ent.setDynamicProperty("mtc_head_p3", p3)
                ent.setDynamicProperty("mtc_head_tlm", tlm)
                ent.setDynamicProperty("mtc_head_vrail", vrail)
            }
        } else {
            p = getBezier(p1, p2, p3, t)
            d2 = dist2(head_loc, p)
            d2f = (p.x - head_loc.x) ** 2 + (p.z - head_loc.z) ** 2
        }

        if (!((t === 0 || t === 1) && d2f > 0) && d2f < 25) {
            //let deg_y = Math.atan2(-(p.x - loc.x), p.z - loc.z) * 57.29578
            let deg_x = Math.atan2((p.y - loc.y), Math.sqrt((p.x - loc.x) ** 2 + (p.z - loc.z) ** 2)) * 57.29578
            setbodyUd(ent, deg_x)
            tilt_ud = deg_x
            head_vec = bezierTangent(p1, p2, p3, t)

            if (ent.hasTag("mtc_parent")) {
                //ent.setRotation({ x: 0, y: deg_y })//+-180°跨ぐときに挙動が良くない
                ent.teleport(ent.location, { facingLocation: { x: p.x, y: ent.location.y, z: p.z } })
                //ent.teleport(ent.location, {rotation:{x:0,y:deg_y}})
                if (bp !== undefined) {
                    let vec = bezierTangent(bp1, bp2, bp3, bt)
                    const vec_size = Math.sqrt(vec.x ** 2 + vec.y ** 2 + vec.z ** 2)
                    if (vec_size > 0) {
                        const dot = ((p.x - loc.x) * vec.x + (p.y - loc.y) * vec.y + (p.z - loc.z) * vec.z)
                        let sign = 1
                        if (dot < 0)
                            sign *= -1
                        if (ent.hasTag("mtc_rev"))
                            sign *= -1

                        vec.x /= vec_size * sign
                        vec.y /= vec_size * sign
                        vec.z /= vec_size * sign
                        setState(ent, "mtc_prev_uvec", vec)
                    }
                }
            } else {
                setState(ent, "midcar_trace_deg", Math.atan2(-(p.x - loc.x), p.z - loc.z) * 57.29578)
            }

        } else {
            if ((ent.hasTag("mtc_parent") || tilt_mode)) {
                let rot = ent.getRotation()
                rot.y = Math.round(rot.y / 3) * 3
                ent.teleport(ent.location, { rotation: rot })
                //ent.setRotation(rot)
                ent.removeTag("mtc_on_newrail_h")
            }
            setState(ent, "midcar_trace_deg", undefined)
            setbodyUd(ent, 0)
        }


    }
    //カント
    //if (tilt_mode) {
    const deg_y = ent.getRotation().y
    let body_deg
    let head_deg
    let db_length = ent.getDynamicProperty("mtc_d_length")
    if (db_length === undefined) {
        db_length = ent.getDynamicProperty("mtc_body_length")
        if (db_length === undefined)
            db_length = 17.5
    }
    if (body_vec !== undefined) {
        body_deg = Math.atan2(-body_vec.x, body_vec.z) * 57.29578
    } else {
        body_deg = deg_y
    }
    if (head_vec !== undefined) {
        head_deg = Math.atan2(-head_vec.x, head_vec.z) * 57.29578
    } else {
        head_deg = deg_y
    }
    let body_deg_d = body_deg - deg_y
    let head_deg_d = head_deg - deg_y

    if (body_deg_d > 180)
        body_deg_d -= 360
    if (body_deg_d < -180)
        body_deg_d += 360
    if (head_deg_d > 180)
        head_deg_d -= 360
    if (head_deg_d < -180)
        head_deg_d += 360

    if (body_deg_d > 90)
        body_deg_d -= 180
    if (body_deg_d < -90)
        body_deg_d += 180
    if (head_deg_d > 90)
        head_deg_d -= 180
    if (head_deg_d < -90)
        head_deg_d += 180

    let diff = body_deg_d - head_deg_d

    if (Math.abs(diff) > 0) {
        //通過速度
        const vh = ent.getDynamicProperty("mtc_head_vrail")
        const vb = ent.getDynamicProperty("mtc_body_vrail")
        let v = 0
        if (vh !== undefined && vh > v)
            v = vh
        if (vb !== undefined && vb > v)
            v = vb

        //曲率半径
        const r = 0.70710678 * db_length / Math.sqrt(1 - Math.cos(diff * 0.0174533))
        let tlm_max = 0
        const tlm_h = ent.getDynamicProperty("mtc_head_tlm")
        const tlm_b = ent.getDynamicProperty("mtc_body_tlm")
        if (tlm_h !== undefined && tlm_h > tlm_max) {
            tlm_max = tlm_h
        }
        if (tlm_b !== undefined && tlm_b > tlm_max) {
            tlm_max = tlm_b
        }

        //カント各計算
        const tdeg = Math.min(tlm_max, Math.atan2(v * v / r, 127) * 57.29578)
        if (diff > 0) {
            setbodyRl(ent, tdeg)
        } else {
            setbodyRl(ent, -tdeg)
        }

        //台車回転
        let eg_d_dist = ent.getDynamicProperty("mtc_d_length")
        let b_dist = ent.getDynamicProperty("mtc_body_length")
        if (eg_d_dist === undefined) eg_d_dist = 16.9
        const dd_ratio = (eg_d_dist * 2 - b_dist) / eg_d_dist

        const body_deg_dx = head_deg_d + diff * dd_ratio//台車位置まで線形補完

        if (world.getDynamicProperty("mtc_tilt") === 1) {
            setdb(ent, -body_deg_dx)
            setdh(ent, -head_deg_d)
        } else {
            setdb(ent, -diff / 2)
            setdh(ent, diff / 2)
        }

    } else {
        setbodyRl(ent, 0)
        setdb(ent, 0)
        setdh(ent, 0)
    }
    //}
    return tilt_ud
}

function setbodyUd(ent, deg_x) {
    if (world.getDynamicProperty("mtc_tilt") === 1) {
        setState(ent, "mtc_tilt_x", deg_x)
        let deg_x_int = Math.round(deg_x * 8)
        deg_x_int = Math.max(-63, Math.min(63, deg_x_int))

        if (getState(ent, "mtc_tiltold_ud") !== deg_x_int || count_g % 20 == 0) {
            setState(ent, "mtc_tiltold_ud", deg_x_int)
            if (deg_x_int > 0) {
                for (let k = 0; k < 6; k++) {
                    if ((deg_x_int >> k & 1) == 1) {
                        playAni(ent, `animation.mtc_body.u${k}`, "mtc_body_ud" + k)
                    } else {
                        stopAni(ent, "mtc_body_ud" + k)
                    }
                }

            } else if (deg_x_int < 0) {
                for (let k = 0; k < 6; k++) {
                    if (((-deg_x_int) >> k & 1) == 1) {
                        playAni(ent, `animation.mtc_body.d${k}`, "mtc_body_ud" + k)
                    } else {
                        stopAni(ent, "mtc_body_ud" + k)
                    }
                }
            } else {
                for (let k = 0; k < 6; k++) {
                    stopAni(ent, "mtc_body_ud" + k)
                }
            }
        }

    }
}
function setbodyRl(ent, deg_y) {
    //if (world.getDynamicProperty("mtc_tilt") === 1) {
    setState(ent, "mtc_tilt_z", deg_y)

    let deg_y_int = Math.round(deg_y * 8)
    deg_y_int = Math.max(-63, Math.min(63, deg_y_int))

    if (getState(ent, "mtc_tiltold_lr") !== deg_y_int || count_g % 20 == 0) {
        setState(ent, "mtc_tiltold_lr", deg_y_int)

        if (deg_y_int > 0) {
            for (let k = 0; k < 6; k++) {
                if ((deg_y_int >> k & 1) == 1) {
                    playAni(ent, `animation.mtc_body.l${k}`, "mtc_body_lr" + k)
                } else {
                    stopAni(ent, "mtc_body_lr" + k)
                }
            }

        } else if (deg_y_int < 0) {
            for (let k = 0; k < 6; k++) {
                if (((-deg_y_int) >> k & 1) == 1) {
                    playAni(ent, `animation.mtc_body.r${k}`, "mtc_body_lr" + k)
                } else {
                    stopAni(ent, "mtc_body_lr" + k)
                }
            }
        } else {
            for (let k = 0; k < 6; k++) {
                stopAni(ent, "mtc_body_lr" + k)
            }
        }
    }
    //}
}

function setdb(ent, deg_y) {

    let deg_y_int = Math.round(deg_y)
    deg_y_int = Math.max(-63, Math.min(63, deg_y_int))

    if (getState(ent, "mtc_db") !== deg_y_int || count_g % 20 == 0) {
        setState(ent, "mtc_db", deg_y_int)

        if (deg_y_int > 0) {
            for (let k = 0; k < 6; k++) {
                if ((deg_y_int >> k & 1) == 1) {
                    playAni(ent, `animation.mtc_body.dbl${k}`, "mtc_dblr" + k)
                } else {
                    stopAni(ent, "mtc_dblr" + k)
                }
            }

        } else if (deg_y_int < 0) {
            for (let k = 0; k < 6; k++) {
                if (((-deg_y_int) >> k & 1) == 1) {
                    playAni(ent, `animation.mtc_body.dbr${k}`, "mtc_dblr" + k)
                } else {
                    stopAni(ent, "mtc_dblr" + k)
                }
            }
        } else {
            for (let k = 0; k < 6; k++) {
                stopAni(ent, "mtc_dblr" + k)
            }
        }
    }
    //}
}
function setdh(ent, deg_y) {

    let deg_y_int = Math.round(deg_y)
    deg_y_int = Math.max(-63, Math.min(63, deg_y_int))

    if (getState(ent, "mtc_dh") !== deg_y_int || count_g % 20 == 0) {
        setState(ent, "mtc_dh", deg_y_int)

        if (deg_y_int > 0) {
            for (let k = 0; k < 6; k++) {
                if ((deg_y_int >> k & 1) == 1) {
                    playAni(ent, `animation.mtc_body.dhl${k}`, "mtc_dhlr" + k)
                } else {
                    stopAni(ent, "mtc_dhlr" + k)
                }
            }

        } else if (deg_y_int < 0) {
            for (let k = 0; k < 6; k++) {
                if (((-deg_y_int) >> k & 1) == 1) {
                    playAni(ent, `animation.mtc_body.dhr${k}`, "mtc_dhlr" + k)
                } else {
                    stopAni(ent, "mtc_dhlr" + k)
                }
            }
        } else {
            for (let k = 0; k < 6; k++) {
                stopAni(ent, "mtc_dhlr" + k)
            }
        }
    }
    //}
}

function testOnRail(ent, loc, rot) {
    let on_rail = false
    const ublock = ent.dimension.getBlockFromRay(loc, { x: 0, y: -1, z: 0 })
    if (ublock !== undefined) {
        if (ublock.block.typeId.slice(-4) == "rail") {
            on_rail = true
        }
    }
    if (!on_rail) {
        const bx_ux = -Math.cos(0.0174533 * rot.y)
        const by_ux = 0
        const bz_ux = Math.sin(0.0174533 * rot.y)
        const sx = loc.x + 1 * bx_ux
        const sy = loc.y + 1 * by_ux
        const sz = loc.z + 1 * bz_ux
        const ublock = ent.dimension.getBlockFromRay({ x: sx, y: sy, z: sz }, { x: 0, y: -1, z: 0 })
        if (ublock !== undefined) {
            if (ublock.block.typeId.slice(-4) == "rail") {
                on_rail = true
            }
        }
    }
    if (!on_rail) {
        const bx_ux = -Math.cos(0.0174533 * rot.y)
        const by_ux = 0
        const bz_ux = Math.sin(0.0174533 * rot.y)
        const sx = loc.x - 1 * bx_ux
        const sy = loc.y - 1 * by_ux
        const sz = loc.z - 1 * bz_ux
        const ublock = ent.dimension.getBlockFromRay({ x: sx, y: sy, z: sz }, { x: 0, y: -1, z: 0 })
        if (ublock !== undefined) {
            if (ublock.block.typeId.slice(-4) == "rail") {
                on_rail = true
            }
        }
    }
    return on_rail
}

//parentからの呼び出し
async function runJoint(ent_p, ents_f) {
    //編成連結順(1号車先頭)
    let entf_order = [ent_p]
    let pre_ent = ent_p
    while (true) {
        let fount_child = false
        for (const ent_trg of ents_f) {
            if (obj_mtc_uid.getScore(pre_ent) === obj_mtc_parent.getScore(ent_trg)) {
                entf_order.push(ent_trg)
                pre_ent = ent_trg
                fount_child = true
                break
            }
        }
        if (!fount_child) break
    }
    const cars = entf_order.length

    for (let i = 0; i < cars; i++) {
        let x0 = ent_p.getDynamicProperty("dist")
        let ent_f
        //編成連結順(進行方向先頭)
        if (ent_p.hasTag("mtc_rev")) {
            ent_f = entf_order[cars - 1 - i]
        } else {
            ent_f = entf_order[i]
        }

        //車軸間距離
        let d1 = 2.1
        if (obj_mtc_dd.hasParticipant(ent_f)) {
            d1 = obj_mtc_dd.getScore(ent_f) * 0.001
        }

        let eg_d_dist = ent_f.getDynamicProperty("mtc_d_length")
        let b_dist = ent_f.getDynamicProperty("mtc_body_length")
        if (eg_d_dist === undefined) eg_d_dist = 16.9

        //20m車の一般的なパラメータとMTCの初期パラメータの補正
        if (Math.abs(b_dist - 20) < 0.1 && Math.abs(eg_d_dist - 17.5) < 0.1) {
            eg_d_dist = 16.9
        }

        //台車間距離
        const d_dist = eg_d_dist * 2 - b_dist

        let pitch = 0.5 + (obj_mtc_spd.getScore(ent_p) - 20000) / 120000
        if (pitch < 0.5) pitch = 0.5
        if (pitch > 1) pitch = 1
        pitch = pitch.toFixed(5)

        let run_name = ent_f.getDynamicProperty("mtc_jointsound")
        if (run_name === undefined) run_name = "mtc.joint"

        let pos1, pos2
        if (ent_p.hasTag("mtc_rev")) {
            pos1 = (b_dist - eg_d_dist).toFixed(5)
            pos2 = eg_d_dist.toFixed(5)
        } else {
            pos1 = eg_d_dist.toFixed(5)
            pos2 = (b_dist - eg_d_dist).toFixed(5)
        }

        ent_f.runCommand(`execute positioned ^^^${pos1} run playsound ${run_name} @a[r=${b_dist / 2}] ~~~ 1.0 ${pitch} 1.0`)
        ent_f.runCommand(`execute positioned ^^^${pos1} run playsound ${run_name} @a[r=${b_dist},rm=${b_dist / 2}] ~~~ 0.2 ${pitch} 0.3`)
        ent_f.runCommand(`execute positioned ^^^${pos1} run playsound ${run_name} @a[r=${b_dist * 1.5},rm=${b_dist}] ~~~ 0.1 ${pitch} 0.1`)

        if (d1 > 0) {
            await sleep(Math.max(1, Math.round(144000 * d1 / (obj_mtc_spd.getScore(ent_p) * scale_g))))

            ent_f.runCommand(`execute positioned ^^^${pos1} run playsound ${run_name} @a[r=${b_dist / 2}] ~~~ 1.0 ${pitch} 1.0`)
            ent_f.runCommand(`execute positioned ^^^${pos1} run playsound ${run_name} @a[r=${b_dist},rm=${b_dist / 2}] ~~~ 0.2 ${pitch} 0.3`)
            ent_f.runCommand(`execute positioned ^^^${pos1} run playsound ${run_name} @a[r=${b_dist * 1.5},rm=${b_dist}] ~~~ 0.1 ${pitch} 0.1`)
        }

        while (ent_p.getDynamicProperty("dist") - x0 < d_dist) await sleep(1)

        ent_f.runCommand(`execute positioned ^^^${pos2} run playsound ${run_name} @a[r=${b_dist / 2}] ~~~ 1.0 ${pitch} 1.0`)
        ent_f.runCommand(`execute positioned ^^^${pos2} run playsound ${run_name} @a[r=${b_dist},rm=${b_dist / 2}] ~~~ 0.2 ${pitch} 0.3`)
        ent_f.runCommand(`execute positioned ^^^${pos2} run playsound ${run_name} @a[r=${b_dist * 1.5},rm=${b_dist}] ~~~ 0.1 ${pitch} 0.1`)

        if (d1 > 0) {
            await sleep(Math.max(1, Math.ceil(144000 * d1 / (obj_mtc_spd.getScore(ent_p) * scale_g))))

            ent_f.runCommand(`execute positioned ^^^${pos2} run playsound ${run_name} @a[r=${b_dist / 2}] ~~~ 1.0 ${pitch} 1.0`)
            ent_f.runCommand(`execute positioned ^^^${pos2} run playsound ${run_name} @a[r=${b_dist},rm=${b_dist / 2}] ~~~ 0.2 ${pitch} 0.3`)
            ent_f.runCommand(`execute positioned ^^^${pos2} run playsound ${run_name} @a[r=${b_dist * 1.5},rm=${b_dist}] ~~~ 0.1 ${pitch} 0.1`)
        }

        while (ent_p.getDynamicProperty("dist") - x0 < b_dist) await sleep(1)
        //await sleep(Math.ceil(144000 * (b_dist-d_dist-d1) / obj_mtc_spd.getScore(ent_p)))
    }
}

function getTime() {
    return new Date().getTime();
}

function makeTunnel(dim, bz1, bz2, bz3, dl, dr, du, dd) {
    let sca_l = []
    let sca_r = []
    let sca_u = []
    let sca_d = []
    for (let i = 0; i <= dl; i++) sca_l.push(i);
    sca_l.push(dl + 0.48)
    for (let i = 1; i <= dr; i++) sca_r.push(i);
    sca_r.push(dr + 0.48)
    for (let i = 0; i <= du; i++) sca_u.push(i);
    sca_u.push(du + 0.98)
    for (let i = 1; i <= dd; i++) sca_d.push(i);
    sca_d.push(dd)

    for (let t = 0; t <= 1; t += 0.01) {
        const p = getBezier(bz1, bz2, bz3, t)
        const vec = bezierTangent(bz1, bz2, bz3, t)
        let vx = vec.z
        let vz = -vec.x
        const vr = Math.sqrt(vx ** 2 + vz ** 2)
        if (vr <= 0) break
        vx /= vr
        vz /= vr
        setBlock(dim, p, "minecraft:air")
        for (const su of sca_u) {
            for (const sl of sca_l) {
                const p2 = { x: p.x + vx * sl, y: p.y + su, z: p.z + vz * sl }
                setBlock(dim, p2, "minecraft:air")
            }
            for (const sr of sca_r) {
                const p2 = { x: p.x - vx * sr, y: p.y + su, z: p.z - vz * sr }
                setBlock(dim, p2, "minecraft:air")
            }
        }
        for (const sd of sca_d) {
            for (const sl of sca_l) {
                const p2 = { x: p.x + vx * sl, y: p.y - sd, z: p.z + vz * sl }
                setBlock(dim, p2, "minecraft:air")
            }
            for (const sr of sca_r) {
                const p2 = { x: p.x - vx * sr, y: p.y - sd, z: p.z - vz * sr }
                setBlock(dim, p2, "minecraft:air")
            }
        }


    }

}

function setBlock(dim, pos, block_n) {
    try {
        const block = dim.getBlock(pos)
        block.setPermutation(BlockPermutation.resolve(block_n))
        return true
    } catch (e) {
    }
    return false
}

let temp_state = {}
function setState(ent, id, val) {
    temp_state[id + ent.id] = val
}
function getState(ent, id) {
    return temp_state[id + ent.id]
}
